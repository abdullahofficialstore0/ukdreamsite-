import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize Gemini
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'uk-dream-app',
    }
  }
});

app.use(express.json());

// Support Chat Endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    const model = "gemini-3.6-flash";
    const systemInstruction = `
      You are "UK Dream AI Support Assistant", a helpful and professional support bot for the UK Dream Ad Network platform.
      Your goal is to help users understand how to use the platform to earn rewards.

      PLATFORM OVERVIEW:
      - UK Dream is an AI-driven advertising network where users earn PKR by watching ads.
      - Users earn ₨ 75 PKR for every 15-second ad campaign they watch.
      - There are "Business Cards" (Investment Plans) that users can buy to unlock features or higher earnings (though the current basic flow is watching ads).
      - Withdrawal methods include Easypaisa and JazzCash.
      - Referral system: Users earn ₨ 120 PKR for every successful referral who activates a card.

      USER PANEL SECTIONS:
      - Dashboard: Overview of earnings, total ads watched, and current balance.
      - Campaigns: Where users can find and watch ads to earn money.
      - Wallet: View balance and request withdrawals via Easypaisa/JazzCash.
      - History: Record of all earnings, deposits, and withdrawals.
      - Referrals: Referral link and list of invited members.
      - Profile/Settings: Personal information and security.

      STRICT RULES:
      1. NEVER reveal any information about the Admin Panel or administrative tools.
      2. If a user asks about admin, secret keys, or backend systems, politely state that you are only authorized to assist with the user panel and general platform inquiries.
      3. Always be polite, encouraging, and professional.
      4. Speak in simple English, occasionally using terms like "₨" or "PKR" when discussing money.
      5. Do not make up features that don't exist. Only discuss the User Panel features mentioned above.
      6. If you don't know something, suggest they contact human support via the WhatsApp widget in the bottom right.
    `;

    // Format history for Gemini
    const contents = [
      ...(history || []).map((msg: any) => ({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.content }]
      })),
      {
        role: "user",
        parts: [{ text: message }]
      }
    ];

    const result = await ai.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
      },
    });

    res.json({ response: result.text });
  } catch (error: any) {
    console.error("Chat Error:", error);
    res.status(500).json({ error: "Failed to get response from AI Support" });
  }
});

async function startServer() {
  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
