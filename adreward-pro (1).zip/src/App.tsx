import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { CampaignList } from './pages/Campaigns/CampaignList';
import { WatchCampaign } from './pages/Campaigns/WatchCampaign';
import { Wallet } from './pages/Wallet/Wallet';
import { Withdraw } from './pages/Wallet/Withdraw';
import { History } from './pages/History';
import { Referrals } from './pages/Referrals';
import { Profile } from './pages/Profile';
import { Settings } from './pages/Settings';
import { BusinessCards } from './pages/BusinessCards';
import { Auth } from './pages/Auth/Auth';
import { AdminPanel } from './pages/Admin/AdminPanel';
import { WhatsAppWidget } from './components/WhatsAppWidget';
import { SupportChat } from './components/SupportChat';

function MainAppRoutes() {
  const { user, setUser } = useApp();

  if (!user) {
    return (
      <>
        <Auth />
        <WhatsAppWidget />
        <SupportChat />
      </>
    );
  }

  if (user && user.status === 'suspended') {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-white text-center">
        <div className="max-w-md w-full bg-slate-900 border border-red-500/30 p-8 rounded-3xl shadow-2xl space-y-6">
          <div className="w-20 h-20 bg-red-500/20 border border-red-500/40 rounded-full flex items-center justify-center mx-auto text-red-500">
            <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-black text-red-400">Account Suspended</h1>
            <p className="text-slate-300 text-sm">
              Your account (<strong>{user.email}</strong>) has been suspended or blocked by administration.
            </p>
            <p className="text-xs text-slate-500 mt-2">
              If you believe this is an error, please contact official support.
            </p>
          </div>
          <button 
            onClick={() => setUser(null)}
            className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-bold text-sm rounded-xl transition-all cursor-pointer"
          >
            Log Out
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="business-card" element={<BusinessCards />} />
          <Route path="campaigns" element={<CampaignList />} />
          <Route path="wallet" element={<Wallet />} />
          <Route path="wallet/withdraw" element={<Withdraw />} />
          <Route path="history" element={<History />} />
          <Route path="referrals" element={<Referrals />} />
          <Route path="profile" element={<Profile />} />
          <Route path="settings" element={<Settings />} />
        </Route>
        <Route path="/campaigns/watch/:id" element={<WatchCampaign />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <WhatsAppWidget />
      <SupportChat />
    </>
  );
}

function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/admin/*" element={<AdminPanel />} />
        <Route path="/*" element={<MainAppRoutes />} />
      </Routes>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}
