import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { CampaignList } from './pages/Campaigns/CampaignList';
import { WatchCampaign } from './pages/Campaigns/WatchCampaign';
import { Wallet } from './pages/Wallet/Wallet';
import { Withdraw } from './pages/Wallet/Withdraw';
import { History } from './pages/History';
import { Referrals } from './pages/Referrals';
import { Profile } from './pages/Profile';
import { Settings } from './pages/Settings';
import { Auth } from './pages/Auth/Auth';

function AppRouter() {
  const { user } = useApp();

  if (!user) {
    return <Auth />;
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="campaigns" element={<CampaignList />} />
          <Route path="wallet" element={<Wallet />} />
          <Route path="wallet/withdraw" element={<Withdraw />} />
          <Route path="history" element={<History />} />
          <Route path="referrals" element={<Referrals />} />
          <Route path="profile" element={<Profile />} />
          <Route path="settings" element={<Settings />} />
        </Route>
        <Route path="/campaigns/watch/:id" element={<WatchCampaign />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}
