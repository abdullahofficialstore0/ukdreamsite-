import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  AppState, 
  User, 
  Campaign, 
  Transaction, 
  BusinessCard, 
  SiteSettings, 
  WithdrawalRequest, 
  NotificationItem,
  DepositRequest
} from '../types';
import { 
  db 
} from '../lib/firebase';
import { 
  doc, 
  collection, 
  onSnapshot, 
  setDoc, 
  updateDoc,
  deleteDoc,
  query,
  where,
  getDocs,
  getDoc,
  orderBy
} from 'firebase/firestore';
import { 
  defaultSiteSettings, 
  initializeSettings, 
  saveCampaignInFirestore, 
  createWithdrawalRequestInFirestore,
  updateWithdrawalStatusInFirestore,
  createDepositRequestInFirestore,
  transactionsCol
} from '../lib/firestoreService';

const defaultBusinessCards: BusinessCard[] = [
  {
    id: 'starter',
    title: 'Starter Business Card',
    pricePkr: 700,
    priceUsd: 2.50,
    color: 'from-blue-600 via-indigo-600 to-slate-900',
    cardNumber: '4532 8910 1001 7001',
    validity: 'Lifetime',
    status: 'unactivated'
  },
  {
    id: 'gold',
    title: 'Golden Business Card',
    pricePkr: 1400,
    priceUsd: 5.00,
    color: 'from-amber-500 via-yellow-600 to-amber-900',
    cardNumber: '4916 8910 1003 1400',
    validity: 'Lifetime',
    status: 'unactivated'
  },
  {
    id: 'premium',
    title: 'Premium Business Card',
    pricePkr: 2100,
    priceUsd: 7.50,
    color: 'from-purple-600 via-indigo-700 to-slate-900',
    cardNumber: '5241 8910 1002 2100',
    validity: 'Lifetime',
    status: 'unactivated'
  },
  {
    id: 'royal',
    title: 'Royal Business Card',
    pricePkr: 3000,
    priceUsd: 10.70,
    color: 'from-emerald-600 via-teal-700 to-slate-950',
    cardNumber: '3782 8910 1004 3000',
    validity: 'Lifetime',
    status: 'unactivated'
  }
];

const initialDailyAds: Campaign[] = [
  {
    id: 'ad-1',
    title: 'Tech Gadget Launch 2026 UK',
    description: 'Watch this 15-second UK tech showcase ad completely to earn ₨ 75 ($0.27).',
    thumbnail: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Technology',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-2',
    title: 'British EV Supercars Innovation',
    description: 'Discover next-gen UK electric vehicle tech in this 15-second ad.',
    thumbnail: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Automotive',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-3',
    title: 'London Digital Wallet & Fintech',
    description: 'Learn how modern mobile wallet technology simplifies UK payments.',
    thumbnail: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Finance',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-4',
    title: 'UK Sustainable Living & Fashion',
    description: 'Explore organic British lifestyle products in this quick 15-second ad.',
    thumbnail: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Lifestyle',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoylikes.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-5',
    title: 'Cloud Gaming Showcase London',
    description: 'Watch the official trailer preview for top UK cloud gaming releases.',
    thumbnail: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Gaming',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-6',
    title: 'Smart Home Automation UK',
    description: 'Next-generation smart home security and AI devices in 15 seconds.',
    thumbnail: 'https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Technology',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-7',
    title: 'UK Luxury Watches & Apparel',
    description: 'Experience handcrafted luxury timepieces and British craftsmanship.',
    thumbnail: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Fashion',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnEmpty.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-8',
    title: 'Global Crypto & Web3 Exchange UK',
    description: 'Secure instant cryptocurrency trading platform promo for UK investors.',
    thumbnail: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1bd?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Crypto',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-9',
    title: 'High Speed Fiber Broadband UK',
    description: 'Ultra-fast 1Gbps fiber internet for homes and offices across the United Kingdom.',
    thumbnail: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Telecom',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-10',
    title: 'British Organic Health & Fitness',
    description: 'Premium vitamins and organic nutrition products for daily performance.',
    thumbnail: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Health',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-11',
    title: 'AI Productivity Suite UK',
    description: 'Automate business workflows with next-gen artificial intelligence tools.',
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Software',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-12',
    title: 'UK Premier Travel & Airlines',
    description: 'Book luxury direct flights from London Heathrow with exclusive rewards.',
    thumbnail: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Travel',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-13',
    title: 'E-Commerce Logistics London',
    description: 'Same-day parcel delivery across London and major UK metropolitan areas.',
    thumbnail: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Logistics',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-14',
    title: 'Modern Real Estate Investment UK',
    description: 'Invest in high-yield residential properties in Manchester and Birmingham.',
    thumbnail: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Real Estate',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-15',
    title: 'Solar Energy & Green Tech UK',
    description: 'Zero-emission solar panel installations for UK homes and commercial buildings.',
    thumbnail: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Energy',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoylikes.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-16',
    title: 'UK Online Academy & Degrees',
    description: 'Earn accredited UK university degrees through flexible online learning.',
    thumbnail: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Education',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-17',
    title: 'Premium UK Coffee Roasters',
    description: 'Artisanal single-origin coffee beans delivered fresh to your door in the UK.',
    thumbnail: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Food',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-18',
    title: 'Cybersecurity Guard UK',
    description: 'Enterprise threat protection and data privacy shielding for British firms.',
    thumbnail: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Security',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnEmpty.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-19',
    title: 'UK Mobile App Studio',
    description: 'Build high performance iOS & Android mobile applications with AI.',
    thumbnail: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Tech',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-20',
    title: 'Royal Luxury Hotel & Resorts UK',
    description: 'Five-star countryside retreats and luxury spa experiences in Scotland.',
    thumbnail: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Hospitality',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-21',
    title: 'UK Renewable Energy Holdings',
    description: 'Invest in wind farm infrastructure powering over 2 million homes.',
    thumbnail: 'https://images.unsplash.com/photo-1466611653911-95081537e5b7?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Investment',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    watched: false,
    status: 'active'
  },
  {
    id: 'ad-22',
    title: 'UK Dream Official AI Network',
    description: 'Maximize your daily digital earnings with verified global video ad campaigns.',
    thumbnail: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800',
    duration: 15,
    rewardAmount: 0.27,
    rewardPkr: 75,
    remainingAvailability: 100,
    category: 'Platform',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4',
    watched: false,
    status: 'active'
  }
];

interface AppContextType extends AppState {
  setUser: (user: User | null) => void;
  setTheme: (theme: AppState['theme']) => void;
  addBalance: (amount: number, description?: string) => void;
  deductBalance: (amount: number) => void;
  applyCardActivation: (cardId: string, senderTitle: string, senderNumber: string, trxId: string, receiptUrl?: string) => void;
  approveCardActivation: (cardId: string, targetEmail?: string) => void;
  deleteTransaction: (txId: string) => Promise<void>;
  deleteCampaign: (campaignId: string) => void;
  markAdWatched: (adId: string) => void;
  hasActiveCard: boolean;
  resetDailyAds: () => void;
  submitWithdrawal: (amountUsd: number, amountPkr: number, method: string, accountTitle: string, accountNumber: string) => Promise<boolean>;
  updateSiteSettingsState: (settings: Partial<SiteSettings>) => void;
}

const defaultState: AppState = {
  user: null,
  walletBalance: 0.00,
  lifetimeRewards: 0.00,
  pendingRewards: 0.00,
  todayEarnings: 0.00,
  monthlyEarnings: 0.00,
  totalAdsWatched: 0,
  referralEarnings: 0.00,
  theme: 'light',
  notifications: [],
  campaigns: initialDailyAds,
  transactions: [],
  businessCards: defaultBusinessCards,
  siteSettings: defaultSiteSettings,
  withdrawals: [],
  depositRequests: [],
  announcements: [],
  pkrRate: 278.5
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(() => {
    // Try to restore user state from localStorage
    const savedEmail = localStorage.getItem('adreward_current_email');
    if (savedEmail) {
      const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      const u = storedUsers[savedEmail];
      if (u) {
        const userCards = u.businessCards || defaultBusinessCards;
        return {
          ...defaultState,
          user: u,
          walletBalance: u.walletBalance || 0,
          referralEarnings: u.referralEarnings || 0,
          businessCards: userCards,
          campaigns: u.campaigns || initialDailyAds,
          pkrRate: 278.5
        };
      }
    }
    return defaultState;
  });

  // Initialize and subscribe to Firestore Site Settings in Real Time
  useEffect(() => {
    initializeSettings();

    const unsubSettings = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) {
        const data = snap.data() as SiteSettings;
        setState(s => ({ ...s, siteSettings: { ...defaultSiteSettings, ...data } }));
      }
    });

    // Real time campaigns listener
    const unsubCampaigns = onSnapshot(collection(db, 'campaigns'), (snap) => {
      const loadedCampaigns: Campaign[] = [];
      if (!snap.empty) {
        snap.forEach(docSnap => {
          loadedCampaigns.push({ id: docSnap.id, ...docSnap.data() } as Campaign);
        });
      }
      setState(s => ({ ...s, campaigns: loadedCampaigns }));
    });

    // Real time announcements listener
    const unsubAnnouncements = onSnapshot(collection(db, 'announcements'), (snap) => {
      const list: any[] = [];
      snap.forEach(docSnap => list.push({ id: docSnap.id, ...docSnap.data() }));
      setState(s => ({ ...s, announcements: list }));
    });

    // Real time withdrawals listener
    const unsubWithdrawals = onSnapshot(collection(db, 'withdrawals'), (snap) => {
      const list: WithdrawalRequest[] = [];
      snap.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as WithdrawalRequest);
      });
      setState(s => ({ ...s, withdrawals: list }));
    });

    // Real time deposit requests listener
    const unsubDeposits = onSnapshot(collection(db, 'deposits'), (snap) => {
      const list: DepositRequest[] = [];
      snap.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as DepositRequest);
      });
      setState(s => ({ ...s, depositRequests: list }));
    });

    // Real time notifications listener
    const unsubNotifications = onSnapshot(collection(db, 'notifications'), (snap) => {
      const list: NotificationItem[] = [];
      snap.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as NotificationItem);
      });
      setState(s => ({ ...s, notifications: list }));
    });

    // Real time transactions listener for the current user
    let unsubTransactions = () => {};
    if (state.user?.email) {
      const txQuery = query(
        collection(db, 'transactions'), 
        where('userId', '==', state.user.email),
        orderBy('date', 'desc')
      );
      unsubTransactions = onSnapshot(txQuery, (snap) => {
        const txList: Transaction[] = [];
        snap.forEach(docSnap => {
          txList.push({ id: docSnap.id, ...docSnap.data() } as Transaction);
        });
        setState(s => ({ ...s, transactions: txList }));
      }, (err) => {
        console.warn('Transactions listen notice (may need index):', err);
        // Fallback to non-ordered query if index missing
        const fallbackQuery = query(collection(db, 'transactions'), where('userId', '==', state.user!.email));
        onSnapshot(fallbackQuery, (snap) => {
          const txList: Transaction[] = [];
          snap.forEach(docSnap => {
            txList.push({ id: docSnap.id, ...docSnap.data() } as Transaction);
          });
          setState(s => ({ ...s, transactions: txList }));
        });
      });
    }

    return () => {
      unsubSettings();
      unsubCampaigns();
      unsubWithdrawals();
      unsubDeposits();
      unsubNotifications();
      unsubTransactions();
      unsubAnnouncements();
    };
  }, [state.user?.email]); 
  useEffect(() => {
    if (!state.user?.email) return;
    const userEmail = state.user.email;
    
    // Use query for email field instead of direct ID for absolute reliability
    const q = query(collection(db, 'users'), where('email', '==', userEmail));
    
    const unsubUser = onSnapshot(q, (snap) => {
      if (!snap.empty) {
        const liveUserData = snap.docs[0].data();
        setState(s => {
          if (!s.user || s.user.email !== userEmail) return s;
          
          // Only update if data actually changed to avoid infinite loops
          const hasBalanceChanged = liveUserData.walletBalance !== s.walletBalance;
          const hasRefChanged = liveUserData.referralEarnings !== s.referralEarnings;
          const hasStatusChanged = liveUserData.status !== s.user.status;
          const hasCardChanged = liveUserData.activeCardId !== s.user.activeCardId;
          const hasWatchedAdsChanged = JSON.stringify(liveUserData.watchedAds) !== JSON.stringify(s.user.watchedAds);
          const hasRefListChanged = JSON.stringify(liveUserData.referralsList) !== JSON.stringify(s.user.referralsList);

          if (!hasBalanceChanged && !hasRefChanged && !hasStatusChanged && !hasCardChanged && !hasWatchedAdsChanged && !hasRefListChanged) return s;

          const updatedReferrals = liveUserData.referralsList || s.user.referralsList || [];

          // Also keep local storage in sync
          try {
            const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
            if (storedUsers[userEmail]) {
              storedUsers[userEmail] = {
                ...storedUsers[userEmail],
                walletBalance: typeof liveUserData.walletBalance === 'number' ? liveUserData.walletBalance : s.walletBalance,
                referralEarnings: typeof liveUserData.referralEarnings === 'number' ? liveUserData.referralEarnings : s.referralEarnings,
                activeCardId: liveUserData.activeCardId,
                referralsList: updatedReferrals
              };
              localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
            }
          } catch (eErr) {
            console.warn('Local storage sync in snapshot failed:', eErr);
          }

          return {
            ...s,
            walletBalance: typeof liveUserData.walletBalance === 'number' ? liveUserData.walletBalance : s.walletBalance,
            referralEarnings: typeof liveUserData.referralEarnings === 'number' ? liveUserData.referralEarnings : s.referralEarnings,
            user: {
              ...s.user,
              status: liveUserData.status || s.user.status,
              activeCardId: liveUserData.activeCardId !== undefined ? liveUserData.activeCardId : s.user.activeCardId,
              watchedAds: liveUserData.watchedAds || [],
              referralsList: updatedReferrals
            }
          };
        });
      }
    });

    return () => unsubUser();
  }, [state.user?.email]);

  // Initialize theme on html document root
  useEffect(() => {
    const root = window.document.documentElement;
    if (state.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [state.theme]);

  // Sync state changes to localStorage for persistent user accounts
  useEffect(() => {
    if (state.user?.email) {
      localStorage.setItem('adreward_current_email', state.user.email);
      const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      
      const updatedLocalUser = {
        ...(storedUsers[state.user.email] || state.user),
        walletBalance: state.walletBalance,
        referralEarnings: state.referralEarnings,
        businessCards: state.businessCards,
        campaigns: state.campaigns,
        activeCardId: state.user.activeCardId
      };
      
      storedUsers[state.user.email] = updatedLocalUser;
      localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
    }
  }, [state.walletBalance, state.referralEarnings, state.businessCards, state.campaigns, state.user]);

  const setUser = (user: User | null) => {
    if (user === null) {
      localStorage.removeItem('adreward_current_email');
      setState(s => ({ ...defaultState, theme: s.theme, siteSettings: s.siteSettings, campaigns: s.campaigns }));
    } else {
      const referralCode = user.referralCode || `UKD-${Math.floor(1000 + Math.random() * 9000)}`;
      const userWithCode = { ...user, referralCode };
      localStorage.setItem('adreward_current_email', user.email);
      
      const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      const uData = storedUsers[user.email] || {};
      const userCards = uData.businessCards || defaultBusinessCards;

      setState(s => ({ 
        ...s, 
        user: userWithCode, 
        walletBalance: uData.walletBalance ?? (user.walletBalance || 0),
        referralEarnings: uData.referralEarnings ?? (user.referralEarnings || 0),
        businessCards: userCards,
        campaigns: uData.campaigns || s.campaigns
      }));
    }
  };

  const setTheme = (theme: AppState['theme']) => setState(s => ({ ...s, theme }));

  const updateSiteSettingsState = (settings: Partial<SiteSettings>) => {
    setState(s => ({ ...s, siteSettings: { ...s.siteSettings, ...settings } }));
  };

  const addBalance = (amount: number, description: string = 'Reward Claimed') => setState(s => {
    const newTx: Transaction = {
      id: Math.random().toString(36).substring(7),
      type: 'reward',
      amount,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' - ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status: 'completed',
      referenceNumber: 'RWD-' + Math.floor(Math.random() * 100000),
      description
    };
    return {
      ...s,
      walletBalance: s.walletBalance + amount,
      lifetimeRewards: s.lifetimeRewards + amount,
      todayEarnings: s.todayEarnings + amount,
      totalAdsWatched: s.totalAdsWatched + 1,
      transactions: [newTx, ...s.transactions]
    };
  });
  
  const deductBalance = (amount: number, description: string = 'Withdrawal Request', txId?: string) => setState(s => {
    const referenceNumber = txId || 'WDL-' + Math.floor(100000 + Math.random() * 900000);
    const newTx: Transaction = {
      id: referenceNumber,
      type: 'withdrawal',
      amount: -amount,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
      status: 'pending',
      referenceNumber,
      description
    };
    return {
      ...s,
      walletBalance: Math.max(0, s.walletBalance - amount),
      transactions: [newTx, ...s.transactions]
    };
  });

  const submitWithdrawal = async (amountUsd: number, amountPkr: number, method: string, accountTitle: string, accountNumber: string) => {
    if (!state.user || !state.user.email) return false;

    // Minimum withdrawal threshold is $0.36 USD
    if (amountUsd < 0.36) {
      console.warn('Withdrawal rejected: Amount is less than minimum $0.36 USD');
      return false;
    }

    if (state.walletBalance < amountUsd) {
      console.warn('Withdrawal rejected: Insufficient wallet balance');
      return false;
    }

    const referenceNumber = 'WDL-' + Math.floor(100000 + Math.random() * 900000);

    // 1. Save to Firestore Withdrawals Collection
    const withdrawalRequest = await createWithdrawalRequestInFirestore({
      userId: state.user.id || state.user.email,
      userName: state.user.name || 'User',
      userEmail: state.user.email,
      amountUsd,
      amountPkr,
      method,
      accountTitle,
      accountNumber,
      status: 'pending',
      requestedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })
    });

    // 2. Save as a Pending Transaction in Firestore
    const txRef = doc(transactionsCol, referenceNumber);
    await setDoc(txRef, {
      id: referenceNumber,
      userId: state.user.email,
      userName: state.user.name,
      type: 'withdrawal',
      amount: -amountUsd,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
      status: 'pending',
      referenceNumber,
      description: `${method.toUpperCase()} Fund Withdrawal`,
      accountTitle,
      accountNumber,
      method,
      withdrawalId: withdrawalRequest.id
    });

    // 3. Update User Balance in Firestore
    const userRef = doc(db, 'users', state.user.email);
    await updateDoc(userRef, {
      walletBalance: Math.max(0, state.walletBalance - amountUsd)
    });

    // Local state will be updated by real-time listeners
    return true;
  };

  const effectiveBusinessCards = defaultBusinessCards.map(card => {
    if (state.user?.activeCardId === card.id) {
      return {
        ...card,
        status: 'active' as const
      };
    }

    const currentUserEmail = state.user?.email ? state.user.email.trim().toLowerCase() : '';
    const currentUserId = state.user?.id;

    const pendingDep = state.depositRequests.find(d => {
      if (d.cardId !== card.id || d.status !== 'pending') return false;
      const dEmail = (d.userEmail || '').trim().toLowerCase();
      const dUserId = d.userId;
      return (
        (currentUserEmail && dEmail === currentUserEmail) ||
        (currentUserId && dUserId === currentUserId) ||
        (currentUserEmail && dUserId && dUserId.trim().toLowerCase() === currentUserEmail)
      );
    });

    if (pendingDep) {
      return {
        ...card,
        status: 'processing' as const,
        senderTitle: pendingDep.senderTitle,
        senderNumber: pendingDep.senderNumber,
        trxId: pendingDep.trxId,
        receiptUrl: pendingDep.receiptUrl,
        appliedAt: pendingDep.createdAt
      };
    }

    return {
      ...card,
      status: 'unactivated' as const
    };
  });

  const applyCardActivation = (cardId: string, senderTitle: string, senderNumber: string, trxId: string, receiptUrl?: string) => {
    const card = defaultBusinessCards.find(c => c.id === cardId);
    if (state.user && card) {
      const userEmail = state.user.email.trim().toLowerCase();
      const newDepositObj: DepositRequest = {
        id: 'temp-' + Date.now(),
        userId: state.user.id || userEmail,
        userName: state.user.name || 'Member',
        userEmail: userEmail,
        cardId: card.id as any,
        cardTitle: card.title,
        amountPkr: card.pricePkr,
        amountUsd: card.priceUsd,
        senderTitle,
        senderNumber,
        trxId,
        receiptUrl: receiptUrl || 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&q=80&w=400',
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      // Optimistically push to depositRequests in state
      setState(s => ({
        ...s,
        depositRequests: [
          newDepositObj,
          ...s.depositRequests.filter(d => !(d.userEmail?.toLowerCase() === userEmail && d.cardId === cardId && d.status === 'pending'))
        ]
      }));

      createDepositRequestInFirestore({
        userId: newDepositObj.userId,
        userName: newDepositObj.userName,
        userEmail: newDepositObj.userEmail,
        cardId: newDepositObj.cardId,
        cardTitle: newDepositObj.cardTitle,
        amountPkr: newDepositObj.amountPkr,
        amountUsd: newDepositObj.amountUsd,
        senderTitle: newDepositObj.senderTitle,
        senderNumber: newDepositObj.senderNumber,
        trxId: newDepositObj.trxId,
        receiptUrl: newDepositObj.receiptUrl,
        status: 'pending',
        createdAt: newDepositObj.createdAt
      }).catch(err => console.warn('Deposit request create notice:', err));
    }
  };

  const approveCardActivation = (cardId: string, targetEmail?: string) => {
    const targetUserEmail = (targetEmail || state.user?.email || '').trim().toLowerCase();
    
    setState(s => {
      const currentUserEmail = s.user?.email ? s.user.email.trim().toLowerCase() : '';
      const isSelf = currentUserEmail && currentUserEmail === targetUserEmail;
      
      const updatedUser = isSelf ? { ...s.user!, activeCardId: cardId } : s.user;

      const pkrRate = s.siteSettings.pkrRate || 278.5;
      const affiliateBonusUsd = 80 / pkrRate; // Rs 80 PKR

      const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      if (targetUserEmail && storedUsers[targetUserEmail]) {
        storedUsers[targetUserEmail].activeCardId = cardId;
        const refEmail = storedUsers[targetUserEmail].referredByEmail;
        if (refEmail && storedUsers[refEmail]) {
          const referrer = storedUsers[refEmail];
          referrer.walletBalance = (referrer.walletBalance || 0) + affiliateBonusUsd;
          referrer.referralEarnings = (referrer.referralEarnings || 0) + affiliateBonusUsd;
          
          if (!referrer.referralsList) referrer.referralsList = [];
          const existingIdx = referrer.referralsList.findIndex((r: any) => (r.email || '').trim().toLowerCase() === targetUserEmail);
          if (existingIdx >= 0) {
            referrer.referralsList[existingIdx].packageActivated = true;
            referrer.referralsList[existingIdx].reward = affiliateBonusUsd;
          } else {
            referrer.referralsList.push({
              name: storedUsers[targetUserEmail].name || 'Member',
              email: targetUserEmail,
              date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
              reward: affiliateBonusUsd,
              packageActivated: true
            });
          }

          storedUsers[refEmail] = referrer;
        }
        localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
      }

      return {
        ...s,
        user: updatedUser
      };
    });
  };

  const deleteTransaction = async (txId: string) => {
    if (state.user?.email) {
      try {
        await deleteDoc(doc(db, 'transactions', txId));
        // Local state will be updated by listener
      } catch (err) {
        console.error('Delete tx error:', err);
      }
    }
  };

  const markAdWatched = async (adId: string) => {
    const ad = state.campaigns.find(a => a.id === adId);
    if (!ad) return;

    // Plan-based rewards (PKR)
    // Starter: 50, Golden: 70, Premium: 85, Royal: 95
    let rewardPkr = 50;
    const activeCard = state.user?.activeCardId;
    if (activeCard === 'gold') rewardPkr = 70;
    else if (activeCard === 'premium') rewardPkr = 85;
    else if (activeCard === 'royal') rewardPkr = 95;
    
    const rewardUsd = rewardPkr / state.pkrRate;

    // 1. Update Firestore first (Source of Truth)
    if (state.user?.email) {
      try {
        const userRef = doc(db, 'users', state.user.email);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
          const userData = userSnap.data();
          
          // Check daily limit (5 ads)
          const today = new Date().toLocaleDateString();
          const lastWatchDate = userData.lastWatchDate || '';
          let dailyCount = lastWatchDate === today ? (userData.dailyAdsWatched || 0) : 0;
          
          if (dailyCount >= 5) {
            alert('Daily limit reached! You can only watch 5 ads per day.');
            return;
          }

          const currentBal = userData.walletBalance || 0;
          const watchedAds = userData.watchedAds || [];
          
          if (watchedAds.includes(adId)) {
            alert('You have already watched this ad.');
            return;
          }

          await updateDoc(userRef, { 
            walletBalance: currentBal + rewardUsd,
            totalAdsWatched: (userData.totalAdsWatched || 0) + 1,
            dailyAdsWatched: dailyCount + 1,
            lastWatchDate: today,
            watchedAds: [...watchedAds, adId],
            updatedAt: new Date().toISOString()
          });

          // Also record transaction in Firestore
          const txRef = doc(transactionsCol);
          await setDoc(txRef, {
            id: txRef.id,
            userId: state.user.email,
            userName: state.user.name,
            type: 'reward',
            amount: rewardUsd,
            date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' - ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
            status: 'completed',
            referenceNumber: 'AD-' + Math.floor(Math.random() * 1000000),
            description: `Watched Ad: ${ad.title}`
          });
        }
      } catch (err) {
        console.error('Error updating reward in Firestore:', err);
      }
    }

    // Local state will be updated by real-time listeners
  };

  const deleteCampaign = (campaignId: string) => {
    setState(s => {
      const updated = s.campaigns.filter(c => c.id !== campaignId);
      localStorage.setItem('adreward_campaigns', JSON.stringify(updated));
      return { ...s, campaigns: updated };
    });
  };

  const resetDailyAds = () => {
    setState(s => ({
      ...s,
      campaigns: initialDailyAds
    }));
  };

  const hasActiveCard = effectiveBusinessCards.some(c => c.status === 'active') || Boolean(state.user?.activeCardId);

  return (
    <AppContext.Provider 
      value={{ 
        ...state, 
        businessCards: effectiveBusinessCards,
        setUser, 
        setTheme, 
        addBalance, 
        deductBalance, 
        applyCardActivation, 
        approveCardActivation, 
        markAdWatched, 
        hasActiveCard,
        resetDailyAds,
        submitWithdrawal,
        updateSiteSettingsState,
        deleteTransaction,
        deleteCampaign
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
