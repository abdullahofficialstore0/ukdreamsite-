import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppState, User, Campaign, Transaction } from '../types';

const defaultCampaigns: Campaign[] = [];

interface AppContextType extends AppState {
  setUser: (user: User | null) => void;
  setTheme: (theme: AppState['theme']) => void;
  addBalance: (amount: number, description?: string) => void;
  deductBalance: (amount: number) => void;
}

const defaultState: AppState = {
  user: null,
  walletBalance: 0.00,
  lifetimeRewards: 0.00,
  pendingRewards: 0.00,
  todayEarnings: 0.00,
  monthlyEarnings: 0.00,
  totalAdsWatched: 0,
  referralEarnings: 0.00,
  theme: 'light',
  notifications: [],
  campaigns: defaultCampaigns,
  transactions: []
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(defaultState);

  // Initialize theme
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('theme-black', 'theme-hacker', 'theme-navy');
    
    if (state.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [state.theme]);

  const setUser = (user: User | null) => {
    if (user === null) {
      // Logout - clear state but keep theme
      setState(s => ({ ...defaultState, theme: s.theme }));
    } else {
      // Ensure referralCode exists
      const referralCode = user.referralCode || `UKD-${Math.floor(1000 + Math.random() * 9000)}-AI`;
      const userWithCode = { ...user, referralCode };
      setState(s => ({ ...defaultState, user: userWithCode, theme: s.theme }));
    }
  };
  const setTheme = (theme: AppState['theme']) => setState(s => ({ ...s, theme }));
  const addBalance = (amount: number, description: string = 'Reward Claimed') => setState(s => {
    const newTx: Transaction = {
      id: Math.random().toString(36).substring(7),
      type: 'reward',
      amount,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' - ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status: 'completed',
      referenceNumber: 'RWD-' + Math.floor(Math.random() * 100000),
      description
    };
    return {
      ...s,
      walletBalance: s.walletBalance + amount,
      lifetimeRewards: s.lifetimeRewards + amount,
      todayEarnings: s.todayEarnings + amount,
      totalAdsWatched: s.totalAdsWatched + 1,
      transactions: [newTx, ...s.transactions]
    };
  });
  
  const deductBalance = (amount: number) => setState(s => {
    const newTx: Transaction = {
      id: Math.random().toString(36).substring(7),
      type: 'withdrawal',
      amount: -amount,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' - ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status: 'completed',
      referenceNumber: 'WDL-' + Math.floor(Math.random() * 100000),
      description: 'Bank/PayPal Withdrawal'
    };
    return {
      ...s,
      walletBalance: s.walletBalance - amount,
      transactions: [newTx, ...s.transactions]
    };
  });

  return (
    <AppContext.Provider value={{ ...state, setUser, setTheme, addBalance, deductBalance }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
