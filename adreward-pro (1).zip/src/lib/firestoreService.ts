import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  addDoc 
} from 'firebase/firestore';
import { db } from './firebase';
import { User, Campaign, WithdrawalRequest, Transaction, SiteSettings, NotificationItem, AuditLog, DepositRequest } from '../types';

// Collections References
export const usersCol = collection(db, 'users');
export const campaignsCol = collection(db, 'campaigns');
export const withdrawalsCol = collection(db, 'withdrawals');
export const depositsCol = collection(db, 'deposits');
export const transactionsCol = collection(db, 'transactions');
export const notificationsCol = collection(db, 'notifications');
export const settingsCol = collection(db, 'settings');
export const auditLogsCol = collection(db, 'audit_logs');

export const defaultSiteSettings: SiteSettings = {
  websiteName: 'UK Dream',
  bankName: 'Meezan Bank Limited',
  accountHolderName: 'UK Dream Official',
  accountNumberIban: 'PK36MEZN0001020304050607',
  easyPaisaNumber: '0300 1234567',
  jazzCashNumber: '0301 7654321',
  nayaPayNumber: '0300 1234567',
  sadaPayNumber: '0301 7654321',
  paymentInstructions: 'Send the exact package amount to any account listed above. Take a screenshot of the payment receipt and enter your TRX ID below to activate.',
  minWithdrawal: 100, // PKR (≈ $0.36 USD)
  maxWithdrawal: 50000, // PKR
  maintenanceMode: false,
  contactEmail: 'support@ukdream.com',
  supportPhone: '+92 300 1234567',
  announcementBanner: 'Welcome to UK Dream AI Affiliate & Reward Platform! Watch daily ads to earn rewards.',
  primaryColor: '#10b981',
  socialFacebook: 'https://facebook.com',
  socialTelegram: 'https://t.me/ukdream',
  socialWhatsapp: 'https://wa.me/923001234567',
  socialYoutube: 'https://youtube.com/@ukdreamofficial',
  socialInstagram: 'https://instagram.com/ukdreamofficial',
  socialTiktok: 'https://tiktok.com/@ukdreamofficial',
  fbrCertificateEnabled: true,
  fbrCertificateNumber: 'NTN: 8940125-9 / FBR Reg: UKD-2026-PRO',
  starterCardPricePkr: 700,
  goldCardPricePkr: 1400,
  premiumCardPricePkr: 2100,
  royalCardPricePkr: 3000,
  specialOfferActive: false,
  specialOfferTitle: 'Sunday Special Offer',
  specialOfferDiscountPercent: 20,
  specialOfferNote: 'Special 20% discount on all Business Card activations today!'
};

// INITIALIZATION: Guarantee site settings doc exists
export async function initializeSettings() {
  try {
    const docRef = doc(db, 'settings', 'global');
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      await setDoc(docRef, defaultSiteSettings);
    }
  } catch (err) {
    console.warn('Firestore settings init notice:', err);
  }
}

// AUDIT LOG HELPER
export async function logAdminAction(adminEmail: string, action: string, details: string) {
  try {
    await addDoc(auditLogsCol, {
      adminEmail,
      action,
      details,
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    console.error('Error writing audit log:', err);
  }
}

// SITE SETTINGS
export async function updateSiteSettingsInFirestore(newSettings: Partial<SiteSettings>, adminEmail: string) {
  const docRef = doc(db, 'settings', 'global');
  await setDoc(docRef, newSettings, { merge: true });
  await logAdminAction(adminEmail, 'Update Payment & Site Settings', 'Updated payment account details or site settings.');
}

// CAMPAIGN MANAGEMENT
export async function saveCampaignInFirestore(campaign: Campaign, adminEmail: string) {
  const docRef = doc(db, 'campaigns', campaign.id);
  await setDoc(docRef, campaign, { merge: true });
  await logAdminAction(adminEmail, 'Save Campaign', `Saved campaign "${campaign.title}" (${campaign.id})`);
}

export async function deleteCampaignInFirestore(campaignId: string, adminEmail: string) {
  const docRef = doc(db, 'campaigns', campaignId);
  await deleteDoc(docRef);
  await logAdminAction(adminEmail, 'Delete Campaign', `Deleted campaign ID: ${campaignId}`);
}

// WITHDRAWAL MANAGEMENT
export async function createWithdrawalRequestInFirestore(req: Omit<WithdrawalRequest, 'id'>) {
  const newRef = doc(withdrawalsCol);
  const withdrawalObj: WithdrawalRequest = {
    ...req,
    id: newRef.id
  };
  await setDoc(newRef, withdrawalObj);
  return withdrawalObj;
}

export async function updateWithdrawalStatusInFirestore(
  withdrawalId: string, 
  status: WithdrawalRequest['status'], 
  adminEmail: string, 
  notes?: string, 
  trxId?: string
) {
  const docRef = doc(db, 'withdrawals', withdrawalId);
  const updateData: any = { status };
  if (notes) updateData.notes = notes;
  if (trxId) updateData.trxId = trxId;

  await updateDoc(docRef, updateData);
  await logAdminAction(adminEmail, 'Update Withdrawal Status', `Withdrawal ${withdrawalId} marked as ${status}`);
}

// DEPOSIT / CARD ACTIVATION REQUEST MANAGEMENT
export async function createDepositRequestInFirestore(req: Omit<DepositRequest, 'id'>) {
  const newRef = doc(depositsCol);
  const depositObj: DepositRequest = {
    ...req,
    id: newRef.id
  };
  await setDoc(newRef, depositObj);
  return depositObj;
}

export async function updateDepositStatusInFirestore(
  depositId: string,
  status: 'approved' | 'rejected',
  adminEmail: string,
  adminNotes?: string,
  pkrRate: number = 278.5
) {
  const docRef = doc(db, 'deposits', depositId);
  const snap = await getDoc(docRef);
  if (!snap.exists()) return;

  const depData = snap.data() as DepositRequest;
  await updateDoc(docRef, {
    status,
    reviewedAt: new Date().toISOString(),
    adminNotes: adminNotes || `Deposit ${status} by admin`
  });

  if (status === 'approved') {
    // Activate card for user in Firestore
    const userEmail = (depData.userEmail || '').trim().toLowerCase();
    let userRef = userEmail ? doc(db, 'users', userEmail) : null;
    let userSnap = userRef ? await getDoc(userRef) : null;
    let u: User | null = (userSnap && userSnap.exists()) ? (userSnap.data() as User) : null;

    if (!u && depData.userId) {
      const refById = doc(db, 'users', depData.userId);
      const snapById = await getDoc(refById);
      if (snapById.exists()) {
        userRef = refById;
        u = snapById.data() as User;
      }
    }

    if (!u && userEmail) {
      const q = query(collection(db, 'users'), where('email', '==', userEmail));
      const qSnap = await getDocs(q);
      if (!qSnap.empty) {
        userRef = doc(db, 'users', qSnap.docs[0].id);
        u = qSnap.docs[0].data() as User;
      }
    }

    // Ensure activeCardId is persisted on user document
    if (userRef) {
      await setDoc(userRef, { activeCardId: depData.cardId }, { merge: true });
    }

    if (u || userEmail) {
      const targetUser = u || { email: userEmail, name: depData.userName || 'Member' } as User;
      
      // Handle Affiliate Referral Bonus (Rs 80 PKR)
      let refEmailToSearch = targetUser.referredByEmail;
      if (!refEmailToSearch && targetUser.referredByCode) {
        try {
          const qByCode = query(collection(db, 'users'), where('referralCode', '==', targetUser.referredByCode));
          const snapByCode = await getDocs(qByCode);
          if (!snapByCode.empty) {
            refEmailToSearch = snapByCode.docs[0].data().email;
          }
        } catch (errCode) {
          console.warn('Search referrer by code failed:', errCode);
        }
      }

      if (refEmailToSearch) {
        let referrerRef = doc(db, 'users', refEmailToSearch);
        let refSnap = await getDoc(referrerRef);
        let referrerData: User | null = refSnap.exists() ? (refSnap.data() as User) : null;

        if (!referrerData) {
          const qRef = query(collection(db, 'users'), where('email', '==', refEmailToSearch));
          const qRefSnap = await getDocs(qRef);
          if (!qRefSnap.empty) {
            referrerRef = doc(db, 'users', qRefSnap.docs[0].id);
            referrerData = qRefSnap.docs[0].data() as User;
          }
        }

        if (referrerData) {
          const bonusUsd = 80 / pkrRate;
          const newBal = (referrerData.walletBalance || 0) + bonusUsd;
          const newRefEarnings = (referrerData.referralEarnings || 0) + bonusUsd;

          const existingList = referrerData.referralsList || [];
          const targetEmail = targetUser.email || userEmail;
          const existingIdx = existingList.findIndex((r: any) => r.email === targetEmail);
          let updatedList = [...existingList];

          if (existingIdx >= 0) {
            updatedList[existingIdx] = {
              ...updatedList[existingIdx],
              packageActivated: true,
              reward: bonusUsd
            };
          } else {
            updatedList.push({
              name: targetUser.name || 'Member',
              email: targetEmail,
              date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
              reward: bonusUsd,
              packageActivated: true
            });
          }

          await updateDoc(referrerRef, {
            walletBalance: newBal,
            referralEarnings: newRefEarnings,
            referralsList: updatedList
          });

          // Also record a transaction for the referrer
          const txRef = doc(transactionsCol);
          await setDoc(txRef, {
            id: txRef.id,
            userId: refEmailToSearch,
            userName: referrerData.name,
            type: 'bonus',
            amount: bonusUsd,
            date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
            status: 'completed',
            referenceNumber: 'REF-' + Math.floor(Math.random() * 100000),
            description: `Referral Bonus (₨ 80 PKR): ${targetUser.name || 'Member'} activated ${depData.cardTitle}`
          });
        }
      }

      // Sync local storage if applicable
      try {
        const localUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
        const targetEmail = (targetUser.email || depData.userEmail || '').trim().toLowerCase();
        if (targetEmail && localUsers[targetEmail]) {
          localUsers[targetEmail].activeCardId = depData.cardId;
        }
        const refEmail = targetUser.referredByEmail || refEmailToSearch;
        if (refEmail && localUsers[refEmail]) {
          const bonusUsd = 80 / pkrRate;
          const referrer = localUsers[refEmail];
          referrer.walletBalance = (referrer.walletBalance || 0) + bonusUsd;
          referrer.referralEarnings = (referrer.referralEarnings || 0) + bonusUsd;
          if (!referrer.referralsList) referrer.referralsList = [];
          const idx = referrer.referralsList.findIndex((r: any) => (r.email || '').trim().toLowerCase() === targetEmail);
          if (idx >= 0) {
            referrer.referralsList[idx].packageActivated = true;
            referrer.referralsList[idx].reward = bonusUsd;
          } else {
            referrer.referralsList.push({
              name: targetUser.name || 'Member',
              email: targetEmail,
              date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
              reward: bonusUsd,
              packageActivated: true
            });
          }
          localUsers[refEmail] = referrer;
        }
        localStorage.setItem('adreward_users', JSON.stringify(localUsers));
      } catch (lErr) {
        console.warn('Local storage sync error:', lErr);
      }
    }
  }

  await logAdminAction(adminEmail, 'Update Deposit Request', `Deposit request ${depositId} for ${depData.userEmail} set to ${status}`);
}

// USER MANAGEMENT
export async function saveUserInFirestore(user: User) {
  const docRef = doc(db, 'users', user.id || user.email);
  await setDoc(docRef, user, { merge: true });
}

export async function updateUserStatusInFirestore(userId: string, status: 'active' | 'suspended', adminEmail: string) {
  try {
    // 1. Try direct ID
    const docRef = doc(db, 'users', userId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      await updateDoc(docRef, { status });
    } else {
      // 2. Try email field query
      const q = query(collection(db, 'users'), where('email', '==', userId));
      const qSnap = await getDocs(q);
      if (!qSnap.empty) {
        await updateDoc(qSnap.docs[0].ref, { status });
      }
    }
    await logAdminAction(adminEmail, 'User Status Toggle', `User ${userId} set to ${status}`);
  } catch (err) {
    console.error('Status update failed:', err);
    throw err;
  }
}

export async function adjustUserBalanceInFirestore(
  userId: string, 
  amountChange: number, 
  reason: string, 
  adminEmail: string,
  type: 'manual_credit' | 'manual_debit'
) {
  try {
    let userRef = doc(db, 'users', userId);
    let snap = await getDoc(userRef);
    
    if (!snap.exists()) {
      const q = query(collection(db, 'users'), where('email', '==', userId));
      const qSnap = await getDocs(q);
      if (!qSnap.empty) {
        userRef = qSnap.docs[0].ref;
        snap = qSnap.docs[0];
      }
    }

    if (snap.exists()) {
      const currentData = snap.data() as User;
      const currentBalance = currentData.walletBalance || 0;
      const newBalance = type === 'manual_credit' ? currentBalance + amountChange : Math.max(0, currentBalance - amountChange);
      
      await updateDoc(userRef, { walletBalance: newBalance });

      // Record Transaction
      const txRef = doc(transactionsCol);
      await setDoc(txRef, {
        id: txRef.id,
        userId: currentData.email || userId,
        userName: currentData.name,
        type,
        amount: type === 'manual_credit' ? amountChange : -amountChange,
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        status: 'completed',
        referenceNumber: 'ADM-' + Math.floor(100000 + Math.random() * 900000),
        description: `Admin Manual ${type === 'manual_credit' ? 'Credit' : 'Debit'}: ${reason}`
      });

      await logAdminAction(adminEmail, `User Balance ${type === 'manual_credit' ? 'Credit' : 'Debit'}`, `${type} ${amountChange} USD to user ${userId} (${reason})`);
    } else {
      throw new Error('User not found in database.');
    }
  } catch (err) {
    console.error('Balance adjustment failed:', err);
    throw err;
  }
}

export async function deleteUserFromFirestore(userId: string, adminEmail: string) {
  const docRef = doc(db, 'users', userId);
  await deleteDoc(docRef);
  await logAdminAction(adminEmail, 'Delete User', `Deleted user ${userId}`);
}

// NOTIFICATIONS
export async function sendNotificationInFirestore(
  title: string, 
  message: string, 
  type: 'global' | 'user' | 'maintenance', 
  adminEmail: string,
  targetUserId?: string
) {
  const notifRef = doc(notificationsCol);
  const notifObj: NotificationItem = {
    id: notifRef.id,
    title,
    message,
    type,
    createdAt: new Date().toISOString(),
    targetUserId: targetUserId || 'all',
    read: false
  };
  await setDoc(notifRef, notifObj);
  await logAdminAction(adminEmail, 'Send Notification', `Sent ${type} notification: "${title}"`);
  return notifObj;
}

export async function deleteNotificationInFirestore(id: string, adminEmail: string) {
  await deleteDoc(doc(db, 'notifications', id));
  await logAdminAction(adminEmail, 'Delete Notification', `Deleted notification ${id}`);
}
