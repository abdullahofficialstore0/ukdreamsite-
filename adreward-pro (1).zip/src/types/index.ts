export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  phone: string;
  country: string;
  memberSince: string;
  avatar?: string;
  referralCode?: string;
  referredByEmail?: string;
  referredByName?: string;
  referredByCode?: string;
  activeCardId?: string;
  role?: 'user' | 'admin';
  status?: 'active' | 'suspended';
  walletBalance?: number;
  referralEarnings?: number;
  watchedAds?: string[];
  lastWatchDate?: string;
  dailyAdsWatched?: number;
  referralsList?: any[];
  totalAdsWatched?: number;
}

export interface BusinessCard {
  id: 'starter' | 'premium' | 'gold' | 'royal';
  title: string;
  pricePkr: number;
  priceUsd: number;
  color: string;
  cardNumber: string;
  validity: string;
  status: 'unactivated' | 'processing' | 'active';
  trxId?: string;
  senderTitle?: string;
  senderNumber?: string;
  receiptUrl?: string;
  appliedAt?: string;
}

export interface Campaign {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  duration: number; // in seconds
  rewardAmount: number;
  rewardPkr: number;
  remainingAvailability: number;
  category: string;
  videoUrl?: string;
  watched?: boolean;
  status?: 'active' | 'disabled';
  startDate?: string;
  endDate?: string;
}

export interface Transaction {
  id: string;
  userId?: string;
  userName?: string;
  type: 'reward' | 'withdrawal' | 'bonus' | 'adjustment' | 'manual_credit' | 'manual_debit';
  amount: number;
  date: string;
  status: 'completed' | 'pending' | 'rejected' | 'Approved' | 'Rejected';
  referenceNumber: string;
  description: string;
  accountTitle?: string;
  accountNumber?: string;
  method?: string;
  withdrawalId?: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  amountPkr: number;
  amountUsd: number;
  method: string;
  accountTitle: string;
  accountNumber: string;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  requestedAt: string;
  notes?: string;
  trxId?: string;
}

export interface SiteSettings {
  websiteName: string;
  logoUrl?: string;
  bankName: string;
  accountHolderName: string;
  accountNumberIban: string;
  easyPaisaNumber: string;
  jazzCashNumber: string;
  nayaPayNumber: string;
  sadaPayNumber: string;
  paymentInstructions: string;
  minWithdrawal: number; // in PKR
  maxWithdrawal: number; // in PKR
  maintenanceMode: boolean;
  contactEmail: string;
  supportPhone: string;
  announcementBanner: string;
  primaryColor?: string;
  socialFacebook?: string;
  socialTelegram?: string;
  socialWhatsapp?: string;
  socialYoutube?: string;
  socialInstagram?: string;
  socialTiktok?: string;
  fbrCertificateEnabled?: boolean;
  fbrCertificateNumber?: string;
  fbrCertificateImage?: string;
  starterCardPricePkr?: number;
  goldCardPricePkr?: number;
  premiumCardPricePkr?: number;
  royalCardPricePkr?: number;
  specialOfferActive?: boolean;
  specialOfferTitle?: string;
  specialOfferDiscountPercent?: number;
  specialOfferNote?: string;
}

export interface NotificationItem {
  id: string;
  targetUserId?: string; // 'all' or userId
  title: string;
  message: string;
  type: 'global' | 'user' | 'maintenance';
  createdAt: string;
  read?: boolean;
}

export interface AuditLog {
  id: string;
  adminEmail: string;
  action: string;
  timestamp: string;
  details: string;
}

export interface DepositRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  cardId: 'starter' | 'premium' | 'gold' | 'royal';
  cardTitle: string;
  amountPkr: number;
  amountUsd: number;
  senderTitle: string;
  senderNumber: string;
  trxId: string;
  receiptUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedAt?: string;
  adminNotes?: string;
}

export interface AppState {
  user: User | null;
  walletBalance: number;
  lifetimeRewards: number;
  pendingRewards: number;
  todayEarnings: number;
  monthlyEarnings: number;
  totalAdsWatched: number;
  referralEarnings: number;
  theme: 'light' | 'dark';
  notifications: NotificationItem[];
  campaigns: Campaign[];
  transactions: Transaction[];
  businessCards: BusinessCard[];
  siteSettings: SiteSettings;
  withdrawals: WithdrawalRequest[];
  depositRequests: DepositRequest[];
  announcements: any[];
  pkrRate: number;
}
