export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  phone: string;
  country: string;
  memberSince: string;
  avatar?: string;
  referralCode?: string;
}

export interface Campaign {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  duration: number; // in seconds
  rewardAmount: number;
  remainingAvailability: number;
  category: string;
}

export interface Transaction {
  id: string;
  type: 'reward' | 'withdrawal' | 'bonus' | 'adjustment';
  amount: number;
  date: string;
  status: 'completed' | 'pending' | 'rejected';
  referenceNumber: string;
  description: string;
}

export interface RewardHistory {
  id: string;
  campaignId: string;
  campaignTitle: string;
  reward: number;
  date: string;
  status: 'credited' | 'pending';
}

export interface AppState {
  user: User | null;
  walletBalance: number;
  lifetimeRewards: number;
  pendingRewards: number;
  todayEarnings: number;
  monthlyEarnings: number;
  totalAdsWatched: number;
  referralEarnings: number;
  theme: 'light' | 'dark';
  notifications: any[];
  campaigns: Campaign[];
  transactions: Transaction[];
}
