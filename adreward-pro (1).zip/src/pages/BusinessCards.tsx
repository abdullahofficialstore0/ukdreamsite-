import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CreditCard, CheckCircle2, Clock, AlertCircle, ShieldCheck, ArrowRight, Upload, Sparkles, RefreshCw, Smartphone, Check, Building2, Wallet } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { BusinessCard } from '../types';

export function BusinessCards() {
  const { user, businessCards, applyCardActivation, approveCardActivation, siteSettings } = useApp();
  const navigate = useNavigate();
  const [selectedCard, setSelectedCard] = useState<BusinessCard | null>(null);
  
  // Payment Form state
  const [senderTitle, setSenderTitle] = useState('');
  const [senderNumber, setSenderNumber] = useState('');
  const [trxId, setTrxId] = useState('');
  const [receiptFile, setReceiptFile] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [submittedMessage, setSubmittedMessage] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) {
      alert("Screenshot size should be less than 1MB");
      return;
    }

    setUploading(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setReceiptFile(reader.result as string);
      setUploading(false);
    };
    reader.readAsDataURL(file);
  };

  // Active card at the top, others below
  const activeCard = businessCards.find(c => c.status === 'active');
  const processingCards = businessCards.filter(c => c.status === 'processing');

  const getCardPkrPrice = (cardId: string) => {
    let basePkr = 700;
    if (cardId === 'starter') basePkr = siteSettings.starterCardPricePkr ?? 700;
    else if (cardId === 'gold') basePkr = siteSettings.goldCardPricePkr ?? 1400;
    else if (cardId === 'premium') basePkr = siteSettings.premiumCardPricePkr ?? 2100;
    else if (cardId === 'royal') basePkr = siteSettings.royalCardPricePkr ?? 3000;

    if (siteSettings.specialOfferActive && (siteSettings.specialOfferDiscountPercent || 0) > 0) {
      const pct = siteSettings.specialOfferDiscountPercent || 0;
      return Math.round(basePkr * (1 - pct / 100));
    }
    return basePkr;
  };

  const getCardOriginalPkrPrice = (cardId: string) => {
    if (cardId === 'starter') return siteSettings.starterCardPricePkr ?? 700;
    if (cardId === 'gold') return siteSettings.goldCardPricePkr ?? 1400;
    if (cardId === 'premium') return siteSettings.premiumCardPricePkr ?? 2100;
    if (cardId === 'royal') return siteSettings.royalCardPricePkr ?? 3000;
    return 700;
  };

  const handleActivateClick = (card: BusinessCard) => {
    const finalPrice = getCardPkrPrice(card.id);
    setSelectedCard({
      ...card,
      pricePkr: finalPrice,
      priceUsd: Math.round((finalPrice / 280) * 100) / 100
    });
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCard) return;

    applyCardActivation(
      selectedCard.id,
      senderTitle,
      senderNumber,
      trxId,
      receiptFile || undefined
    );

    setSubmittedMessage(true);
    setTimeout(() => {
      setSubmittedMessage(false);
      setSelectedCard(null);
      setSenderTitle('');
      setSenderNumber('');
      setTrxId('');
      setReceiptFile(null);
    }, 2000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-950 rounded-2xl p-6 sm:p-8 text-white relative overflow-hidden shadow-sm border border-slate-800">
        <div className="absolute top-0 right-0 w-72 h-72 bg-blue-500/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/3"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 bg-blue-500/20 border border-blue-400/30 rounded-full text-blue-300 text-[10px] font-bold uppercase tracking-wider mb-2">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              <span>Verified Membership Cards</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight mb-1">Activate Business Card</h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-lg leading-relaxed">
              Select and activate a business card to unlock daily video ad earnings (5 Ads / Day), instant withdrawals, and affiliate rewards.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-xl border border-white/15 text-center shrink-0">
            <span className="text-[10px] uppercase font-bold text-slate-300 block">Current Status</span>
            {activeCard ? (
              <div className="flex items-center space-x-1.5 text-emerald-400 font-bold text-xs mt-0.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>{activeCard.title} Active</span>
              </div>
            ) : processingCards.length > 0 ? (
              <div className="flex items-center space-x-1.5 text-amber-400 font-bold text-xs mt-0.5">
                <Clock className="w-4 h-4 animate-pulse" />
                <span>Pending Review</span>
              </div>
            ) : (
              <div className="flex items-center space-x-1.5 text-red-300 font-bold text-xs mt-0.5">
                <AlertCircle className="w-4 h-4" />
                <span>No Card Activated</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ACTIVE CARD AT TOP */}
      {activeCard && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-emerald-500" />
              <span>Your Active Business Card</span>
            </h2>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-500/20">
              Active & Verified
            </span>
          </div>

          <div className="relative group max-w-md mx-auto sm:mx-0">
            <div className={`p-6 sm:p-8 rounded-3xl bg-gradient-to-tr ${activeCard.color} text-white shadow-2xl relative overflow-hidden border border-white/20`}>
              <div className="flex justify-between items-start mb-8">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-white/70 block">Official Business Card</span>
                  <h3 className="text-xl font-black">{activeCard.title}</h3>
                </div>
                <div className="w-10 h-8 rounded-md bg-amber-400/80 border border-amber-300 flex items-center justify-center font-mono text-[9px] font-bold text-slate-900">
                  CHIP
                </div>
              </div>

              <div className="mb-8">
                <p className="text-[10px] font-mono text-white/60 mb-1">REGISTRATION CARD NO.</p>
                <p className="font-mono text-xl sm:text-2xl font-bold tracking-widest text-white drop-shadow-sm">{activeCard.cardNumber}</p>
              </div>

              <div className="flex justify-between items-end text-xs">
                <div>
                  <p className="text-[9px] uppercase font-bold text-white/60">CARD HOLDER</p>
                  <p className="font-bold uppercase tracking-wide">{user?.name || 'MEMBER'}</p>
                </div>
                <div className="text-right">
                  <p className="text-[9px] uppercase font-bold text-white/60">VALIDITY</p>
                  <p className="font-bold text-emerald-300">LIFETIME</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PENDING / PROCESSING CARDS */}
      {processingCards.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <Clock className="w-5 h-5 text-amber-500 animate-spin" />
            <span>Card Activation Under Processing</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {processingCards.map((card) => (
              <div key={card.id} className="p-6 bg-amber-50/50 dark:bg-amber-500/10 border-2 border-amber-300 dark:border-amber-500/30 rounded-3xl space-y-4 shadow-sm">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider block">Pending Review</span>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">{card.title}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Price: ₨ {card.pricePkr} PKR (${card.priceUsd.toFixed(2)})</p>
                  </div>
                  <span className="px-3 py-1 bg-amber-500 text-white font-bold text-xs rounded-full flex items-center space-x-1 shadow-sm">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Processing</span>
                  </span>
                </div>

                <div className="text-xs space-y-1 bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-amber-200 dark:border-amber-500/20 text-slate-700 dark:text-slate-300">
                  <p><strong>Sender Title:</strong> {card.senderTitle}</p>
                  <p><strong>Sender Number:</strong> {card.senderNumber}</p>
                  <p><strong>TRX ID:</strong> <span className="font-mono text-amber-600 dark:text-amber-400">{card.trxId}</span></p>
                </div>

                <div className="pt-2 border-t border-amber-200/60 dark:border-amber-500/20 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 italic">Submitted for review. Admin will verify your payment shortly.</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SPECIAL DISCOUNT OFFER BANNER */}
      {siteSettings?.specialOfferActive && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 rounded-2xl text-white shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-amber-300/30"
        >
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center shrink-0 border border-white/30">
              <Sparkles className="w-6 h-6 text-yellow-200 animate-spin" />
            </div>
            <div>
              <div className="inline-block px-2.5 py-0.5 bg-black/20 rounded-full text-[10px] font-black uppercase tracking-wider mb-1 text-amber-200">
                🔥 {siteSettings.specialOfferTitle || 'Special Discount Offer'}
              </div>
              <h3 className="text-base sm:text-lg font-black">{siteSettings.specialOfferDiscountPercent}% OFF On All Business Card Activations!</h3>
              <p className="text-xs text-white/90 font-medium">{siteSettings.specialOfferNote || 'Activate your Business Card today to enjoy exclusive discounted registration prices!'}</p>
            </div>
          </div>

          <div className="px-4 py-2 bg-white text-slate-900 font-black text-xs rounded-xl shadow-md shrink-0 self-end sm:self-center">
            Discount Applied Below!
          </div>
        </motion.div>
      )}

      {/* ALL BUSINESS CARDS LIST */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">Business Card Packages</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Choose a card tier according to your budget to start earning daily.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {businessCards.map((card) => {
            const isActive = card.status === 'active';
            const isProcessing = card.status === 'processing';

            const cardPkr = getCardPkrPrice(card.id);
            const origPkr = getCardOriginalPkrPrice(card.id);
            const isDiscounted = siteSettings?.specialOfferActive && cardPkr < origPkr;

            return (
              <motion.div 
                key={card.id}
                whileHover={{ y: -4 }}
                className={`p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#111827] border transition-all shadow-sm flex flex-col justify-between space-y-6 ${
                  isActive 
                    ? 'border-2 border-emerald-500 dark:border-emerald-500/50 shadow-emerald-500/10' 
                    : isProcessing
                    ? 'border-2 border-amber-400 dark:border-amber-500/40'
                    : 'border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-600'
                }`}
              >
                {/* Visual Debit Card Mockup */}
                <div className={`p-6 rounded-2xl bg-gradient-to-br ${card.color} text-white shadow-lg relative overflow-hidden border border-white/20`}>
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <span className="text-[9px] font-bold uppercase tracking-widest text-white/70 block">Business Card</span>
                      <h4 className="text-lg font-black">{card.title}</h4>
                    </div>
                    <CreditCard className="w-7 h-7 text-white/80" />
                  </div>

                  <p className="font-mono text-base font-bold tracking-widest mb-6">{card.cardNumber}</p>

                  <div className="flex justify-between items-end text-xs">
                    <div>
                      <p className="text-[8px] uppercase text-white/60">CARD HOLDER</p>
                      <p className="font-bold uppercase text-xs">{user?.name || 'MEMBER'}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[8px] uppercase text-white/60">REGISTRATION PRICE</p>
                      <div className="flex items-center justify-end space-x-1.5">
                        {isDiscounted && (
                          <span className="line-through text-white/60 text-[10px]">₨ {origPkr}</span>
                        )}
                        <p className="font-black text-sm text-emerald-300">₨ {cardPkr} PKR</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Specs & Details */}
                <div className="space-y-3 flex-1">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-500 dark:text-slate-400">Registration Price:</span>
                    <div className="flex items-center space-x-2">
                      {isDiscounted && (
                        <span className="px-2 py-0.5 bg-amber-500/20 text-amber-600 dark:text-amber-400 text-[10px] font-black rounded-md border border-amber-500/30">
                          {siteSettings.specialOfferDiscountPercent}% OFF
                        </span>
                      )}
                      {isDiscounted && (
                        <span className="line-through text-slate-400 text-xs">₨ {origPkr}</span>
                      )}
                      <span className="font-extrabold text-slate-900 dark:text-white">₨ {cardPkr} PKR</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-500 dark:text-slate-400">Daily Video Ads:</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">5 Ads / Day</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-500 dark:text-slate-400">Reward Per Ad:</span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">₨ {card.id === 'starter' ? 50 : card.id === 'gold' ? 70 : card.id === 'premium' ? 85 : 95} PKR</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-500 dark:text-slate-400">Validity:</span>
                    <span className="font-bold text-slate-900 dark:text-white">Lifetime</span>
                  </div>
                </div>

                {/* Status Button */}
                <div>
                  {isActive ? (
                    <button 
                      disabled
                      className="w-full py-3.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold rounded-2xl border border-emerald-500/20 flex items-center justify-center space-x-2 cursor-default"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      <span>Card Active</span>
                    </button>
                  ) : isProcessing ? (
                    <button 
                      disabled
                      className="w-full py-3.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 font-bold rounded-2xl border border-amber-500/20 flex items-center justify-center space-x-2 cursor-default"
                    >
                      <Clock className="w-5 h-5 animate-spin" />
                      <span>Processing Activation</span>
                    </button>
                  ) : (
                    <button 
                      onClick={() => handleActivateClick(card)}
                      className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center space-x-2 group"
                    >
                      <span>Activate Card (₨ {card.pricePkr})</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* ACTIVATION MODAL / DEPOSIT INSTRUCTIONS */}
      <AnimatePresence>
        {selectedCard && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-8"
            >
              <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider block">Card Activation Request</span>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white">{selectedCard.title}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Total Deposit Amount: <strong className="text-emerald-600 font-bold text-sm">₨ {selectedCard.pricePkr} PKR</strong></p>
                </div>
                <button 
                  onClick={() => setSelectedCard(null)}
                  className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center font-bold text-sm"
                >
                  ✕
                </button>
              </div>

              {submittedMessage ? (
                <div className="py-8 text-center space-y-3">
                  <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <h4 className="text-xl font-bold text-slate-900 dark:text-white">Deposit Submitted Successfully!</h4>
                  <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
                    Your card activation application is now under processing. It will be verified shortly by the admin team.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleDepositSubmit} className="space-y-5">
                  {/* Bank & Mobile Account Details Box */}
                  <div className="p-4 bg-emerald-50/80 dark:bg-emerald-500/10 border-2 border-emerald-300 dark:border-emerald-500/30 rounded-2xl space-y-3">
                    <div className="flex items-center space-x-2 text-emerald-700 dark:text-emerald-300 font-bold text-sm">
                      <Smartphone className="w-5 h-5 text-emerald-600" />
                      <span>Official Deposit Accounts</span>
                    </div>

                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                      {siteSettings.paymentInstructions || 'Transfer exact package price to any account below and paste your Transaction TRX ID.'}
                    </p>

                    <div className="text-xs space-y-2 text-slate-700 dark:text-slate-300 pt-1">
                      {siteSettings.easyPaisaNumber && (
                        <div className="flex justify-between border-b border-emerald-200 dark:border-emerald-500/20 pb-1">
                          <span className="text-slate-500">EasyPaisa:</span>
                          <span className="font-mono font-bold text-emerald-700 dark:text-emerald-300">{siteSettings.easyPaisaNumber} ({siteSettings.accountHolderName})</span>
                        </div>
                      )}
                      {siteSettings.jazzCashNumber && (
                        <div className="flex justify-between border-b border-emerald-200 dark:border-emerald-500/20 pb-1">
                          <span className="text-slate-500">JazzCash:</span>
                          <span className="font-mono font-bold text-red-600 dark:text-red-400">{siteSettings.jazzCashNumber} ({siteSettings.accountHolderName})</span>
                        </div>
                      )}
                      {siteSettings.bankName && (
                        <div className="flex justify-between border-b border-emerald-200 dark:border-emerald-500/20 pb-1">
                          <span className="text-slate-500">{siteSettings.bankName}:</span>
                          <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{siteSettings.accountNumberIban} ({siteSettings.accountHolderName})</span>
                        </div>
                      )}
                      {siteSettings.sadaPayNumber && (
                        <div className="flex justify-between border-b border-emerald-200 dark:border-emerald-500/20 pb-1">
                          <span className="text-slate-500">SadaPay:</span>
                          <span className="font-mono font-bold text-amber-600 dark:text-amber-400">{siteSettings.sadaPayNumber}</span>
                        </div>
                      )}
                      {siteSettings.nayaPayNumber && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">NayaPay:</span>
                          <span className="font-mono font-bold text-teal-600 dark:text-teal-400">{siteSettings.nayaPayNumber}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Inputs */}
                  <div className="space-y-3 text-left">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Sender Account Title (Name)
                      </label>
                      <input 
                        type="text" 
                        required
                        value={senderTitle}
                        onChange={(e) => setSenderTitle(e.target.value)}
                        placeholder="e.g. Ali Raza"
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl outline-none text-sm text-slate-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Sender Mobile / Account Number
                      </label>
                      <input 
                        type="text" 
                        required
                        value={senderNumber}
                        onChange={(e) => setSenderNumber(e.target.value)}
                        placeholder="0300XXXXXXX"
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl outline-none text-sm text-slate-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Transaction ID (TRX ID)
                      </label>
                      <input 
                        type="text" 
                        required
                        value={trxId}
                        onChange={(e) => setTrxId(e.target.value)}
                        placeholder="e.g. 8492019482"
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl outline-none text-sm font-mono text-slate-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Payment Screenshot / Receipt
                      </label>
                      <div className="relative">
                        <input 
                          type="file" 
                          id="screenshot"
                          accept="image/*"
                          onChange={handleFileChange}
                          className="hidden"
                          required={!receiptFile}
                        />
                        <label 
                          htmlFor="screenshot"
                          className={`w-full px-3.5 py-4 bg-slate-50 dark:bg-white/5 border-2 border-dashed rounded-xl flex flex-col items-center justify-center cursor-pointer transition-all ${
                            receiptFile ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-slate-200 dark:border-slate-700 hover:border-blue-500/50'
                          }`}
                        >
                          {uploading ? (
                            <div className="flex flex-col items-center space-y-2">
                              <RefreshCw className="w-6 h-6 text-blue-500 animate-spin" />
                              <span className="text-[10px] text-slate-500">Processing...</span>
                            </div>
                          ) : receiptFile ? (
                            <div className="flex flex-col items-center space-y-2 text-center">
                              <div className="relative w-16 h-16 rounded-lg overflow-hidden border border-emerald-500/30">
                                <img src={receiptFile} alt="Receipt" className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-emerald-500/20 flex items-center justify-center">
                                  <Check className="w-6 h-6 text-white" />
                                </div>
                              </div>
                              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">Screenshot Attached</span>
                              <span className="text-[9px] text-slate-400">Click to change</span>
                            </div>
                          ) : (
                            <>
                              <Upload className="w-6 h-6 text-slate-400 mb-2" />
                              <span className="text-[10px] font-bold text-slate-500">Upload Screenshot (Max 1MB)</span>
                              <span className="text-[9px] text-slate-400">Capture your payment success screen</span>
                            </>
                          )}
                        </label>
                      </div>
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-lg shadow-emerald-500/20 transition-all text-sm flex items-center justify-center space-x-2"
                  >
                    <span>Submit Activation Request</span>
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
