import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Building2, CreditCard, Wallet, ArrowRight, CheckCircle2, Calculator, RefreshCw, Clock, AlertTriangle, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import confetti from 'canvas-confetti';

export function Withdraw() {
  const { walletBalance, submitWithdrawal, siteSettings, pkrRate: exchangeRate } = useApp();
  const [method, setMethod] = useState('easypaisa');
  const [amount, setAmount] = useState('');
  const [calcUsd, setCalcUsd] = useState('1.00');
  const [accountTitle, setAccountTitle] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');
  const [alertNotice, setAlertNotice] = useState<{ title: string; message: string } | null>(null);

  // Minimum withdrawal fixed at $0.36 USD (≈ ₨ 100 PKR)
  const minWithdrawalUsd = 0.36;
  const minWithdrawalPkr = Math.round(minWithdrawalUsd * exchangeRate) || 100;

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    const valUsd = parseFloat(amount);

    if (isNaN(valUsd) || valUsd <= 0) {
      setAlertNotice({
        title: 'Invalid Amount',
        message: 'Please enter a valid withdrawal amount in USD.'
      });
      return;
    }

    // STRICT CHECK: Minimum withdrawal is $0.36 USD
    if (valUsd < minWithdrawalUsd) {
      const msg = `Minimum withdrawal amount is $${minWithdrawalUsd.toFixed(2)} USD (₨ ${minWithdrawalPkr} PKR). You cannot request a withdrawal for less than $${minWithdrawalUsd.toFixed(2)} USD.`;
      setAlertNotice({
        title: 'Minimum Withdrawal Limit Notice',
        message: msg
      });
      try {
        alert(`⚠️ ALERT: ${msg}`);
      } catch (e) {}
      return;
    }

    // CHECK: Balance sufficiency
    if (valUsd > walletBalance) {
      const msg = `Insufficient balance! Your current available balance is $${walletBalance.toFixed(2)} USD. You cannot withdraw more than your available balance.`;
      setAlertNotice({
        title: 'Insufficient Wallet Balance',
        message: msg
      });
      try {
        alert(`⚠️ BALANCE ALERT: ${msg}`);
      } catch (e) {}
      return;
    }

    setStatus('loading');

    const valPkr = Number((valUsd * exchangeRate).toFixed(0));
    const success = await submitWithdrawal(valUsd, valPkr, method, accountTitle, accountNumber);

    if (success) {
      setStatus('success');
    } else {
      setStatus('idle');
      setAlertNotice({
        title: 'Withdrawal Failed',
        message: 'Failed to process withdrawal request. Please check your account details and wallet balance.'
      });
    }
  };

  useEffect(() => {
    if (status === 'success') {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10B981', '#3B82F6', '#F59E0B']
      });
    }
  }, [status]);

  // Calculated values for currency converter
  const parsedCalcUsd = parseFloat(calcUsd) || 0;
  const pkrEquivalent = (parsedCalcUsd * exchangeRate).toFixed(2);

  const parsedWithdrawalUsd = parseFloat(amount) || 0;
  const pkrWithdrawalTotal = (parsedWithdrawalUsd * exchangeRate).toFixed(2);
  const isBelowMin = parsedWithdrawalUsd > 0 && parsedWithdrawalUsd < minWithdrawalUsd;

  if (status === 'success') {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md mx-auto mt-10 p-8 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 text-center shadow-xl"
      >
        <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Withdrawal Submitted</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-2">Your request for <strong>${parseFloat(amount).toFixed(2)} USD</strong> (≈ ₨ {pkrWithdrawalTotal} PKR) is submitted to admin for approval.</p>
        <p className="text-xs text-slate-400 mb-8">Minimum withdrawal requirement: ₨ {minWithdrawalPkr} PKR (${minWithdrawalUsd.toFixed(2)} USD).</p>
        <button 
          onClick={() => { setStatus('idle'); setAmount(''); setAccountTitle(''); setAccountNumber(''); }}
          className="w-full py-3 bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-slate-900 dark:text-white font-medium rounded-xl transition-colors cursor-pointer"
        >
          Make another withdrawal
        </button>
      </motion.div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-10 relative">
      {/* Instant Custom Alert Modal */}
      <AnimatePresence>
        {alertNotice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="w-full max-w-md bg-slate-900 border border-red-500/40 rounded-3xl p-6 text-center space-y-4 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-red-500 via-amber-500 to-red-500"></div>
              <button 
                onClick={() => setAlertNotice(null)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="w-16 h-16 bg-red-500/20 border border-red-500/40 text-red-400 rounded-full flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(239,68,68,0.3)]">
                <AlertTriangle className="w-8 h-8 animate-bounce" />
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-black text-white">{alertNotice.title}</h3>
                <p className="text-sm text-slate-300 leading-relaxed font-medium bg-red-950/40 p-4 rounded-2xl border border-red-500/20">
                  {alertNotice.message}
                </p>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setAlertNotice(null)}
                  className="w-full py-3.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-extrabold text-sm rounded-xl shadow-lg transition-all active:scale-95 cursor-pointer"
                >
                  Understood & Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 sm:p-6 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-start space-x-4"
      >
        <div className="p-3 bg-amber-500/20 rounded-xl">
          <Clock className="w-6 h-6 text-amber-500 animate-pulse" />
        </div>
        <div>
          <h4 className="font-black text-amber-500 text-sm uppercase tracking-wider mb-1">Official Withdrawal Notice</h4>
          <p className="text-slate-700 dark:text-slate-300 text-xs sm:text-sm leading-relaxed">
            Withdrawal processing is active daily between <strong className="text-amber-600 dark:text-amber-400">6:00 PM and 8:30 PM (PKT)</strong>. 
            Minimum withdrawal limit is strictly <strong className="text-emerald-500">$0.36 USD (₨ {minWithdrawalPkr} PKR)</strong>.
          </p>
        </div>
      </motion.div>

      <div>
        <div className="flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-bold text-xs uppercase tracking-widest mb-1">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Instant Processing • Minimum $0.36 USD (₨ {minWithdrawalPkr} PKR)</span>
        </div>
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Withdraw Funds</h2>
        <p className="text-slate-500 dark:text-slate-400">Transfer your earnings to Meezan Bank, EasyPaisa, JazzCash, SadaPay, or NayaPay.</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button 
          type="button"
          onClick={() => setMethod('easypaisa')}
          className={`p-4 rounded-2xl border-2 transition-all text-left cursor-pointer ${
            method === 'easypaisa' 
              ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-500/10' 
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] hover:border-emerald-300 dark:hover:border-emerald-500/50'
          }`}
        >
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${
            method === 'easypaisa' ? 'bg-emerald-500 text-white shadow-lg' : 'bg-slate-100 dark:bg-white/5 text-slate-500'
          }`}>
            <Wallet className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">EasyPaisa</h3>
          <p className="text-[10px] text-slate-500">{siteSettings.easyPaisaNumber || '0300 1234567'}</p>
        </button>

        <button 
          type="button"
          onClick={() => setMethod('jazzcash')}
          className={`p-4 rounded-2xl border-2 transition-all text-left cursor-pointer ${
            method === 'jazzcash' 
              ? 'border-red-500 bg-red-50/50 dark:bg-red-500/10' 
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] hover:border-red-300 dark:hover:border-red-500/50'
          }`}
        >
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${
            method === 'jazzcash' ? 'bg-red-500 text-white shadow-lg' : 'bg-slate-100 dark:bg-white/5 text-slate-500'
          }`}>
            <CreditCard className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Jazz Cash</h3>
          <p className="text-[10px] text-slate-500">{siteSettings.jazzCashNumber || '0301 7654321'}</p>
        </button>

        <button 
          type="button"
          onClick={() => setMethod('meezan')}
          className={`p-4 rounded-2xl border-2 transition-all text-left cursor-pointer ${
            method === 'meezan' 
              ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-500/10' 
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] hover:border-blue-300 dark:hover:border-blue-500/50'
          }`}
        >
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${
            method === 'meezan' ? 'bg-blue-500 text-white shadow-lg' : 'bg-slate-100 dark:bg-white/5 text-slate-500'
          }`}>
            <Building2 className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">{siteSettings.bankName || 'Meezan Bank'}</h3>
          <p className="text-[10px] text-slate-500">Bank Transfer</p>
        </button>

        <button 
          type="button"
          onClick={() => setMethod('sadapay')}
          className={`p-4 rounded-2xl border-2 transition-all text-left cursor-pointer ${
            method === 'sadapay' 
              ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-500/10' 
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] hover:border-amber-300 dark:hover:border-amber-500/50'
          }`}
        >
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${
            method === 'sadapay' ? 'bg-amber-500 text-white shadow-lg' : 'bg-slate-100 dark:bg-white/5 text-slate-500'
          }`}>
            <Wallet className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">SadaPay / NayaPay</h3>
          <p className="text-[10px] text-slate-500">Wallet Transfer</p>
        </button>
      </div>

      {/* USD to PKR Calculator & Converter Tool */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-900 to-slate-900 text-white shadow-lg border border-indigo-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 blur-2xl rounded-full"></div>
        <div className="flex items-center justify-between mb-4 relative z-10">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-white/10 backdrop-blur-md">
              <Calculator className="w-5 h-5 text-indigo-300" />
            </div>
            <h3 className="font-bold text-lg text-white">USD to PKR Converter</h3>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
            Live Rate: 1 USD = ₨ {exchangeRate} PKR
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
          <div>
            <label className="block text-xs font-semibold text-indigo-200 mb-1">Enter USD Amount ($)</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-indigo-300 font-bold">$</span>
              <input 
                type="number"
                value={calcUsd}
                onChange={(e) => setCalcUsd(e.target.value)}
                step="0.01"
                min="0.01"
                placeholder="1.00"
                className="w-full pl-8 pr-3 py-2.5 bg-white/10 border border-white/20 rounded-xl outline-none font-bold text-white text-lg focus:border-indigo-400 transition-all"
              />
            </div>
          </div>

          <div className="flex flex-col justify-center bg-white/5 border border-white/10 p-3 rounded-xl">
            <span className="text-xs text-indigo-200">Estimated Payout in PKR:</span>
            <span className="text-2xl font-black text-emerald-400">₨ {pkrEquivalent} PKR</span>
            <span className="text-[10px] text-slate-300">Fee: ₨ 0.00 (Free payout transfer)</span>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between pt-3 border-t border-white/10 text-xs">
          <span className="text-indigo-200">Convert your USD earnings directly before submitting request.</span>
          <button 
            type="button"
            onClick={() => setAmount(calcUsd)}
            className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white font-bold rounded-lg transition-colors flex items-center space-x-1 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Apply to Withdrawal</span>
          </button>
        </div>
      </div>

      {/* Withdrawal Submission Form */}
      <div className="p-6 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm">
        <form onSubmit={handleWithdraw} className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Amount to Withdraw (USD)</label>
              <span className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                Min: $0.36 USD
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl text-slate-400 font-bold">$</span>
              <input 
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.36"
                step="0.01"
                required
                className={`w-full pl-12 pr-4 py-4 text-2xl font-bold bg-slate-50 dark:bg-white/5 border rounded-xl outline-none text-slate-900 dark:text-white transition-all placeholder:text-slate-300 dark:placeholder:text-slate-700 ${
                  isBelowMin 
                    ? 'border-red-500/80 focus:ring-2 focus:ring-red-500 bg-red-50/20 dark:bg-red-500/5' 
                    : 'border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500'
                }`}
              />
            </div>

            {/* In-place alert warning banner if below $0.36 USD */}
            {isBelowMin && (
              <motion.div 
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-2.5 p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center space-x-2 text-xs font-extrabold text-red-500 dark:text-red-400"
              >
                <AlertTriangle className="w-4 h-4 shrink-0 animate-bounce" />
                <span>Minimum withdrawal amount is $0.36 USD (₨ {minWithdrawalPkr} PKR). Please enter at least $0.36 USD.</span>
              </motion.div>
            )}
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-2 gap-2">
              <div className="text-sm text-slate-500 dark:text-slate-400 flex items-center space-x-2">
                <span>Available: <strong>${walletBalance.toFixed(2)}</strong></span>
                {parsedWithdrawalUsd > 0 && (
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                    (≈ ₨ {pkrWithdrawalTotal} PKR)
                  </span>
                )}
              </div>
              <button 
                type="button" 
                onClick={() => setAmount(walletBalance > 0 ? walletBalance.toString() : minWithdrawalUsd.toString())}
                className="text-sm font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                Max Amount
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Account Holder Name (Title)</label>
              <input 
                type="text" 
                value={accountTitle}
                onChange={(e) => setAccountTitle(e.target.value)}
                placeholder="e.g. Muhammad Ali" 
                required 
                className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                {method === 'meezan' ? 'IBAN / Bank Account Number' : 'Mobile Number / Account ID'}
              </label>
              <input 
                type="text" 
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder={method === 'meezan' ? 'PK36MEZN000...' : '03001234567'} 
                required 
                className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white" 
              />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={status === 'loading' || !amount}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 dark:disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/20 disabled:shadow-none transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:cursor-not-allowed"
          >
            {status === 'loading' ? (
              <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              <>
                <span>Submit Withdrawal Request</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}

