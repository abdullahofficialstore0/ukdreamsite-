import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Building2, CreditCard, Wallet, ArrowRight, CheckCircle2, Calculator, RefreshCw } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import confetti from 'canvas-confetti';

export function Withdraw() {
  const { walletBalance, deductBalance } = useApp();
  const [method, setMethod] = useState('meezan');
  const [amount, setAmount] = useState('');
  const [calcUsd, setCalcUsd] = useState('1.00');
  const [exchangeRate, setExchangeRate] = useState(278.50);
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');
  
  const minWithdrawal = 0.01;

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (val < minWithdrawal) return;
    
    setStatus('loading');
    setTimeout(() => {
      if (walletBalance >= val) {
        deductBalance(val);
      } else if (walletBalance > 0) {
        deductBalance(walletBalance);
      }
      setStatus('success');
    }, 1500);
  };

  useEffect(() => {
    if (status === 'success') {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10B981', '#3B82F6', '#F59E0B']
      });
    }
  }, [status]);

  // Calculated values for currency converter
  const parsedCalcUsd = parseFloat(calcUsd) || 0;
  const pkrEquivalent = (parsedCalcUsd * exchangeRate).toFixed(2);

  const parsedWithdrawalUsd = parseFloat(amount) || 0;
  const pkrWithdrawalTotal = (parsedWithdrawalUsd * exchangeRate).toFixed(2);

  if (status === 'success') {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md mx-auto mt-10 p-8 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 text-center shadow-xl"
      >
        <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Withdrawal Submitted</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-2">Your request for <strong>${parseFloat(amount).toFixed(2)} USD</strong> (Approx ₨ {pkrWithdrawalTotal} PKR) is being processed.</p>
        <p className="text-xs text-slate-400 mb-8">Minimum withdrawal requirement: $0.01 USD across all payment channels.</p>
        <button 
          onClick={() => { setStatus('idle'); setAmount(''); }}
          className="w-full py-3 bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-slate-900 dark:text-white font-medium rounded-xl transition-colors"
        >
          Make another withdrawal
        </button>
      </motion.div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div>
        <div className="flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-bold text-xs uppercase tracking-widest mb-1">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Instant Processing • Min $0.01</span>
        </div>
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Withdraw Funds</h2>
        <p className="text-slate-500 dark:text-slate-400">Transfer your earnings to Meezan Bank, EasyPaisa, or JazzCash instantly with minimum $0.01 requirement.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button 
          type="button"
          onClick={() => setMethod('meezan')}
          className={`p-5 rounded-2xl border-2 transition-all text-left ${
            method === 'meezan' 
              ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-500/10' 
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] hover:border-blue-300 dark:hover:border-blue-500/50'
          }`}
        >
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
            method === 'meezan' ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/30' : 'bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400'
          }`}>
            <Building2 className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white mb-1">Meezan Bank</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">1-2 business days. Min $0.01</p>
        </button>

        <button 
          type="button"
          onClick={() => setMethod('easypaisa')}
          className={`p-5 rounded-2xl border-2 transition-all text-left ${
            method === 'easypaisa' 
              ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-500/10' 
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] hover:border-emerald-300 dark:hover:border-emerald-500/50'
          }`}
        >
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
            method === 'easypaisa' ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30' : 'bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400'
          }`}>
            <Wallet className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white mb-1">EasyPaisa</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">Instant transfer. Min $0.01</p>
        </button>

        <button 
          type="button"
          onClick={() => setMethod('jazzcash')}
          className={`p-5 rounded-2xl border-2 transition-all text-left ${
            method === 'jazzcash' 
              ? 'border-red-500 bg-red-50/50 dark:bg-red-500/10' 
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] hover:border-red-300 dark:hover:border-red-500/50'
          }`}
        >
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
            method === 'jazzcash' ? 'bg-red-500 text-white shadow-lg shadow-red-500/30' : 'bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400'
          }`}>
            <CreditCard className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white mb-1">Jazz Cash</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">Instant transfer. Min $0.01</p>
        </button>
      </div>

      {/* USD to PKR Calculator & Converter Tool */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-900 to-slate-900 text-white shadow-lg border border-indigo-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 blur-2xl rounded-full"></div>
        <div className="flex items-center justify-between mb-4 relative z-10">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-white/10 backdrop-blur-md">
              <Calculator className="w-5 h-5 text-indigo-300" />
            </div>
            <h3 className="font-bold text-lg text-white">USD to PKR Converter</h3>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
            Live Rate: 1 USD = ₨ {exchangeRate} PKR
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
          <div>
            <label className="block text-xs font-semibold text-indigo-200 mb-1">Enter USD Amount ($)</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-indigo-300 font-bold">$</span>
              <input 
                type="number"
                value={calcUsd}
                onChange={(e) => setCalcUsd(e.target.value)}
                step="0.01"
                min="0.01"
                placeholder="1.00"
                className="w-full pl-8 pr-3 py-2.5 bg-white/10 border border-white/20 rounded-xl outline-none font-bold text-white text-lg focus:border-indigo-400 transition-all"
              />
            </div>
          </div>

          <div className="flex flex-col justify-center bg-white/5 border border-white/10 p-3 rounded-xl">
            <span className="text-xs text-indigo-200">Estimated Payout in PKR:</span>
            <span className="text-2xl font-black text-emerald-400">₨ {pkrEquivalent} PKR</span>
            <span className="text-[10px] text-slate-300">Fee: ₨ 0.00 (Free payout transfer)</span>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between pt-3 border-t border-white/10 text-xs">
          <span className="text-indigo-200">Convert your USD earnings directly before submitting request.</span>
          <button 
            type="button"
            onClick={() => setAmount(calcUsd)}
            className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white font-bold rounded-lg transition-colors flex items-center space-x-1"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Apply to Withdrawal</span>
          </button>
        </div>
      </div>

      {/* Withdrawal Submission Form */}
      <div className="p-6 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm">
        <form onSubmit={handleWithdraw} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Amount to Withdraw (USD)</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl text-slate-400 font-bold">$</span>
              <input 
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.01"
                min={minWithdrawal}
                step="0.01"
                required
                className="w-full pl-12 pr-4 py-4 text-2xl font-bold bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-slate-900 dark:text-white transition-all placeholder:text-slate-300 dark:placeholder:text-slate-700"
              />
            </div>
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-2 gap-2">
              <div className="text-sm text-slate-500 dark:text-slate-400 flex items-center space-x-2">
                <span>Available: <strong>${walletBalance.toFixed(2)}</strong></span>
                {parsedWithdrawalUsd > 0 && (
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                    (≈ ₨ {pkrWithdrawalTotal} PKR)
                  </span>
                )}
              </div>
              <button 
                type="button" 
                onClick={() => setAmount(walletBalance > 0 ? walletBalance.toString() : '0.01')}
                className="text-sm font-bold text-blue-600 dark:text-blue-400 hover:underline"
              >
                Max Amount
              </button>
            </div>
          </div>
          
          {method === 'meezan' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Account Title</label>
                <input type="text" placeholder="e.g. Muhammad Ali" required className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">IBAN Number / Account Number</label>
                <input type="text" placeholder="PK..." required className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white" />
              </div>
            </div>
          )}

          {(method === 'easypaisa' || method === 'jazzcash') && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Account Holder Name</label>
                <input type="text" placeholder="e.g. Ahmed Raza" required className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Mobile Number ({method === 'easypaisa' ? 'EasyPaisa' : 'JazzCash'})</label>
                <input type="tel" placeholder="03XXXXXXXXX" required className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white" />
              </div>
            </div>
          )}

          <button 
            type="submit" 
            disabled={status === 'loading' || !amount || parseFloat(amount) < minWithdrawal}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 dark:disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/20 disabled:shadow-none transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:cursor-not-allowed"
          >
            {status === 'loading' ? (
              <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              <>
                <span>Submit Withdrawal Request</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
