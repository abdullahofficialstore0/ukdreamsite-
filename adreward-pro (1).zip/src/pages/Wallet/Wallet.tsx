import React from 'react';
import { motion } from 'motion/react';
import { Wallet as WalletIcon, ArrowUpRight, ArrowDownRight, Clock, Building2, CreditCard, History } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Link } from 'react-router-dom';

export function Wallet() {
  const { walletBalance, lifetimeRewards, pendingRewards, transactions } = useApp();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Wallet</h2>
          <p className="text-slate-500 dark:text-slate-400">Manage your earnings and withdrawals.</p>
        </div>
        <Link to="/wallet/withdraw" className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl transition-colors shadow-lg shadow-blue-500/20 flex items-center justify-center space-x-2">
          <ArrowUpRight className="w-5 h-5" />
          <span>Withdraw Funds</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Balance Card */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="lg:col-span-2 relative overflow-hidden rounded-3xl bg-gradient-to-tr from-slate-900 to-slate-800 dark:from-[#0a0f1c] dark:to-[#111827] p-8 text-white border border-slate-700 dark:border-slate-800 shadow-xl"
        >
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <WalletIcon className="w-48 h-48 transform rotate-12" />
          </div>
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center backdrop-blur-md">
                  <WalletIcon className="w-5 h-5 text-blue-400" />
                </div>
                <span className="font-medium text-slate-300">Available Balance</span>
              </div>
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-bold rounded-full border border-emerald-500/20">Active</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl font-bold tracking-tight mb-2">
              <span className="text-slate-400 font-normal mr-1">$</span>
              {walletBalance.toFixed(2)}
            </h1>
            <p className="text-slate-400 mb-8">{walletBalance > 0 ? '+12.5% from last month' : 'Start earning today!'}</p>
            
            <div className="grid grid-cols-2 gap-4 border-t border-slate-700 pt-6">
              <div>
                <p className="text-sm text-slate-400 mb-1">Lifetime Earnings</p>
                <p className="text-xl font-bold text-white">${lifetimeRewards.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-1">Pending Rewards</p>
                <p className="text-xl font-bold text-amber-400">${pendingRewards.toFixed(2)}</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Quick Actions */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Withdrawal Methods</h3>
          <div className="grid grid-cols-2 lg:grid-cols-1 gap-4">
            <button className="flex items-center space-x-4 p-4 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 hover:border-blue-500/50 dark:hover:border-blue-500/50 transition-colors group text-left">
              <div className="w-12 h-12 rounded-xl bg-slate-50 dark:bg-white/5 flex items-center justify-center group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 transition-colors">
                <Building2 className="w-6 h-6 text-slate-600 dark:text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">Bank Transfer</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">2-3 business days</p>
              </div>
            </button>
            
            <button className="flex items-center space-x-4 p-4 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 hover:border-blue-500/50 dark:hover:border-blue-500/50 transition-colors group text-left">
              <div className="w-12 h-12 rounded-xl bg-slate-50 dark:bg-white/5 flex items-center justify-center group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 transition-colors">
                <CreditCard className="w-6 h-6 text-slate-600 dark:text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">PayPal</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">Instant transfer</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden"
      >
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <History className="w-5 h-5 text-slate-400" />
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Recent Transactions</h3>
          </div>
          {transactions.length > 0 && (
            <Link to="/history" className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline">View All</Link>
          )}
        </div>
        
        {transactions.length === 0 ? (
          <div className="p-12 text-center flex flex-col items-center">
            <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
              <History className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">No transaction history</h3>
            <p className="text-slate-500 dark:text-slate-400 mb-6">You haven't made any transactions yet. Watch campaigns to earn rewards.</p>
            <Link to="/campaigns" className="px-6 py-2 bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-semibold rounded-lg hover:bg-blue-100 dark:hover:bg-blue-500/20 transition-colors">
              Find Campaigns
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {transactions.slice(0, 5).map((tx) => (
              <div key={tx.id} className="p-4 sm:p-6 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    tx.type === 'reward' || tx.type === 'bonus' 
                      ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                      : 'bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400'
                  }`}>
                    {tx.type === 'reward' || tx.type === 'bonus' ? <ArrowDownRight className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900 dark:text-white">{tx.description}</h4>
                    <div className="flex items-center space-x-1 text-xs text-slate-500 dark:text-slate-400 mt-1">
                      <Clock className="w-3 h-3" />
                      <span>{tx.date}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`font-bold ${tx.amount > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-900 dark:text-white'}`}>
                    {tx.amount > 0 ? '+' : ''}{tx.amount.toFixed(2)}
                  </span>
                  <span className="block text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase">
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
}
