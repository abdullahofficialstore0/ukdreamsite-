import React from 'react';
import { User, Mail, Phone, Globe, Calendar, Camera, Shield, LogOut } from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';

export function Profile() {
  const { user, setUser } = useApp();
  const navigate = useNavigate();

  const handleLogout = () => {
    setUser(null);
    navigate('/auth');
  };

  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto pb-24">
      {/* Premium Header Profile */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative mb-8 rounded-[2.5rem] overflow-hidden bg-[#111827] border border-slate-800 shadow-2xl"
      >
        <div className="absolute top-0 left-0 w-full h-48 bg-gradient-to-r from-blue-600 to-indigo-900 opacity-20"></div>
        <div className="absolute top-0 left-0 w-full h-48 overflow-hidden">
           <div className="absolute top-[-50%] left-[-10%] w-[60%] h-[200%] bg-blue-500/10 blur-[100px] rounded-full rotate-12" />
        </div>
        
        <div className="relative z-10 px-8 pt-24 pb-8 flex flex-col md:flex-row items-center md:items-end space-y-6 md:space-y-0 md:space-x-8">
          <div className="relative group">
            <div className="w-40 h-40 rounded-[2.5rem] bg-slate-900 border-4 border-[#0a0f1c] shadow-2xl overflow-hidden flex items-center justify-center">
              {user.avatar ? (
                <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="w-20 h-20 text-slate-700" />
              )}
            </div>
            <button className="absolute bottom-2 right-2 p-3 bg-blue-600 text-white rounded-2xl shadow-xl hover:bg-blue-700 transition-all active:scale-95">
              <Camera className="w-5 h-5" />
            </button>
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <div className={`inline-flex items-center space-x-2 px-3 py-1 ${useApp().hasActiveCard ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-slate-500/10 border-slate-500/20 text-slate-400'} border rounded-full text-[10px] font-black uppercase tracking-widest mb-3`}>
              <Shield className="w-3.5 h-3.5" />
              <span>{useApp().hasActiveCard ? 'Verified VIP Member' : 'Free Member'}</span>
            </div>
            <h2 className="text-4xl font-black text-white tracking-tighter mb-1">{user.name}</h2>
            <p className="text-slate-400 font-bold">@{user.username}</p>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-4 mt-6">
              <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-slate-300 font-bold">Joined {user.memberSince}</span>
              </div>
              <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl flex items-center space-x-2">
                <Globe className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-slate-300 font-bold">{user.country}</span>
              </div>
            </div>
          </div>

          <button 
            onClick={handleLogout}
            className="px-6 py-4 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-black text-xs uppercase tracking-widest rounded-2xl border border-red-500/20 transition-all flex items-center space-x-2"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="p-8 sm:p-10 rounded-[2.5rem] bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-xl"
          >
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tighter">Account Settings</h3>
              <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center">
                <User className="w-5 h-5 text-blue-500" />
              </div>
            </div>
            
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Full Identity Name</label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="text" defaultValue={user.name} className="w-full pl-11 pr-4 py-3.5 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:border-blue-500 outline-none text-slate-900 dark:text-white transition-all font-bold" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Network Handle</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black">@</span>
                    <input type="text" defaultValue={user.username} className="w-full pl-10 pr-4 py-3.5 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:border-blue-500 outline-none text-slate-900 dark:text-white transition-all font-bold" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Communication Email</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="email" defaultValue={user.email} className="w-full pl-11 pr-4 py-3.5 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:border-blue-500 outline-none text-slate-900 dark:text-white transition-all font-bold" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Primary Phone</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="tel" defaultValue={user.phone} className="w-full pl-11 pr-4 py-3.5 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:border-blue-500 outline-none text-slate-900 dark:text-white transition-all font-bold" />
                  </div>
                </div>
              </div>

              <div className="pt-8 flex items-center justify-end">
                <button type="submit" className="px-10 py-4 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-blue-500/20 transition-all active:scale-95">
                  Update Security Profile
                </button>
              </div>
            </form>
          </motion.div>
        </div>

        <div className="space-y-8">
           <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="p-8 rounded-[2.5rem] bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-2xl relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 blur-2xl rounded-full -translate-y-1/2 translate-x-1/2 group-hover:bg-white/20 transition-all duration-700" />
            <h4 className="text-xs font-black uppercase tracking-widest mb-4 opacity-80">Security Status</h4>
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xl font-black tracking-tighter">Level 2 Secure</p>
                <p className="text-[10px] font-bold opacity-70 uppercase tracking-wider">Two-Factor Enabled</p>
              </div>
            </div>
            <button className="w-full py-3 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all">
              Security Audit
            </button>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="p-8 rounded-[2.5rem] bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-xl"
          >
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-6">Platform Activity</h4>
            <div className="space-y-6">
              {[
                { label: 'Wallet Balance', value: `₨ ${(useApp().walletBalance * 278.50).toFixed(2)}`, color: 'text-emerald-500' },
                { label: 'Available Campaigns', value: `${useApp().campaigns.filter(c => !c.watched).length} Items`, color: 'text-blue-500' },
                { label: 'Ads Watched', value: `${useApp().totalAdsWatched} Total`, color: 'text-amber-500' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">{item.label}</span>
                  <span className={`text-sm font-black ${item.color}`}>{item.value}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
