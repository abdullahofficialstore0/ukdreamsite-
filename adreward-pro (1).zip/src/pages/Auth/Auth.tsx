import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, Globe, CheckCircle2, ArrowRight, Users, ShieldCheck, Sparkles } from 'lucide-react';
import { doc, setDoc, getDoc, collection, query, where, getDocs, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useApp } from '../../context/AppContext';
import { Logo } from '../../components/Logo';
import { useNavigate } from 'react-router-dom';

export function Auth() {
  const { setUser, announcements } = useApp();
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);

  // Filter announcements for home/login page
  const homeAnnouncements = announcements.filter(a => a.targetPage === 'home' || a.targetPage === 'all');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Secret 10-tap counter for Admin Login access
  const [logoTaps, setLogoTaps] = useState(0);

  // Inviter Info State for non-editable boxes
  const [inviterName, setInviterName] = useState('');
  const [inviterCode, setInviterCode] = useState('');
  const [inviterEmail, setInviterEmail] = useState('');

  const showError = (msg: string) => {
    setError(msg);
    setTimeout(() => setError(null), 5000);
  };

  const handleLogoTap = () => {
    setLogoTaps(prev => {
      const next = prev + 1;
      if (next >= 10) {
        navigate('/admin');
        return 0;
      }
      return next;
    });
  };

  // Auto-detect referral code from URL query parameter ?ref=...
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      setIsLogin(false); // switch to signup automatically
      lookupInviter(ref);
    }
  }, []);

  const lookupInviter = async (queryStr: string) => {
    const target = queryStr.trim().toLowerCase();
    
    try {
      // 1. Try direct doc fetch by email if doc ID is email
      const docSnap = await getDoc(doc(db, 'users', target));
      if (docSnap.exists()) {
        const u = docSnap.data();
        setInviterName(u.name || 'Referrer');
        setInviterCode(u.referralCode || target.toUpperCase());
        setInviterEmail(u.email || target);
        return;
      }

      // 2. Query by referralCode or email field
      const q = query(collection(db, 'users'), where('referralCode', '==', target.toUpperCase()));
      const snap = await getDocs(q);
      
      if (!snap.empty) {
        const u = snap.docs[0].data();
        setInviterName(u.name || 'Referrer');
        setInviterCode(u.referralCode || target.toUpperCase());
        setInviterEmail(u.email || target);
        return;
      }

      // 3. Query by email field
      const q2 = query(collection(db, 'users'), where('email', '==', target));
      const snap2 = await getDocs(q2);
      if (!snap2.empty) {
        const u = snap2.docs[0].data();
        setInviterName(u.name || 'Referrer');
        setInviterCode(u.referralCode || target.toUpperCase());
        setInviterEmail(u.email || target);
        return;
      }

    } catch (err) {
      console.warn('Inviter lookup error:', err);
    }

    // Default fallback
    setInviterName('Official UK Dream Referrer');
    setInviterCode(target.toUpperCase());
    setInviterEmail('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    const emailInput = (e.target as any).querySelector('input[type="email"]');
    const passwordInput = (e.target as any).querySelector('input[name="password"]');
    const phoneInput = (e.target as any).querySelector('input[name="phone"]');
    const email = emailInput ? emailInput.value.toLowerCase().trim() : '';
    const password = passwordInput ? passwordInput.value : '';
    const phone = phoneInput ? phoneInput.value.trim() : '';
    
    const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');

    try {
      const storedUsersRaw = localStorage.getItem('adreward_users');
      const storedUsers = storedUsersRaw ? JSON.parse(storedUsersRaw) : {};

      if (!email || !password) {
        showError('Please enter a valid email and password.');
        setLoading(false);
        return;
      }

      if (!isLogin) {
        const confirmPasswordInput = (e.target as any).querySelector('input[name="confirmPassword"]');
        const confirmPassword = confirmPasswordInput ? confirmPasswordInput.value : '';

        if (password !== confirmPassword) {
          showError('Passwords do not match.');
          setLoading(false);
          return;
        }

        if (!phone) {
          showError('Please enter a valid phone number.');
          setLoading(false);
          return;
        }

        // 1. Strict Email Duplicate Check (Firestore + Local)
        const userRef = doc(db, 'users', email);
        const userSnap = await getDoc(userRef);
        const emailQuery = query(collection(db, 'users'), where('email', '==', email));
        const emailQuerySnap = await getDocs(emailQuery);

        if (userSnap.exists() || !emailQuerySnap.empty || storedUsers[email]) {
          showError('This Email is already registered. Please sign in instead.');
          setLoading(false);
          return;
        }

        // 2. Strict Phone Duplicate Check (Firestore + Local)
        const cleanPhone = phone.replace(/[^\d+]/g, '');
        const phoneQuery = query(collection(db, 'users'), where('phone', '==', phone));
        const phoneQuerySnap = await getDocs(phoneQuery);

        const phoneExistsInLocal = Object.values(storedUsers).some((u: any) => {
          if (!u.phone) return false;
          const userCleanPhone = u.phone.replace(/[^\d+]/g, '');
          return u.phone === phone || userCleanPhone === cleanPhone;
        });

        if (!phoneQuerySnap.empty || phoneExistsInLocal) {
          showError('This Phone number is already registered with another account. Please use a different phone number or sign in.');
          setLoading(false);
          return;
        }
        
        const nameInput = (e.target as any).querySelector('input[name="fullName"]');
        const usernameInput = (e.target as any).querySelector('input[name="username"]');
        const stateInput = (e.target as any).querySelector('input[name="state"]');
        const addressInput = (e.target as any).querySelector('input[name="address"]');
        const countrySelect = (e.target as any).querySelector('select[name="country"]');
        const refCodeInput = (e.target as any).querySelector('input[name="referralCodeInput"]');

        const name = nameInput ? nameInput.value.trim() : 'User';
        const username = usernameInput ? usernameInput.value.trim() : 'user_' + Math.floor(Math.random() * 1000);
        const country = countrySelect ? countrySelect.value : 'Pakistan';
        const state = stateInput ? stateInput.value.trim() : '';
        const address = addressInput ? addressInput.value.trim() : '';
        const userEnteredRefCode = refCodeInput ? refCodeInput.value.trim().toUpperCase() : '';

        let finalInviterEmail = inviterEmail || '';
        let finalInviterName = inviterName || '';
        let finalInviterCode = inviterCode || '';

        // If user explicitly entered a referral code in signup field
        if (userEnteredRefCode) {
          try {
            // Check Firestore first
            const refQuery = query(collection(db, 'users'), where('referralCode', '==', userEnteredRefCode));
            const refSnap = await getDocs(refQuery);

            if (!refSnap.empty) {
              const refUser = refSnap.docs[0].data();
              finalInviterEmail = refUser.email;
              finalInviterName = refUser.name;
              finalInviterCode = refUser.referralCode;
            } else {
              // Check local storage fallback
              const foundInLocal = Object.values(storedUsers).find((u: any) => u.referralCode === userEnteredRefCode) as any;
              if (foundInLocal) {
                finalInviterEmail = foundInLocal.email;
                finalInviterName = foundInLocal.name;
                finalInviterCode = foundInLocal.referralCode;
              } else {
                showError('Invalid Referral Code! Please enter a valid code or leave it blank.');
                setLoading(false);
                return;
              }
            }
          } catch (refCheckErr) {
            console.warn('Referral check error:', refCheckErr);
            // Check local storage as fallback
            const foundInLocal = Object.values(storedUsers).find((u: any) => u.referralCode === userEnteredRefCode) as any;
            if (foundInLocal) {
              finalInviterEmail = foundInLocal.email;
              finalInviterName = foundInLocal.name;
              finalInviterCode = foundInLocal.referralCode;
            } else {
              showError('Invalid Referral Code! Please enter a valid code or leave it blank.');
              setLoading(false);
              return;
            }
          }
        }
        
        // Generate unique Referral Code for new user
        const cleanName = name.replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 4) || 'UKD';
        const randomDigits = Math.floor(1000 + Math.random() * 9000);
        const myReferralCode = `${cleanName}-${randomDigits}`;
        
        const newUserObj = {
          id: email,
          name,
          username,
          email,
          password,
          phone,
          country,
          state,
          address,
          memberSince: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
          referralCode: myReferralCode,
          referredByEmail: finalInviterEmail || null,
          referredByName: finalInviterName || null,
          referredByCode: finalInviterCode || null,
          walletBalance: 0.00,
          referralEarnings: 0.00,
          referralsList: [],
          role: 'user',
          status: 'active',
          createdAt: new Date().toISOString()
        };
        
        // 1. Save to Firestore first
        await setDoc(userRef, newUserObj);

        // 2. Add to Referrer's list without bonus (Bonus only on package purchase)
        if (finalInviterEmail) {
          try {
            const referrerRef = doc(db, 'users', finalInviterEmail);
            const refSnap = await getDoc(referrerRef);
            if (refSnap.exists()) {
              const referrer = refSnap.data();
              await updateDoc(referrerRef, {
                referralsList: [
                  ...(referrer.referralsList || []),
                  {
                    name,
                    email,
                    date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                    reward: 0,
                    packageActivated: false
                  }
                ]
              });
            }

            // Sync local storage for referrer
            if (storedUsers[finalInviterEmail]) {
              if (!storedUsers[finalInviterEmail].referralsList) storedUsers[finalInviterEmail].referralsList = [];
              storedUsers[finalInviterEmail].referralsList.push({
                name,
                email,
                date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                reward: 0,
                packageActivated: false
              });
            }
          } catch (refErr) {
            console.warn('Referral list update failed:', refErr);
          }
        }

        // 3. Sync local
        storedUsers[email] = newUserObj;
        localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
        
        setLoading(false);
        setSuccess(true);
        setTimeout(() => {
          setSuccess(false);
          setIsLogin(true);
        }, 2000);
      } else {
        // Handle Login
        let activeUser = null;
        const userRef = doc(db, 'users', email);
        const userSnap = await getDoc(userRef);

        if (userSnap.exists()) {
          activeUser = userSnap.data();
        } else {
          // Try query as fallback
          const q = query(collection(db, 'users'), where('email', '==', email));
          const qSnap = await getDocs(q);
          if (!qSnap.empty) {
            activeUser = qSnap.docs[0].data();
          }
        }

        // Fallback to local cache if offline or not found in Firestore
        if (!activeUser) {
          activeUser = storedUsers[email];
        }

        if (!activeUser || String(activeUser.password) !== String(password)) {
          showError('Invalid email or password. Please check your credentials.');
          setLoading(false);
          return;
        }

        if (activeUser.status === 'suspended') {
          showError('This account has been suspended. Contact support for assistance.');
          setLoading(false);
          return;
        }

        // Update local cache
        storedUsers[email] = activeUser;
        localStorage.setItem('adreward_users', JSON.stringify(storedUsers));

        const { password: _, ...userWithoutPassword } = activeUser;
        setUser(userWithoutPassword as any);
        setLoading(false);
      }
    } catch (err: any) {
      console.error('Database Connection Error:', err);
      const isNetwork = err.message?.toLowerCase().includes('network') || err.code === 'unavailable';
      showError(isNetwork 
        ? 'Network timeout. Please check your internet connection and try again.' 
        : `Database Error: ${err.message || 'Connection failed'}. Please try again.`
      );
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#030712] flex flex-col justify-center items-center p-4 sm:p-6 transition-colors duration-300 relative overflow-hidden">
      {/* Background Subtle Gradient Accents */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-gradient-to-b from-blue-500/10 via-emerald-500/5 to-transparent blur-[100px] rounded-full" />
      </div>

      {/* ERROR TOAST */}
      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: -50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.95 }}
            className="fixed top-6 z-[100] max-w-md w-full px-5 py-3.5 bg-red-600 text-white rounded-2xl shadow-xl flex items-center justify-between border border-white/20"
          >
            <div className="flex items-center space-x-3">
              <ShieldCheck className="w-5 h-5 text-white shrink-0" />
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-white/80 uppercase tracking-wider">Notice</span>
                <span className="text-xs font-semibold leading-snug">{error}</span>
              </div>
            </div>
            <button 
              onClick={() => setError(null)} 
              className="p-1 hover:bg-white/20 rounded-lg transition-colors ml-2"
            >
              <Sparkles className="w-4 h-4 text-white" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        {/* Brand Header */}
        <div className="text-center mb-6 flex flex-col items-center">
          <div className="mb-4 cursor-pointer" onClick={handleLogoTap} title="UK Dream Pro">
            <Logo className="justify-center" />
          </div>
          
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            {isLogin ? 'Welcome Back' : 'Create an Account'}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium">
            {isLogin 
              ? 'Sign in to access your UK Dream earning dashboard.' 
              : 'Join Pakistan\'s premier ad-reward network today.'}
          </p>
        </div>

        {/* Home Announcements */}
        {homeAnnouncements.length > 0 && (
          <div className="mb-6 space-y-3">
            {homeAnnouncements.map((ann) => (
              <motion.div 
                key={ann.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white dark:bg-[#111827] border border-blue-500/20 rounded-2xl p-4 shadow-sm"
              >
                <div className="flex items-start space-x-3">
                  {ann.imageUrl && (
                    <img src={ann.imageUrl} alt={ann.title} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                  )}
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">{ann.title}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">{ann.message}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Form Card */}
        <div className="bg-white dark:bg-[#111827] rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200/80 dark:border-slate-800 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 via-emerald-500 to-indigo-600" />
          
          <AnimatePresence mode="wait">
            {success ? (
              <motion.div 
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="text-center py-8 space-y-4"
              >
                <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-2xl flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white">Registration Complete!</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Your account was created successfully. Logging you in...</p>
                </div>
              </motion.div>
            ) : (
              <motion.form 
                key={isLogin ? 'login' : 'register'}
                initial={{ opacity: 0, x: isLogin ? -15 : 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: isLogin ? 15 : -15 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleSubmit}
                className="space-y-4"
              >
                 {!isLogin && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Full Name</label>
                      <div className="relative">
                        <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="text" 
                          name="fullName"
                          required 
                          placeholder="Shabana Naz"
                          className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Username</label>
                      <div className="relative">
                        <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="text" 
                          name="username"
                          required 
                          placeholder="shabana_uk"
                          className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Phone Number</label>
                      <div className="relative">
                        <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="tel" 
                          name="phone"
                          required 
                          placeholder="+92 343 1252394"
                          className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Country</label>
                      <div className="relative">
                        <Globe className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <select name="country" className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all appearance-none">
                          <option value="Pakistan">Pakistan</option>
                          <option value="United Arab Emirates">United Arab Emirates</option>
                          <option value="Saudi Arabia">Saudi Arabia</option>
                          <option value="United Kingdom">United Kingdom</option>
                          <option value="United States">United States</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">City / Province</label>
                      <div className="relative">
                        <Globe className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="text" 
                          name="state"
                          required 
                          placeholder="Punjab"
                          className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Referral Code</label>
                      <div className="relative">
                        <Users className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="text" 
                          name="referralCodeInput"
                          defaultValue={inviterCode}
                          placeholder="e.g. UKD-1234"
                          className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-mono uppercase focus:border-blue-500 transition-all"
                        />
                      </div>
                    </div>

                    <div className="sm:col-span-2 space-y-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Full Address</label>
                      <div className="relative">
                        <Globe className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="text" 
                          name="address"
                          required 
                          placeholder="House #123, Sector G, Islamabad"
                          className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                        />
                      </div>
                    </div>

                    {/* Inviter Info Box */}
                    {inviterName && (
                      <div className="sm:col-span-2 p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl text-xs flex items-center justify-between">
                        <div className="flex items-center space-x-2.5">
                          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold">
                            <Users className="w-4 h-4" />
                          </div>
                          <div>
                            <span className="font-bold text-blue-600 dark:text-blue-400 block text-[10px] uppercase">Invited By</span>
                            <p className="text-slate-900 dark:text-white font-bold">{inviterName}</p>
                          </div>
                        </div>
                        <span className="font-mono font-bold text-slate-500 text-xs">{inviterCode}</span>
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="email" 
                      name="email"
                      required 
                      placeholder="name@example.com"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                    />
                  </div>
                </div>

                {isLogin && (
                  <div className="space-y-1">
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Phone Number (Optional)</label>
                    <div className="relative">
                      <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input 
                        type="tel" 
                        name="phone"
                        placeholder="+92 300 1234567"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="password" 
                      name="password"
                      required 
                      placeholder="••••••••"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                    />
                  </div>
                </div>

                {!isLogin && (
                  <div className="space-y-1">
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">Confirm Password</label>
                    <div className="relative">
                      <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input 
                        type="password" 
                        name="confirmPassword"
                        required 
                        placeholder="••••••••"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-900 dark:text-white text-xs font-semibold focus:border-blue-500 transition-all"
                      />
                    </div>
                  </div>
                )}

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md shadow-blue-500/20 transition-all flex items-center justify-center space-x-2 mt-6 active:scale-[0.99]"
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>{isLogin ? 'Sign In' : 'Register Account'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800/80 text-center">
            <button 
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              {isLogin ? (
                <>Don't have an account? <span className="text-blue-600 dark:text-blue-400 font-bold ml-1">Sign Up</span></>
              ) : (
                <>Already registered? <span className="text-blue-600 dark:text-blue-400 font-bold ml-1">Sign In</span></>
              )}
            </button>
          </div>
        </div>

        <p className="mt-6 text-center text-[11px] font-medium text-slate-400">
          © 2026 UK Dream AdReward Pro • All Rights Reserved
        </p>
      </motion.div>
    </div>
  );
}
