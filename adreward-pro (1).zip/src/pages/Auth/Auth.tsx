import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, Globe, CheckCircle2, ArrowRight, Share2, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Logo } from '../../components/Logo';

export function Auth() {
  const { setUser } = useApp();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [refInput, setRefInput] = useState('');

  // Auto-detect referral code from URL query parameter ?ref=...
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      setRefInput(ref);
      setIsLogin(false); // switch to signup automatically
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    setTimeout(() => {
      setLoading(false);
      const emailInput = (e.target as any).querySelector('input[type="email"]');
      const passwordInput = (e.target as any).querySelector('input[type="password"]');
      const email = emailInput ? emailInput.value : '';
      const password = passwordInput ? passwordInput.value : '';
      
      const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      
      if (!isLogin) {
        // Handle Registration
        if (storedUsers[email]) {
          alert('Email already registered. Please log in.');
          return;
        }
        
        const nameInput = (e.target as any).querySelector('input[placeholder="John Doe"]');
        const name = nameInput ? nameInput.value : 'User';
        const countrySelect = (e.target as any).querySelector('select');
        const country = countrySelect ? countrySelect.value : 'Pakistan';
        
        // Generate unique AI Referral Code
        const cleanName = name.replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 4) || 'UKD';
        const randomDigits = Math.floor(1000 + Math.random() * 9000);
        const myReferralCode = `${cleanName}-${randomDigits}-AI`;
        
        let referrerEmailFound: string | null = null;
        
        // If user entered a referral code / email / username
        if (refInput.trim()) {
          const targetRef = refInput.trim().toLowerCase();
          for (const uEmail in storedUsers) {
            const u = storedUsers[uEmail];
            if (
              (u.referralCode && u.referralCode.toLowerCase() === targetRef) ||
              (u.email && u.email.toLowerCase() === targetRef) ||
              (u.username && u.username.toLowerCase() === targetRef)
            ) {
              referrerEmailFound = uEmail;
              break;
            }
          }
        }
        
        // Save new user
        const newUserObj = {
          id: Math.random().toString(36).substring(7),
          name,
          username: name.toLowerCase().replace(/\s+/g, '_') + Math.floor(Math.random() * 100),
          email,
          password,
          phone: '+92 300 0000000',
          country,
          memberSince: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
          referralCode: myReferralCode,
          walletBalance: 0.00,
          referralEarnings: 0.00,
          referralsList: []
        };
        
        // Credit referrer $0.50 if valid referrer was found!
        if (referrerEmailFound && storedUsers[referrerEmailFound]) {
          const referrer = storedUsers[referrerEmailFound];
          referrer.walletBalance = (referrer.walletBalance || 0) + 0.50;
          referrer.referralEarnings = (referrer.referralEarnings || 0) + 0.50;
          if (!referrer.referralsList) referrer.referralsList = [];
          referrer.referralsList.push({
            name,
            email,
            date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
            reward: 0.50
          });
          storedUsers[referrerEmailFound] = referrer;
        }

        storedUsers[email] = newUserObj;
        localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
        
        setSuccess(true);
        setTimeout(() => {
          setSuccess(false);
          setIsLogin(true);
        }, 2000);
      } else {
        // Handle Login
        const user = storedUsers[email];
        if (!user || user.password !== password) {
          alert('Invalid email or password. If you do not have an account, please sign up first.');
          return;
        }
        
        const { password: _, ...userWithoutPassword } = user;
        setUser(userWithoutPassword);
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#030712] flex flex-col justify-center items-center p-4 sm:p-6 transition-colors duration-300">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8 flex flex-col items-center">
          <Logo className="mb-6 scale-125" />
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
            Welcome to UK Dream
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            {isLogin ? 'Sign in to manage your campaigns and earnings.' : 'Create an account to start earning today.'}
          </p>
        </div>

        <div className="bg-white dark:bg-[#111827] rounded-3xl p-8 shadow-xl border border-slate-200 dark:border-slate-800 relative overflow-hidden">
          <AnimatePresence mode="wait">
            {success ? (
              <motion.div 
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="text-center py-8"
              >
                <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Registration Successful!</h3>
                <p className="text-slate-500 dark:text-slate-400">You can now sign in with your credentials.</p>
              </motion.div>
            ) : (
              <motion.form 
                key={isLogin ? 'login' : 'register'}
                initial={{ opacity: 0, x: isLogin ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: isLogin ? 20 : -20 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleSubmit}
                className="space-y-5"
              >
                {!isLogin && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Full Name</label>
                      <div className="relative">
                        <User className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input type="text" required className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white transition-colors" placeholder="John Doe" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Country</label>
                      <div className="relative">
                        <Globe className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <select required className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white transition-colors appearance-none">
                          <option value="Pakistan">Pakistan</option>
                          <option value="US">United States</option>
                          <option value="UK">United Kingdom</option>
                          <option value="CA">Canada</option>
                          <option value="AU">Australia</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                        Referral ID / Inviter Email <span className="text-emerald-500 font-bold">(Earn $0.50 Bonus)</span>
                      </label>
                      <div className="relative">
                        <Users className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-emerald-500" />
                        <input 
                          type="text" 
                          value={refInput}
                          onChange={(e) => setRefInput(e.target.value)}
                          className="w-full pl-10 pr-4 py-3 bg-emerald-50/40 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/30 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-slate-900 dark:text-white transition-colors placeholder:text-slate-400" 
                          placeholder="e.g. UKD-8910-AI or inviter@gmail.com" 
                        />
                      </div>
                      <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
                        Inviter gets instant $0.50 bonus reward upon your signup.
                      </p>
                    </div>
                  </>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Email Address</label>
                  <div className="relative">
                    <Mail className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="email" required className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white transition-colors" placeholder="you@example.com" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Password</label>
                    {isLogin && <button type="button" className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline">Forgot password?</button>}
                  </div>
                  <div className="relative">
                    <Lock className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="password" required className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white transition-colors" placeholder="••••••••" />
                  </div>
                </div>

                {!isLogin && (
                  <div className="flex items-center mt-4">
                    <input type="checkbox" id="terms" required className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 bg-slate-50 dark:bg-slate-800 border dark:border-slate-700" />
                    <label htmlFor="terms" className="ml-2 block text-sm text-slate-500 dark:text-slate-400">
                      I accept the <a href="#" className="text-blue-600 dark:text-blue-400 hover:underline">Terms of Service</a>
                    </label>
                  </div>
                )}

                {isLogin && (
                  <div className="flex items-center mt-4">
                    <input type="checkbox" id="remember" className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 bg-slate-50 dark:bg-slate-800 border dark:border-slate-700" />
                    <label htmlFor="remember" className="ml-2 block text-sm text-slate-500 dark:text-slate-400">
                      Remember me
                    </label>
                  </div>
                )}

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full mt-6 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center space-x-2"
                >
                  {loading ? (
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>{isLogin ? 'Sign In' : 'Create Account'}</span>
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </div>

        <p className="text-center mt-8 text-slate-600 dark:text-slate-400">
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="font-bold text-blue-600 dark:text-blue-400 hover:underline"
          >
            {isLogin ? 'Sign up' : 'Log in'}
          </button>
        </p>
      </motion.div>
    </div>
  );
}
