import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Megaphone, Plus, Trash2, Image as ImageIcon, Link as LinkIcon, Send, Clock, X } from 'lucide-react';
import { collection, onSnapshot, addDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useApp } from '../../context/AppContext';

export function AnnouncementManager() {
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [targetPage, setTargetPage] = useState('home'); // home, dashboard, profile, all

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'announcements'), (snap) => {
      const list: any[] = [];
      snap.forEach(docSnap => list.push({ id: docSnap.id, ...docSnap.data() }));
      setAnnouncements(list.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)));
    });
    return () => unsub();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addDoc(collection(db, 'announcements'), {
        title,
        message,
        imageUrl,
        targetPage,
        createdAt: serverTimestamp(),
        active: true
      });
      setIsModalOpen(false);
      setTitle('');
      setMessage('');
      setImageUrl('');
    } catch (err) {
      console.error('Error saving announcement:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'announcements', id));
      setAnnouncements(prev => prev.filter(a => a.id !== id));
    } catch (e) {
      console.error('Delete error:', e);
      setAnnouncements(prev => prev.filter(a => a.id !== id));
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 p-8 bg-[#111827] border border-slate-800 rounded-[2rem] shadow-2xl">
        <div>
          <h2 className="text-3xl font-black text-white flex items-center space-x-3">
            <div className="p-2 bg-blue-500/10 rounded-xl">
              <Megaphone className="w-8 h-8 text-blue-400" />
            </div>
            <span>Announcements</span>
          </h2>
          <p className="text-sm text-slate-400 mt-2 max-w-md">Publish system-wide updates, news, or promotional banners with custom images.</p>
        </div>

        <button 
          onClick={() => setIsModalOpen(true)}
          className="px-6 py-4 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-xl shadow-blue-500/20 flex items-center justify-center space-x-2 shrink-0 cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>New Announcement</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {announcements.map((item) => (
          <div key={item.id} className="bg-[#111827] border border-slate-800 rounded-[2rem] overflow-hidden flex flex-col shadow-xl">
            {item.imageUrl && (
              <div className="h-40 overflow-hidden">
                <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
              </div>
            )}
            <div className="p-6 space-y-3 flex-1">
              <div className="flex justify-between items-start">
                <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-[10px] font-black uppercase tracking-widest rounded-full border border-blue-500/20">
                  Target: {item.targetPage}
                </span>
                {deletingId === item.id ? (
                  <div className="flex items-center space-x-2 animate-in fade-in zoom-in duration-200">
                    <button 
                      onClick={async () => {
                        try {
                          await handleDelete(item.id);
                          alert('Announcement deleted!');
                        } catch (err) {
                          alert('Delete failed');
                        }
                        setDeletingId(null);
                      }}
                      className="px-4 py-2 bg-red-600 text-white text-[10px] font-black uppercase rounded-xl shadow-lg shadow-red-500/20"
                    >
                      Delete
                    </button>
                    <button 
                      onClick={() => setDeletingId(null)}
                      className="px-4 py-2 bg-slate-800 text-slate-400 text-[10px] font-black uppercase rounded-xl"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => setDeletingId(item.id)} 
                    className="p-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl transition-all cursor-pointer border border-red-500/20"
                    title="Delete Announcement"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
              <h3 className="text-xl font-black text-white">{item.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{item.message}</p>
            </div>
            <div className="p-4 bg-slate-900/50 border-t border-slate-800 flex items-center text-[10px] text-slate-500 font-bold uppercase tracking-widest">
              <Clock className="w-3.5 h-3.5 mr-2" />
              <span>Published on {item.createdAt?.toDate ? item.createdAt.toDate().toLocaleDateString() : 'Just now'}</span>
            </div>
          </div>
        ))}

        {announcements.length === 0 && (
          <div className="md:col-span-2 py-20 text-center border-2 border-dashed border-slate-800 rounded-[2rem]">
            <Megaphone className="w-12 h-12 text-slate-700 mx-auto mb-4" />
            <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">No announcements yet</p>
          </div>
        )}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#111827] border border-slate-800 rounded-3xl max-w-lg w-full p-8 space-y-6 shadow-2xl relative"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-4">
                <h3 className="text-xl font-black text-white">Create Announcement</h3>
                <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-widest text-slate-500">Title</label>
                  <input 
                    type="text" 
                    required 
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    placeholder="E.g. Weekend Bonus Event"
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl outline-none text-white text-sm focus:border-blue-500 transition-all"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-widest text-slate-500">Message</label>
                  <textarea 
                    required 
                    rows={4}
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    placeholder="Describe the news or update..."
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl outline-none text-white text-sm focus:border-blue-500 transition-all"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-widest text-slate-500">Announcement Photo</label>
                  
                  {imageUrl ? (
                    <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 group">
                      <img src={imageUrl} alt="Preview" className="w-full h-32 object-cover" />
                      <button
                        type="button"
                        onClick={() => setImageUrl('')}
                        className="absolute top-2 right-2 p-1.5 bg-red-600 text-white rounded-xl shadow-lg hover:bg-red-700 transition-all"
                        title="Remove Photo"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-800 hover:border-blue-500/50 rounded-2xl p-6 cursor-pointer bg-slate-900/50 hover:bg-slate-900 transition-all group">
                        <ImageIcon className="w-8 h-8 text-slate-500 group-hover:text-blue-400 transition-colors mb-2" />
                        <span className="text-xs font-bold text-slate-300">Click to upload photo from device</span>
                        <span className="text-[10px] text-slate-500 mt-1">PNG, JPG, WEBP or GIF</span>
                        <input 
                          type="file" 
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              if (file.size > 5 * 1024 * 1024) {
                                alert('File size should be less than 5MB');
                                return;
                              }
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                setImageUrl(reader.result as string);
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                      <div className="text-center">
                        <span className="text-[10px] font-black uppercase text-slate-600 tracking-widest">Or paste URL directly</span>
                      </div>
                      <input 
                        type="url" 
                        value={imageUrl}
                        onChange={e => setImageUrl(e.target.value)}
                        placeholder="https://..."
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl outline-none text-white text-sm focus:border-blue-500 transition-all"
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-widest text-slate-500">Target Page</label>
                  <select 
                    value={targetPage}
                    onChange={e => setTargetPage(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl outline-none text-white text-sm focus:border-blue-500 transition-all"
                  >
                    <option value="home">Home / Login</option>
                    <option value="dashboard">User Dashboard</option>
                    <option value="profile">User Profile</option>
                    <option value="all">All Pages</option>
                  </select>
                </div>

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Publish Announcement</span>
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
