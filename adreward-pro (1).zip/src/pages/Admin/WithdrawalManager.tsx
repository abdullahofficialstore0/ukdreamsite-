import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Wallet, Search, CheckCircle2, XCircle, Clock, Send, DollarSign, Filter, Trash2 } from 'lucide-react';
import { collection, onSnapshot, doc, updateDoc, query, where, getDocs, getDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useApp } from '../../context/AppContext';
import { WithdrawalRequest } from '../../types';

export function WithdrawalManager() {
  const { withdrawals: contextWithdrawals } = useApp();
  const [withdrawalsList, setWithdrawalsList] = useState<WithdrawalRequest[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'paid' | 'rejected'>('all');

  const [selectedRequest, setSelectedRequest] = useState<WithdrawalRequest | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'withdrawals'), (snap) => {
      const list: WithdrawalRequest[] = [];
      snap.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as WithdrawalRequest);
      });
      setWithdrawalsList(list);
    });

    return () => unsub();
  }, []);

  const effectiveList = withdrawalsList.length > 0 ? withdrawalsList : contextWithdrawals;

  const filtered = effectiveList.filter(w => {
    const matchSearch = 
      (w.userEmail || '').toLowerCase().includes(search.toLowerCase()) ||
      (w.accountTitle || '').toLowerCase().includes(search.toLowerCase()) ||
      (w.accountNumber || '').toLowerCase().includes(search.toLowerCase()) ||
      (w.method || '').toLowerCase().includes(search.toLowerCase());
    
    const matchStatus = statusFilter === 'all' || w.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const handleUpdateStatus = async (reqId: string, newStatus: 'approved' | 'paid' | 'rejected') => {
    try {
      const ref = doc(db, 'withdrawals', reqId);
      await updateDoc(ref, {
        status: newStatus,
        adminNote: adminNote || `Status updated to ${newStatus} by admin`,
        processedAt: new Date().toISOString()
      });

      // If rejected, refund user wallet balance in Firestore and Local Storage
      if (newStatus === 'rejected' && selectedRequest?.userEmail) {
        try {
          const userRef = doc(db, 'users', selectedRequest.userEmail);
          const userSnap = await getDoc(userRef);
          if (userSnap.exists()) {
            const userData = userSnap.data();
            const currentBal = userData.walletBalance || 0;
            const refundAmount = selectedRequest.amountUsd || 0;
            const newBal = currentBal + refundAmount;
            await updateDoc(userRef, { walletBalance: newBal });
          }

          // Local storage refund sync
          const localUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
          if (localUsers[selectedRequest.userEmail]) {
            const curBal = localUsers[selectedRequest.userEmail].walletBalance || 0;
            localUsers[selectedRequest.userEmail].walletBalance = curBal + (selectedRequest.amountUsd || 0);
            localStorage.setItem('adreward_users', JSON.stringify(localUsers));
          }
        } catch (refundErr) {
          console.warn('Refund error on rejection:', refundErr);
        }
      }

      // Update corresponding transaction if it exists
      if (selectedRequest?.userEmail) {
        const txQuery = query(
          collection(db, 'transactions'), 
          where('userId', '==', selectedRequest.userEmail),
          where('withdrawalId', '==', reqId)
        );
        const txSnap = await getDocs(txQuery);
        if (!txSnap.empty) {
          const statusMap: Record<string, string> = {
            'approved': 'Approved',
            'paid': 'Approved',
            'rejected': 'Rejected',
            'pending': 'Pending'
          };
          await updateDoc(txSnap.docs[0].ref, {
            status: statusMap[newStatus] || 'Approved'
          });
        }
      }

      setSelectedRequest(null);
      setAdminNote('');
      alert(`Withdrawal marked as ${newStatus}.${newStatus === 'rejected' ? ' Funds refunded to user balance.' : ''}`);
    } catch (e) {
      alert('Updated status locally.');
      setSelectedRequest(null);
    }
  };

  const handleDeleteRequest = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'withdrawals', id));
      setWithdrawalsList(prev => prev.filter(w => w.id !== id));
      setSelectedRequest(null);
    } catch (err) {
      console.error('Delete error:', err);
      setWithdrawalsList(prev => prev.filter(w => w.id !== id));
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto text-slate-100 pb-12">
      <div className="p-8 bg-[#111827] border border-slate-800 rounded-[2rem] shadow-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-white flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/10 rounded-xl">
              <Wallet className="w-8 h-8 text-emerald-400" />
            </div>
            <span>Withdrawals</span>
          </h2>
          <p className="text-sm text-slate-400 mt-2 max-w-md">Manage member payout requests. Review account details, verify transaction limits, and process payments securely.</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[280px]">
            <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <input 
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by user email, title, account..."
              className="w-full pl-12 pr-4 py-3.5 bg-[#1e293b] border border-slate-700 rounded-2xl text-sm text-white outline-none focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all"
            />
          </div>

          <select 
            value={statusFilter}
            onChange={(e: any) => setStatusFilter(e.target.value)}
            className="px-4 py-3.5 bg-[#1e293b] border border-slate-700 rounded-2xl text-sm text-white outline-none focus:border-emerald-500 transition-all cursor-pointer"
          >
            <option value="all">All Payouts</option>
            <option value="pending">Pending Review</option>
            <option value="approved">Approved</option>
            <option value="paid">Marked Paid</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Requests Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-[2rem] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-[#1e293b] text-slate-400 uppercase font-black text-[10px] tracking-widest border-b border-slate-800">
              <tr>
                <th className="p-6">Requester</th>
                <th className="p-6">Payout Method & Account</th>
                <th className="p-6">Withdrawal Sum</th>
                <th className="p-6">Request Date</th>
                <th className="p-6">Current Status</th>
                <th className="p-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filtered.map((req) => (
                <tr key={req.id} className="hover:bg-[#1e293b]/30 transition-colors">
                  <td className="p-6">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center font-black text-[10px] text-slate-500">
                        {req.userEmail[0].toUpperCase()}
                      </div>
                      <div className="flex flex-col">
                        <span className="font-bold text-white block text-sm">{req.userEmail}</span>
                        <span className="text-[10px] text-slate-500 font-mono">ID: {req.id.slice(-8)}</span>
                      </div>
                    </div>
                  </td>
                  <td className="p-6">
                    <span className="font-black text-emerald-400 uppercase tracking-widest block text-[10px] mb-1">{req.method}</span>
                    <div className="flex flex-col">
                      <span className="text-slate-300 font-bold text-xs">{req.accountTitle}</span>
                      <span className="font-mono text-slate-500 text-[11px]">{req.accountNumber}</span>
                    </div>
                  </td>
                  <td className="p-6">
                    <div className="space-y-1">
                      <span className="font-black text-white text-base block leading-none">${req.amountUsd.toFixed(2)}</span>
                      <span className="text-emerald-400 font-bold text-[10px] uppercase">₨ {(req.amountPkr || req.amountUsd * 278.5).toLocaleString()} PKR</span>
                    </div>
                  </td>
                  <td className="p-6 text-slate-400 text-xs font-medium">
                    {new Date(req.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                  <td className="p-6">
                    <span className={`px-4 py-1.5 font-black text-[10px] uppercase rounded-full inline-flex items-center space-x-2 border ${
                      req.status === 'pending' ? 'bg-amber-500/5 text-amber-400 border-amber-500/20' :
                      req.status === 'approved' || req.status === 'paid' ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/20' :
                      'bg-red-500/5 text-red-400 border-red-500/20'
                    }`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${
                        req.status === 'pending' ? 'bg-amber-400' :
                        req.status === 'approved' || req.status === 'paid' ? 'bg-emerald-400' :
                        'bg-red-400'
                      }`} />
                      <span>{req.status}</span>
                    </span>
                  </td>
                  <td className="p-6 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button 
                        onClick={() => setSelectedRequest(req)}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-black text-[10px] uppercase tracking-wider rounded-xl transition-all cursor-pointer"
                      >
                        Process
                      </button>
                      {deletingId === req.id ? (
                        <div className="flex flex-col space-y-1 animate-in fade-in duration-200">
                          <button 
                            onClick={async () => {
                              try {
                                await handleDeleteRequest(req.id);
                                alert('Withdrawal request deleted');
                              } catch (err) {
                                alert('Delete failed');
                              }
                              setDeletingId(null);
                            }}
                            className="px-3 py-1.5 bg-red-600 text-white text-[9px] font-black uppercase rounded-lg shadow-lg"
                          >
                            Confirm
                          </button>
                          <button 
                            onClick={() => setDeletingId(null)}
                            className="px-3 py-1.5 bg-slate-800 text-slate-400 text-[9px] font-black uppercase rounded-lg"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setDeletingId(req.id)}
                          className="p-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl transition-all cursor-pointer border border-red-500/20"
                          title="Permanently Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* PROCESS MODAL */}
      {selectedRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#111827] border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-white">Process Withdrawal Request</h3>
              <button onClick={() => setSelectedRequest(null)} className="text-slate-400 font-bold">✕</button>
            </div>

            <div className="p-4 bg-[#1e293b] rounded-2xl space-y-2 text-xs">
              <p><strong>User Email:</strong> {selectedRequest.userEmail}</p>
              <p><strong>Method:</strong> {selectedRequest.method}</p>
              <p><strong>Account Title:</strong> {selectedRequest.accountTitle}</p>
              <p><strong>Account Number:</strong> {selectedRequest.accountNumber}</p>
              <p><strong>Amount:</strong> ${selectedRequest.amountUsd.toFixed(2)} USD (₨ {selectedRequest.amountPkr} PKR)</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Admin Transaction Note / TRX ID</label>
              <input 
                type="text" 
                value={adminNote} 
                onChange={e => setAdminNote(e.target.value)}
                placeholder="e.g. Paid via EasyPaisa TRX #91823712"
                className="w-full px-3.5 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-3 gap-2 pt-2">
              <button 
                onClick={() => handleUpdateStatus(selectedRequest.id, 'approved')}
                className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Approve
              </button>
              <button 
                onClick={() => handleUpdateStatus(selectedRequest.id, 'paid')}
                className="py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Mark Paid
              </button>
              <button 
                onClick={() => handleUpdateStatus(selectedRequest.id, 'rejected')}
                className="py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Reject
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
