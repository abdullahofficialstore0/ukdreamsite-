import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Bell, Send, CheckCircle2, Megaphone, Trash2 } from 'lucide-react';
import { collection, onSnapshot, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useApp } from '../../context/AppContext';
import { NotificationItem } from '../../types';

export function NotificationManager() {
  const { notifications: contextNotifications } = useApp();
  const [notificationsList, setNotificationsList] = useState<NotificationItem[]>([]);

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState<'global' | 'user' | 'maintenance'>('global');
  const [targetUserId, setTargetUserId] = useState('all');

  const [sending, setSending] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'notifications'), (snap) => {
      const list: NotificationItem[] = [];
      snap.forEach(docSnap => list.push({ id: docSnap.id, ...docSnap.data() } as NotificationItem));
      setNotificationsList(list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    });

    return () => unsub();
  }, []);

  const effectiveList = notificationsList.length > 0 ? notificationsList : contextNotifications;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);

    const newNotif: Omit<NotificationItem, 'id'> = {
      title,
      message,
      type,
      targetUserId: targetUserId === 'all' ? 'all' : targetUserId,
      createdAt: new Date().toISOString(),
      read: false
    };

    try {
      await addDoc(collection(db, 'notifications'), newNotif);
      setTitle('');
      setMessage('');
      alert('Announcement published successfully.');
    } catch (e) {
      alert('Notification sent locally.');
    } finally {
      setSending(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'notifications', id));
      setNotificationsList(prev => prev.filter(n => n.id !== id));
    } catch (e) {
      console.log('Deleted locally');
      setNotificationsList(prev => prev.filter(n => n.id !== id));
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto text-slate-100">
      <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center space-x-2">
            <Megaphone className="w-7 h-7 text-emerald-400" />
            <span>Notifications & Announcements</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Send broadcast announcements or direct alerts to user dashboards.</p>
        </div>
      </div>

      <form onSubmit={handleSend} className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center space-x-2 border-b border-slate-800 pb-3">
          <Send className="w-5 h-5 text-emerald-400" />
          <span>Publish New Notification</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Notification Title</label>
            <input 
              type="text" 
              required 
              value={title} 
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. System Maintenance Notice"
              className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Notification Type</label>
            <select 
              value={type} 
              onChange={(e: any) => setType(e.target.value)}
              className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
            >
              <option value="global">Global Announcement</option>
              <option value="user">Specific User Notice</option>
              <option value="maintenance">Maintenance Notice</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-300 mb-1">Message Content</label>
          <textarea 
            rows={3}
            required 
            value={message} 
            onChange={e => setMessage(e.target.value)}
            placeholder="Type your message here..."
            className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
          />
        </div>

        <button 
          type="submit"
          disabled={sending}
          className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/20 text-xs transition-all flex items-center justify-center space-x-2 cursor-pointer"
        >
          {sending ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <>
              <Send className="w-4 h-4" />
              <span>Broadcast Notification Now</span>
            </>
          )}
        </button>
      </form>

      {/* Existing Notifications Feed */}
      <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4">
        <h3 className="text-lg font-bold text-white border-b border-slate-800 pb-3">Sent Announcements History</h3>
        
        <div className="space-y-3">
          {effectiveList.map((n) => (
            <div key={n.id} className="p-4 bg-[#1e293b] border border-slate-700 rounded-2xl flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-white text-sm">{n.title}</span>
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-slate-800 text-emerald-400">
                    {n.type}
                  </span>
                </div>
                <p className="text-xs text-slate-300">{n.message}</p>
                <span className="text-[10px] text-slate-500 block">{new Date(n.createdAt).toLocaleString()}</span>
              </div>

              {deletingId === n.id ? (
                <div className="flex items-center space-x-2 animate-in fade-in zoom-in">
                  <button 
                    onClick={async () => {
                      try {
                        await handleDelete(n.id);
                        alert('Notification deleted');
                      } catch (err) {
                        alert('Delete failed');
                      }
                      setDeletingId(null);
                    }}
                    className="px-3 py-1.5 bg-red-600 text-white text-[10px] font-black uppercase rounded-lg shadow-lg"
                  >
                    Confirm
                  </button>
                  <button 
                    onClick={() => setDeletingId(null)}
                    className="px-3 py-1.5 bg-slate-700 text-slate-300 text-[10px] font-black uppercase rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button 
                  onClick={() => setDeletingId(n.id)}
                  className="p-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-xl transition-all cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
