import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CreditCard, Wallet, Building2, Save, Smartphone, CheckCircle2, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { updateSiteSettingsInFirestore } from '../../lib/firestoreService';

export function PaymentSettings() {
  const { siteSettings } = useApp();

  const [bankName, setBankName] = useState(siteSettings.bankName || 'Meezan Bank');
  const [accountHolderName, setAccountHolderName] = useState(siteSettings.accountHolderName || 'Hamza');
  const [accountNumberIban, setAccountNumberIban] = useState(siteSettings.accountNumberIban || '03091236267');
  
  const [easyPaisaNumber, setEasyPaisaNumber] = useState(siteSettings.easyPaisaNumber || '03091236267');
  const [jazzCashNumber, setJazzCashNumber] = useState(siteSettings.jazzCashNumber || '03091236267');
  const [sadaPayNumber, setSadaPayNumber] = useState(siteSettings.sadaPayNumber || '03091236267');
  const [nayaPayNumber, setNayaPayNumber] = useState(siteSettings.nayaPayNumber || '03091236267');
  
  const [minWithdrawal, setMinWithdrawal] = useState(siteSettings.minWithdrawal || 500);
  const [maxWithdrawalLimit, setMaxWithdrawalLimit] = useState(siteSettings.maxWithdrawalLimit || 100000);
  const [paymentInstructions, setPaymentInstructions] = useState(siteSettings.paymentInstructions || 'Send payment to the provided account details and enter the TRX ID below.');

  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const updated = {
      bankName,
      accountHolderName,
      accountNumberIban,
      easyPaisaNumber,
      jazzCashNumber,
      sadaPayNumber,
      nayaPayNumber,
      minWithdrawal: Number(minWithdrawal),
      maxWithdrawalLimit: Number(maxWithdrawalLimit),
      paymentInstructions
    };

    await updateSiteSettingsInFirestore(updated, 'admin@ukdream.com');
    setSaving(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto text-slate-100">
      <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center space-x-2">
            <CreditCard className="w-7 h-7 text-emerald-400" />
            <span>Payment & Gateway Settings</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure deposit receiving accounts and withdrawal thresholds for users.
          </p>
        </div>

        {savedSuccess && (
          <div className="px-4 py-2 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-bold rounded-xl flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings Saved & Synced Live!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Deposit Accounts Config */}
        <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4">
          <h3 className="text-lg font-bold text-white flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Smartphone className="w-5 h-5 text-emerald-400" />
            <span>Official Deposit Accounts (EasyPaisa, JazzCash, Meezan Bank, SadaPay)</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">EasyPaisa Official Number</label>
              <input 
                type="text" 
                required 
                value={easyPaisaNumber} 
                onChange={e => setEasyPaisaNumber(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">JazzCash Official Number</label>
              <input 
                type="text" 
                required 
                value={jazzCashNumber} 
                onChange={e => setJazzCashNumber(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Bank Name</label>
              <input 
                type="text" 
                required 
                value={bankName} 
                onChange={e => setBankName(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Account Holder Name</label>
              <input 
                type="text" 
                required 
                value={accountHolderName} 
                onChange={e => setAccountHolderName(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">IBAN / Bank Account Number</label>
              <input 
                type="text" 
                required 
                value={accountNumberIban} 
                onChange={e => setAccountNumberIban(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">SadaPay / NayaPay Details</label>
              <div className="grid grid-cols-2 gap-2">
                <input 
                  type="text" 
                  value={sadaPayNumber} 
                  onChange={e => setSadaPayNumber(e.target.value)}
                  placeholder="SadaPay No."
                  className="w-full px-3 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs font-mono"
                />
                <input 
                  type="text" 
                  value={nayaPayNumber} 
                  onChange={e => setNayaPayNumber(e.target.value)}
                  placeholder="NayaPay No."
                  className="w-full px-3 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs font-mono"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Payment Instructions to Show Users</label>
            <textarea 
              rows={3}
              value={paymentInstructions}
              onChange={e => setPaymentInstructions(e.target.value)}
              className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
            />
          </div>
        </div>

        {/* Withdrawal Limits */}
        <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4">
          <h3 className="text-lg font-bold text-white flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Wallet className="w-5 h-5 text-amber-400" />
            <span>Withdrawal Rules & Limits</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Minimum Withdrawal Amount (PKR)</label>
              <input 
                type="number" 
                required 
                value={minWithdrawal} 
                onChange={e => setMinWithdrawal(Number(e.target.value))}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Users cannot submit withdrawals lower than this amount.</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Maximum Daily Payout Limit (PKR)</label>
              <input 
                type="number" 
                required 
                value={maxWithdrawalLimit} 
                onChange={e => setMaxWithdrawalLimit(Number(e.target.value))}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs font-mono"
              />
            </div>
          </div>
        </div>

        <button 
          type="submit"
          disabled={saving}
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-2xl shadow-lg shadow-emerald-500/20 text-sm transition-all flex items-center justify-center space-x-2 cursor-pointer"
        >
          {saving ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <>
              <Save className="w-5 h-5" />
              <span>Update Payment Gateway Settings</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
