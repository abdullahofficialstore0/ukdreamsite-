import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Users, Search, UserCheck, UserX, KeyRound, Wallet, Trash2, Edit3, Shield, CheckCircle2 } from 'lucide-react';
import { collection, onSnapshot, doc, updateDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useApp } from '../../context/AppContext';
import { logAdminAction, transactionsCol, adjustUserBalanceInFirestore, updateUserStatusInFirestore } from '../../lib/firestoreService';

export function UserManager() {
  const [usersList, setUsersList] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended'>('all');

  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [balanceAdjustAmount, setBalanceAdjustAmount] = useState('');
  const [adjustType, setAdjustType] = useState<'add' | 'deduct'>('add');
  const [newPassword, setNewPassword] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [deletingEmail, setDeletingEmail] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'users'), (snap) => {
      const list: any[] = [];
      snap.forEach(docSnap => list.push({ id: docSnap.id, ...docSnap.data() }));
      setUsersList(list);
    });

    return () => unsub();
  }, []);

  // Merge with localStorage users if Firestore list is small
  const localUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
  const combinedMap = new Map();
  
  Object.values(localUsers).forEach((u: any) => {
    combinedMap.set(u.email, u);
  });
  usersList.forEach(u => {
    if (u.email) combinedMap.set(u.email, u);
  });

  const allUsersArray = Array.from(combinedMap.values());

  const filtered = allUsersArray.filter(u => {
    const matchSearch = 
      (u.name || '').toLowerCase().includes(search.toLowerCase()) ||
      (u.email || '').toLowerCase().includes(search.toLowerCase()) ||
      (u.referralCode || '').toLowerCase().includes(search.toLowerCase());
    
    const matchStatus = statusFilter === 'all' || (statusFilter === 'active' ? u.status !== 'suspended' : u.status === 'suspended');
    return matchSearch && matchStatus;
  });

  const handleToggleSuspend = async (u: any) => {
    const newStatus = u.status === 'suspended' ? 'active' : 'suspended';
    setActionLoading(true);
    try {
      await updateUserStatusInFirestore(u.id || u.email, newStatus, 'admin@ukdream.com');

      // Also update local storage for instant feedback if needed
      if (localUsers[u.email]) {
        localUsers[u.email].status = newStatus;
        localStorage.setItem('adreward_users', JSON.stringify(localUsers));
      }
    } catch (e) {
      console.warn('User status update warning:', e);
    } finally {
      setActionLoading(false);
    }
  };

  const handleAdjustBalance = async () => {
    if (!selectedUser || !balanceAdjustAmount) return;
    const val = parseFloat(balanceAdjustAmount);
    if (isNaN(val) || val <= 0) return;

    setActionLoading(true);
    try {
      await adjustUserBalanceInFirestore(
        selectedUser.id || selectedUser.email,
        val,
        'Admin Manual Adjustment',
        'admin@ukdream.com',
        adjustType === 'add' ? 'manual_credit' : 'manual_debit'
      );

      // Sync local storage
      const newBal = adjustType === 'add' ? (selectedUser.walletBalance || 0) + val : Math.max(0, (selectedUser.walletBalance || 0) - val);
      if (localUsers[selectedUser.email]) {
        localUsers[selectedUser.email].walletBalance = newBal;
        localStorage.setItem('adreward_users', JSON.stringify(localUsers));
      }

      const pkrVal = (val * 278.5).toFixed(0);
      alert(`Success: Adjusted balance for ${selectedUser.name}. Total: $${newBal.toFixed(2)} USD (≈ ₨ ${(newBal * 278.5).toFixed(0)} PKR).`);
      setSelectedUser(null);
      setBalanceAdjustAmount('');
    } catch (e) {
      console.error('Balance update error:', e);
      alert('Failed to update balance in database. Please check your connection.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!selectedUser || !newPassword) return;
    setActionLoading(true);

    try {
      await updateDoc(doc(db, 'users', selectedUser.id || selectedUser.email), { password: newPassword });
      
      if (localUsers[selectedUser.email]) {
        localUsers[selectedUser.email].password = newPassword;
        localStorage.setItem('adreward_users', JSON.stringify(localUsers));
      }
      alert(`Password reset for ${selectedUser.email} successfully.`);
      setNewPassword('');
      setSelectedUser(null);
    } catch (e) {
      console.error('Pass reset error:', e);
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteUser = async (u: any) => {
    try {
      const userDocId = u.id || u.email;
      if (userDocId) {
        await deleteDoc(doc(db, 'users', userDocId)).catch(() => {});
      }
      if (u.email && u.email !== userDocId) {
        await deleteDoc(doc(db, 'users', u.email.toLowerCase())).catch(() => {});
      }
      
      // Update local state immediately
      setUsersList(prev => prev.filter(item => item.email !== u.email && item.id !== u.id));
      
      // Clear from local storage
      const stored = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      if (u.email) {
        delete stored[u.email];
        delete stored[u.email.toLowerCase()];
        localStorage.setItem('adreward_users', JSON.stringify(stored));
      }
    } catch (e) {
      console.error('Delete error:', e);
      setUsersList(prev => prev.filter(item => item.email !== u.email && item.id !== u.id));
    } finally {
      setDeletingEmail(null);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto text-slate-100 pb-12">
      <div className="p-8 bg-[#111827] border border-slate-800 rounded-[2rem] shadow-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-white flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/10 rounded-xl">
              <Users className="w-8 h-8 text-emerald-400" />
            </div>
            <span>User Management</span>
          </h2>
          <p className="text-sm text-slate-400 mt-2 max-w-md">Comprehensive control over UK Dream members. Manage permissions, verify account details, and handle financial adjustments.</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[280px]">
            <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <input 
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search name, email, referral code..."
              className="w-full pl-12 pr-4 py-3.5 bg-[#1e293b] border border-slate-700 rounded-2xl text-sm text-white outline-none focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all"
            />
          </div>

          <select 
            value={statusFilter}
            onChange={(e: any) => setStatusFilter(e.target.value)}
            className="px-4 py-3.5 bg-[#1e293b] border border-slate-700 rounded-2xl text-sm text-white outline-none focus:border-emerald-500 transition-all cursor-pointer"
          >
            <option value="all">All Accounts</option>
            <option value="active">Active Members</option>
            <option value="suspended">Suspended Users</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-[2rem] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-[#1e293b] text-slate-400 uppercase font-black text-[10px] tracking-widest border-b border-slate-800">
              <tr>
                <th className="p-6">Member Profile</th>
                <th className="p-6">Region & Referral</th>
                <th className="p-6">Financial Overview</th>
                <th className="p-6">Account Status</th>
                <th className="p-6 text-right">Management</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filtered.map((u, idx) => (
                <tr key={idx} className="hover:bg-[#1e293b]/30 transition-colors">
                  <td className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center font-black text-slate-500">
                        {u.name ? u.name[0].toUpperCase() : 'U'}
                      </div>
                      <div>
                        <span className="font-bold text-white block text-base">{u.name || 'Member'}</span>
                        <span className="text-xs text-slate-500">{u.email}</span>
                      </div>
                    </div>
                  </td>
                  <td className="p-6">
                    <span className="text-slate-300 block font-medium">{u.country || 'Pakistan'}</span>
                    <span className="font-mono text-emerald-400 text-xs mt-0.5 block">{u.referralCode || 'N/A'}</span>
                  </td>
                  <td className="p-6">
                    <div className="space-y-1">
                      <span className="font-black text-amber-400 text-lg block leading-none">${(u.walletBalance || 0).toFixed(2)}</span>
                      <span className="text-slate-500 text-[10px] uppercase font-bold block">≈ ₨ {((u.walletBalance || 0) * 278.5).toLocaleString()} PKR</span>
                    </div>
                  </td>
                  <td className="p-6">
                    <span className={`px-4 py-1.5 font-black text-[10px] uppercase rounded-full inline-flex items-center space-x-2 border ${
                      u.status === 'suspended' ? 'bg-red-500/5 text-red-400 border-red-500/20' : 'bg-emerald-500/5 text-emerald-400 border-emerald-500/20'
                    }`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${u.status === 'suspended' ? 'bg-red-400' : 'bg-emerald-400'}`} />
                      <span>{u.status === 'suspended' ? 'Suspended' : 'Active'}</span>
                    </span>
                  </td>
                  <td className="p-6 text-right">
                    <div className="flex items-center justify-end space-x-3">
                      <button 
                        onClick={() => setSelectedUser(u)}
                        disabled={actionLoading}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition-all cursor-pointer disabled:opacity-50 flex items-center space-x-2"
                      >
                        <Shield className="w-3.5 h-3.5" />
                        <span>Manage</span>
                      </button>
                      <button 
                        onClick={() => handleToggleSuspend(u)}
                        disabled={actionLoading}
                        className={`px-4 py-2 font-bold text-xs rounded-xl transition-all cursor-pointer disabled:opacity-50 ${
                          u.status === 'suspended' ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20' : 'bg-amber-500/10 text-amber-400 hover:bg-amber-500/20'
                        }`}
                      >
                        {actionLoading ? '...' : (u.status === 'suspended' ? 'Activate' : 'Suspend')}
                      </button>
                      {deletingEmail === u.email ? (
                        <div className="flex flex-col space-y-2 animate-in fade-in slide-in-from-right-2">
                          <button 
                            onClick={async () => {
                              try {
                                await handleDeleteUser(u);
                                alert('User deleted successfully');
                              } catch (err) {
                                alert('Delete failed');
                              }
                              setDeletingEmail(null);
                            }}
                            className="px-3 py-1.5 bg-red-600 text-white text-[10px] font-black uppercase rounded-lg shadow-lg"
                          >
                            Confirm Delete
                          </button>
                          <button 
                            onClick={() => setDeletingEmail(null)}
                            className="px-3 py-1.5 bg-slate-700 text-slate-300 text-[10px] font-black uppercase rounded-lg"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setDeletingEmail(u.email)}
                          disabled={actionLoading}
                          className="p-3 bg-red-500/10 text-red-400 hover:bg-red-500/20 font-bold rounded-xl transition-all cursor-pointer disabled:opacity-50 border border-red-500/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MANAGE USER MODAL */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#111827] border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-white">Manage User Account</h3>
              <button onClick={() => setSelectedUser(null)} className="text-slate-400 font-bold">✕</button>
            </div>

            <div className="p-3 bg-[#1e293b] rounded-xl text-xs space-y-1">
              <p><strong>Name:</strong> {selectedUser.name}</p>
              <p><strong>Email:</strong> {selectedUser.email}</p>
              <p><strong>Current Wallet Balance:</strong> ${selectedUser.walletBalance || 0}</p>
            </div>

            {/* Adjust Wallet */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <label className="block text-xs font-bold text-slate-300">Credit or Debit Wallet ($ USD)</label>
              <div className="flex space-x-2">
                <select 
                  value={adjustType} 
                  onChange={(e: any) => setAdjustType(e.target.value)}
                  className="px-3 py-2 bg-[#1e293b] border border-slate-700 rounded-xl text-xs text-white"
                >
                  <option value="add">Add (+)</option>
                  <option value="deduct">Deduct (-)</option>
                </select>
                <input 
                  type="number"
                  step="0.01"
                  value={balanceAdjustAmount}
                  onChange={e => setBalanceAdjustAmount(e.target.value)}
                  placeholder="0.00"
                  className="flex-1 px-3 py-2 bg-[#1e293b] border border-slate-700 rounded-xl text-xs text-white outline-none"
                />
                <button 
                  onClick={handleAdjustBalance}
                  disabled={actionLoading}
                  className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer disabled:opacity-50"
                >
                  {actionLoading ? '...' : 'Apply'}
                </button>
              </div>
            </div>

            {/* Reset Password */}
            <div className="space-y-2 pt-3 border-t border-slate-800">
              <label className="block text-xs font-bold text-slate-300">Reset User Password</label>
              <div className="flex space-x-2">
                <input 
                  type="text"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="New Password"
                  className="flex-1 px-3 py-2 bg-[#1e293b] border border-slate-700 rounded-xl text-xs text-white outline-none"
                />
                <button 
                  onClick={handleResetPassword}
                  disabled={actionLoading}
                  className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl cursor-pointer disabled:opacity-50"
                >
                  {actionLoading ? '...' : 'Save Pass'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
