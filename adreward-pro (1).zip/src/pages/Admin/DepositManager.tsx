import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowDownLeft, Search, CheckCircle2, XCircle, Clock, CreditCard, ShieldCheck, Eye, Trash2 } from 'lucide-react';
import { collection, onSnapshot, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useApp } from '../../context/AppContext';
import { DepositRequest } from '../../types';
import { updateDepositStatusInFirestore } from '../../lib/firestoreService';

export function DepositManager({ adminEmail }: { adminEmail: string }) {
  const { depositRequests: contextDeposits, approveCardActivation, pkrRate } = useApp();
  const [depositsList, setDepositsList] = useState<DepositRequest[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const [selectedRequest, setSelectedRequest] = useState<DepositRequest | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'deposits'), (snap) => {
      const list: DepositRequest[] = [];
      snap.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as DepositRequest);
      });
      setDepositsList(list);
    });

    return () => unsub();
  }, []);

  const effectiveList = depositsList.length > 0 ? depositsList : contextDeposits;

  const filtered = effectiveList.filter(d => {
    const matchSearch = 
      (d.userEmail || '').toLowerCase().includes(search.toLowerCase()) ||
      (d.userName || '').toLowerCase().includes(search.toLowerCase()) ||
      (d.trxId || '').toLowerCase().includes(search.toLowerCase()) ||
      (d.senderTitle || '').toLowerCase().includes(search.toLowerCase()) ||
      (d.senderNumber || '').toLowerCase().includes(search.toLowerCase()) ||
      (d.cardTitle || '').toLowerCase().includes(search.toLowerCase());
    
    const matchStatus = statusFilter === 'all' || d.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const handleProcessStatus = async (req: DepositRequest, status: 'approved' | 'rejected') => {
    try {
      await updateDepositStatusInFirestore(req.id, status, adminEmail, adminNote, pkrRate);
      if (status === 'approved') {
        approveCardActivation(req.cardId, req.userEmail);
      }
      setSelectedRequest(null);
      setAdminNote('');
    } catch (e) {
      console.warn('Updated deposit status:', e);
      if (status === 'approved') {
        approveCardActivation(req.cardId, req.userEmail);
      }
      setSelectedRequest(null);
    }
  };

  const handleDeleteRequest = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'deposits', id));
      setDepositsList(prev => prev.filter(d => d.id !== id));
      setSelectedRequest(null);
    } catch (err) {
      console.error('Delete error:', err);
      setDepositsList(prev => prev.filter(d => d.id !== id));
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto text-slate-100 pb-12">
      {/* Header Banner */}
      <div className="p-8 bg-[#111827] border border-slate-800 rounded-[2rem] shadow-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-white flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/10 rounded-xl">
              <ArrowDownLeft className="w-8 h-8 text-emerald-400" />
            </div>
            <span>Payment Requests</span>
          </h2>
          <p className="text-sm text-slate-400 mt-2 max-w-md">Review user deposits, verify TRX IDs, and manage account upgrades in real-time.</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[280px]">
            <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <input 
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search email, TRX ID, name..."
              className="w-full pl-12 pr-4 py-3.5 bg-[#1e293b] border border-slate-700 rounded-2xl text-sm text-white outline-none focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all"
            />
          </div>

          <select 
            value={statusFilter}
            onChange={(e: any) => setStatusFilter(e.target.value)}
            className="px-4 py-3.5 bg-[#1e293b] border border-slate-700 rounded-2xl text-sm text-white outline-none focus:border-emerald-500 transition-all cursor-pointer"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending Review</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Requests Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-[2rem] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-[#1e293b] text-slate-400 uppercase font-black text-[10px] tracking-widest border-b border-slate-800">
              <tr>
                <th className="p-6">Requester</th>
                <th className="p-6">Package Details</th>
                <th className="p-6">Transaction Sum</th>
                <th className="p-6">Verification Data</th>
                <th className="p-6">Current Status</th>
                <th className="p-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filtered.length > 0 ? (
                filtered.map((req) => (
                  <tr key={req.id} className="hover:bg-[#1e293b]/30 transition-colors">
                    <td className="p-6">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center font-black text-[10px] text-slate-500">
                          {req.userName ? req.userName[0].toUpperCase() : 'M'}
                        </div>
                        <div>
                          <span className="font-bold text-white block text-sm">{req.userName || 'Member'}</span>
                          <span className="text-[11px] text-slate-500">{req.userEmail}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-6">
                      <span className="font-black text-emerald-400 block text-xs">{req.cardTitle}</span>
                      <span className="text-[10px] text-slate-500 uppercase tracking-tighter font-mono">#{req.cardId.slice(-6)}</span>
                    </td>
                    <td className="p-6">
                      <div className="space-y-1">
                        <span className="font-black text-amber-400 text-base block leading-none">₨ {req.amountPkr.toLocaleString()}</span>
                        <span className="text-slate-500 text-[10px] uppercase font-bold block">≈ ${req.amountUsd} USD</span>
                      </div>
                    </td>
                    <td className="p-6 space-y-1">
                      <span className="font-mono text-emerald-300 font-bold block text-[11px]">ID: {req.trxId}</span>
                      <div className="flex flex-col">
                        <span className="text-slate-300 font-medium text-[10px]">{req.senderTitle}</span>
                        <span className="text-slate-500 text-[10px]">{req.senderNumber}</span>
                      </div>
                    </td>
                    <td className="p-6">
                      <span className={`px-4 py-1.5 font-black text-[10px] uppercase rounded-full inline-flex items-center space-x-2 border ${
                        req.status === 'pending' ? 'bg-amber-500/5 text-amber-400 border-amber-500/20' :
                        req.status === 'approved' ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/20' :
                        'bg-red-500/5 text-red-400 border-red-500/20'
                      }`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${
                          req.status === 'pending' ? 'bg-amber-400' :
                          req.status === 'approved' ? 'bg-emerald-400' :
                          'bg-red-400'
                        }`} />
                        <span>{req.status}</span>
                      </span>
                    </td>
                    <td className="p-6 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        {req.receiptUrl && (
                          <button 
                            onClick={() => setPreviewImage(req.receiptUrl || null)}
                            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all cursor-pointer"
                            title="View Screenshot"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        )}
                        <button 
                          onClick={() => setSelectedRequest(req)}
                          className="px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 font-black text-[10px] uppercase tracking-wider rounded-xl transition-all cursor-pointer"
                        >
                          Details
                        </button>
                        {deletingId === req.id ? (
                          <div className="flex flex-col space-y-1 animate-in fade-in duration-200">
                            <button 
                              onClick={async () => {
                                try {
                                  await handleDeleteRequest(req.id);
                                  alert('Deposit request deleted');
                                } catch (err) {
                                  alert('Delete failed');
                                }
                                setDeletingId(null);
                              }}
                              className="px-3 py-1.5 bg-red-600 text-white text-[9px] font-black uppercase rounded-lg shadow-lg"
                            >
                              Confirm
                            </button>
                            <button 
                              onClick={() => setDeletingId(null)}
                              className="px-3 py-1.5 bg-slate-800 text-slate-400 text-[9px] font-black uppercase rounded-lg"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setDeletingId(req.id)}
                            className="p-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl transition-all cursor-pointer border border-red-500/20"
                            title="Permanently Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-20 text-slate-600 text-sm font-bold">
                    No payment requests at this time.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PROCESS MODAL */}
      {selectedRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#111827] border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-white">Review Deposit Request</h3>
              <button onClick={() => setSelectedRequest(null)} className="text-slate-400 font-bold">✕</button>
            </div>

            <div className="p-4 bg-[#1e293b] rounded-2xl space-y-2 text-xs">
              <p><strong>User Name:</strong> {selectedRequest.userName}</p>
              <p><strong>User Email:</strong> {selectedRequest.userEmail}</p>
              <p><strong>Package Card:</strong> {selectedRequest.cardTitle} (${selectedRequest.amountUsd} USD / ₨ {selectedRequest.amountPkr} PKR)</p>
              <p><strong>Sender Title:</strong> {selectedRequest.senderTitle}</p>
              <p><strong>Sender Mobile / Acc #:</strong> {selectedRequest.senderNumber}</p>
              <p className="text-emerald-400 font-bold font-mono"><strong>TRX ID:</strong> {selectedRequest.trxId}</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Admin Verification Note</label>
              <input 
                type="text" 
                value={adminNote} 
                onChange={e => setAdminNote(e.target.value)}
                placeholder="e.g. Payment verified on JazzCash/Bank portal"
                className="w-full px-3.5 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button 
                onClick={() => handleProcessStatus(selectedRequest, 'approved')}
                className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer flex items-center justify-center space-x-1"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Approve Deposit</span>
              </button>
              <button 
                onClick={() => handleProcessStatus(selectedRequest, 'rejected')}
                className="py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl cursor-pointer flex items-center justify-center space-x-1"
              >
                <XCircle className="w-4 h-4" />
                <span>Reject Deposit</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RECEIPT PREVIEW MODAL */}
      {previewImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="bg-[#111827] border border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-4 relative">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white">Payment Screenshot Proof</h3>
              <button onClick={() => setPreviewImage(null)} className="text-slate-400 font-bold">✕</button>
            </div>
            <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900">
              <img src={previewImage} alt="Payment Receipt" className="w-full h-auto max-h-[70vh] object-contain mx-auto" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
