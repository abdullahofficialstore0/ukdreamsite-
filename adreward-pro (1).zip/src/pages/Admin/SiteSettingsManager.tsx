import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Settings, Save, ShieldAlert, CheckCircle2, Globe, Phone, Mail } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { updateSiteSettingsInFirestore } from '../../lib/firestoreService';

export function SiteSettingsManager() {
  const { siteSettings } = useApp();

  const [siteName, setSiteName] = useState(siteSettings.siteName || 'UK Dream');
  const [logoText, setLogoText] = useState(siteSettings.logoText || 'UK Dream');
  const [tagline, setTagline] = useState('Earn daily viewing video ads & build your network.');
  const [supportEmail, setSupportEmail] = useState(siteSettings.supportEmail || 'support@ukdream.com');
  const [supportPhone, setSupportPhone] = useState(siteSettings.supportPhone || '+92 309 1236267');
  const [maintenanceMode, setMaintenanceMode] = useState(siteSettings.maintenanceMode || false);

  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const updated = {
      siteName,
      logoText,
      supportEmail,
      supportPhone,
      maintenanceMode
    };

    await updateSiteSettingsInFirestore(updated, 'admin@ukdream.com');
    setSaving(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto text-slate-100">
      <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center space-x-2">
            <Settings className="w-7 h-7 text-emerald-400" />
            <span>Site & Branding Configurations</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Control system branding, contact info, and maintenance mode status.</p>
        </div>

        {savedSuccess && (
          <div className="px-4 py-2 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-bold rounded-xl flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings Updated Live!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Branding & Info */}
        <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4">
          <h3 className="text-lg font-bold text-white flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Globe className="w-5 h-5 text-emerald-400" />
            <span>General Platform Info</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Platform Name</label>
              <input 
                type="text" 
                required 
                value={siteName} 
                onChange={e => setSiteName(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Logo Text</label>
              <input 
                type="text" 
                required 
                value={logoText} 
                onChange={e => setLogoText(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Support Email</label>
              <input 
                type="email" 
                required 
                value={supportEmail} 
                onChange={e => setSupportEmail(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Support Phone / WhatsApp</label>
              <input 
                type="text" 
                required 
                value={supportPhone} 
                onChange={e => setSupportPhone(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs font-mono"
              />
            </div>
          </div>
        </div>

        {/* Maintenance Mode */}
        <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4">
          <h3 className="text-lg font-bold text-white flex items-center space-x-2 border-b border-slate-800 pb-3">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <span>Maintenance Mode Control</span>
          </h3>

          <div className="flex items-center justify-between p-4 bg-[#1e293b] rounded-2xl border border-slate-700">
            <div>
              <h4 className="font-bold text-white text-sm">System Maintenance Mode</h4>
              <p className="text-xs text-slate-400">When enabled, user panel displays a system maintenance notice.</p>
            </div>

            <button 
              type="button"
              onClick={() => setMaintenanceMode(!maintenanceMode)}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                maintenanceMode ? 'bg-red-500 text-white shadow-lg shadow-red-500/20' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {maintenanceMode ? 'Maintenance ENABLED' : 'Maintenance DISABLED'}
            </button>
          </div>
        </div>

        <button 
          type="submit"
          disabled={saving}
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-2xl shadow-lg shadow-emerald-500/20 text-sm transition-all flex items-center justify-center space-x-2 cursor-pointer"
        >
          {saving ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <>
              <Save className="w-5 h-5" />
              <span>Save System Settings</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
