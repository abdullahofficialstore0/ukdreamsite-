import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CreditCard, Tag, Sparkles, Youtube, Phone, MessageSquare, Facebook, Instagram, ShieldCheck, Save, CheckCircle2, AlertCircle, Percent } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { updateSiteSettingsInFirestore } from '../../lib/firestoreService';

export function CardOffersManager() {
  const { siteSettings } = useApp();

  // Business Card Prices State
  const [starterPrice, setStarterPrice] = useState(siteSettings.starterCardPricePkr ?? 700);
  const [goldPrice, setGoldPrice] = useState(siteSettings.goldCardPricePkr ?? 1400);
  const [premiumPrice, setPremiumPrice] = useState(siteSettings.premiumCardPricePkr ?? 2100);
  const [royalPrice, setRoyalPrice] = useState(siteSettings.royalCardPricePkr ?? 3000);

  // Special Sunday / Discount Offer State
  const [specialOfferActive, setSpecialOfferActive] = useState(siteSettings.specialOfferActive ?? false);
  const [specialOfferTitle, setSpecialOfferTitle] = useState(siteSettings.specialOfferTitle ?? 'Sunday Special Offer');
  const [specialOfferDiscountPercent, setSpecialOfferDiscountPercent] = useState(siteSettings.specialOfferDiscountPercent ?? 20);
  const [specialOfferNote, setSpecialOfferNote] = useState(siteSettings.specialOfferNote ?? 'Get 20% instant discount on all Business Card activations today!');

  // Social Media Links State
  const [socialYoutube, setSocialYoutube] = useState(siteSettings.socialYoutube ?? 'https://youtube.com/@ukdreamofficial');
  const [socialWhatsapp, setSocialWhatsapp] = useState(siteSettings.socialWhatsapp ?? 'https://wa.me/923001234567');
  const [socialTelegram, setSocialTelegram] = useState(siteSettings.socialTelegram ?? 'https://t.me/ukdream');
  const [socialFacebook, setSocialFacebook] = useState(siteSettings.socialFacebook ?? 'https://facebook.com');
  const [socialInstagram, setSocialInstagram] = useState(siteSettings.socialInstagram ?? 'https://instagram.com');
  const [socialTiktok, setSocialTiktok] = useState(siteSettings.socialTiktok ?? 'https://tiktok.com');

  // FBR Certificate State
  const [fbrCertificateEnabled, setFbrCertificateEnabled] = useState(siteSettings.fbrCertificateEnabled ?? true);
  const [fbrCertificateNumber, setFbrCertificateNumber] = useState(siteSettings.fbrCertificateNumber ?? 'NTN: 8940125-9 / FBR Reg: UKD-2026-PRO');
  const [fbrCertificateImage, setFbrCertificateImage] = useState(siteSettings.fbrCertificateImage ?? '');

  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const updatedSettings = {
      starterCardPricePkr: Number(starterPrice),
      goldCardPricePkr: Number(goldPrice),
      premiumCardPricePkr: Number(premiumPrice),
      royalCardPricePkr: Number(royalPrice),
      specialOfferActive,
      specialOfferTitle,
      specialOfferDiscountPercent: Number(specialOfferDiscountPercent),
      specialOfferNote,
      socialYoutube,
      socialWhatsapp,
      socialTelegram,
      socialFacebook,
      socialInstagram,
      socialTiktok,
      fbrCertificateEnabled,
      fbrCertificateNumber,
      fbrCertificateImage
    };

    await updateSiteSettingsInFirestore(updatedSettings, 'admin@ukdream.com');
    setSaving(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto text-slate-100 font-sans">
      {/* Title Header */}
      <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Admin Pricing & Social Control</span>
          </div>
          <h2 className="text-2xl font-black text-white flex items-center space-x-2">
            <CreditCard className="w-7 h-7 text-emerald-400" />
            <span>Card Prices, Sunday Offers & Social Links</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Yahan se aap kisi bhi Business Card ki price kam/zyada kar sakte hain, Sunday offer set kar sakte hain, aur YouTube/Social Media links aur FBR Certificate manage kar sakte hain.
          </p>
        </div>

        {savedSuccess && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="px-4 py-2.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-bold rounded-2xl flex items-center space-x-2 shadow-lg"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Tabdeeli Kamyaabi se Save Ho Gayi!</span>
          </motion.div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* SECTION 1: BUSINESS CARD PRICES (PKR) */}
        <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-lg font-extrabold text-white flex items-center space-x-2">
              <CreditCard className="w-5 h-5 text-blue-400" />
              <span>1. Business Card Prices Manager (PKR Me Price Set Karein)</span>
            </h3>
            <span className="text-[11px] text-slate-400 font-medium">Real-time Users Ko Show Hoga</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Starter Card */}
            <div className="p-4 bg-[#1e293b] border border-slate-700 rounded-2xl space-y-2">
              <span className="text-xs font-bold text-blue-400 block uppercase">Starter Business Card</span>
              <label className="text-[11px] text-slate-400 block font-semibold">Price (PKR):</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₨</span>
                <input 
                  type="number"
                  required
                  value={starterPrice}
                  onChange={e => setStarterPrice(Number(e.target.value))}
                  className="w-full pl-8 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold text-sm outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* Gold Card */}
            <div className="p-4 bg-[#1e293b] border border-slate-700 rounded-2xl space-y-2">
              <span className="text-xs font-bold text-amber-400 block uppercase">Golden Business Card</span>
              <label className="text-[11px] text-slate-400 block font-semibold">Price (PKR):</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₨</span>
                <input 
                  type="number"
                  required
                  value={goldPrice}
                  onChange={e => setGoldPrice(Number(e.target.value))}
                  className="w-full pl-8 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold text-sm outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Premium Card */}
            <div className="p-4 bg-[#1e293b] border border-slate-700 rounded-2xl space-y-2">
              <span className="text-xs font-bold text-purple-400 block uppercase">Premium Business Card</span>
              <label className="text-[11px] text-slate-400 block font-semibold">Price (PKR):</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₨</span>
                <input 
                  type="number"
                  required
                  value={premiumPrice}
                  onChange={e => setPremiumPrice(Number(e.target.value))}
                  className="w-full pl-8 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold text-sm outline-none focus:border-purple-500"
                />
              </div>
            </div>

            {/* Royal Card */}
            <div className="p-4 bg-[#1e293b] border border-slate-700 rounded-2xl space-y-2">
              <span className="text-xs font-bold text-emerald-400 block uppercase">Royal Business Card</span>
              <label className="text-[11px] text-slate-400 block font-semibold">Price (PKR):</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₨</span>
                <input 
                  type="number"
                  required
                  value={royalPrice}
                  onChange={e => setRoyalPrice(Number(e.target.value))}
                  className="w-full pl-8 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold text-sm outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 2: SUNDAY / SPECIAL DAY DISCOUNT OFFER */}
        <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-lg font-extrabold text-white flex items-center space-x-2">
              <Tag className="w-5 h-5 text-amber-400" />
              <span>2. Special Offer / Sunday Discount Offer (Khaas Din Ki Discount Offer)</span>
            </h3>

            <button
              type="button"
              onClick={() => setSpecialOfferActive(!specialOfferActive)}
              className={`px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                specialOfferActive 
                  ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20' 
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {specialOfferActive ? 'OFFER ACTIVE (ON)' : 'OFFER INACTIVE (OFF)'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Offer Title (Nam):</label>
              <input 
                type="text"
                value={specialOfferTitle}
                onChange={e => setSpecialOfferTitle(e.target.value)}
                placeholder="e.g. Sunday Mega Offer 20% OFF"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Discount Percent (% OFF):</label>
              <div className="relative">
                <input 
                  type="number"
                  min="0"
                  max="100"
                  value={specialOfferDiscountPercent}
                  onChange={e => setSpecialOfferDiscountPercent(Number(e.target.value))}
                  placeholder="20"
                  className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white font-bold text-xs outline-none focus:border-amber-500"
                />
                <Percent className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-300 mb-1">Offer Notification Message (Users Ko Dikhega):</label>
              <input 
                type="text"
                value={specialOfferNote}
                onChange={e => setSpecialOfferNote(e.target.value)}
                placeholder="e.g. Special 20% discount on all Business Card activations today!"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Offer Preview Box */}
          {specialOfferActive && (
            <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-between text-xs text-amber-200">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong>Preview:</strong> Business Card prices par <strong>{specialOfferDiscountPercent}% discount</strong> lag ke show hoga!
                </span>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 3: SOCIAL MEDIA LINKS & YOUTUBE CHANNEL */}
        <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4 shadow-sm">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-lg font-extrabold text-white flex items-center space-x-2">
              <Youtube className="w-5 h-5 text-red-500" />
              <span>3. Social Media Links & YouTube Channel (Aapke Social Media Icons)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Users in icons par click karke aapke channel/page/group par jayenge.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* YouTube Link */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center space-x-1.5">
                <Youtube className="w-4 h-4 text-red-500" />
                <span>YouTube Channel URL:</span>
              </label>
              <input 
                type="url"
                value={socialYoutube}
                onChange={e => setSocialYoutube(e.target.value)}
                placeholder="https://youtube.com/@yourchannel"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-red-500"
              />
            </div>

            {/* WhatsApp Link */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center space-x-1.5">
                <MessageSquare className="w-4 h-4 text-emerald-500" />
                <span>WhatsApp Group / Help Link:</span>
              </label>
              <input 
                type="url"
                value={socialWhatsapp}
                onChange={e => setSocialWhatsapp(e.target.value)}
                placeholder="https://wa.me/923001234567"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-emerald-500"
              />
            </div>

            {/* Telegram Link */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center space-x-1.5">
                <Phone className="w-4 h-4 text-sky-400" />
                <span>Telegram Channel URL:</span>
              </label>
              <input 
                type="url"
                value={socialTelegram}
                onChange={e => setSocialTelegram(e.target.value)}
                placeholder="https://t.me/yourchannel"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-sky-500"
              />
            </div>

            {/* Facebook Link */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center space-x-1.5">
                <Facebook className="w-4 h-4 text-blue-500" />
                <span>Facebook Page URL:</span>
              </label>
              <input 
                type="url"
                value={socialFacebook}
                onChange={e => setSocialFacebook(e.target.value)}
                placeholder="https://facebook.com/yourpage"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-blue-500"
              />
            </div>

            {/* Instagram Link */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center space-x-1.5">
                <Instagram className="w-4 h-4 text-pink-500" />
                <span>Instagram Profile URL:</span>
              </label>
              <input 
                type="url"
                value={socialInstagram}
                onChange={e => setSocialInstagram(e.target.value)}
                placeholder="https://instagram.com/yourprofile"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-pink-500"
              />
            </div>

            {/* TikTok Link */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center space-x-1.5">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>TikTok Profile URL:</span>
              </label>
              <input 
                type="url"
                value={socialTiktok}
                onChange={e => setSocialTiktok(e.target.value)}
                placeholder="https://tiktok.com/@yourprofile"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-cyan-500"
              />
            </div>
          </div>
        </div>

        {/* SECTION 4: FBR CERTIFICATE CONTROL */}
        <div className="p-6 bg-[#111827] border border-slate-800 rounded-3xl space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-lg font-extrabold text-white flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>4. FBR Certificate Manager (Government Verification Badge)</span>
            </h3>

            <button
              type="button"
              onClick={() => setFbrCertificateEnabled(!fbrCertificateEnabled)}
              className={`px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                fbrCertificateEnabled 
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' 
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {fbrCertificateEnabled ? 'FBR BADGE SHOWN' : 'FBR BADGE HIDDEN'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">FBR Registration / NTN Details:</label>
              <input 
                type="text"
                value={fbrCertificateNumber}
                onChange={e => setFbrCertificateNumber(e.target.value)}
                placeholder="NTN: 8940125-9 / FBR Reg: UKD-2026-PRO"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none font-mono focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Custom FBR Certificate Image URL (Optional):</label>
              <input 
                type="url"
                value={fbrCertificateImage}
                onChange={e => setFbrCertificateImage(e.target.value)}
                placeholder="https://.../fbr_certificate.jpg (Leave blank to use official system template)"
                className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl text-white text-xs outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* SAVE BUTTON */}
        <button 
          type="submit"
          disabled={saving}
          className="w-full py-4 bg-gradient-to-r from-emerald-500 via-teal-600 to-blue-600 hover:from-emerald-600 hover:to-blue-700 text-white font-extrabold rounded-2xl shadow-xl shadow-emerald-500/20 text-sm transition-all flex items-center justify-center space-x-2 cursor-pointer active:scale-[0.99]"
        >
          {saving ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <>
              <Save className="w-5 h-5" />
              <span>Tamam Settings Aur Prices Save Karein</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
