import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Tv, 
  CreditCard, 
  Wallet, 
  Users, 
  Megaphone, 
  Settings, 
  LogOut, 
  ShieldCheck,
  ChevronRight,
  Menu,
  X,
  ArrowLeft,
  ArrowDownLeft,
  Tag,
  Share2
} from 'lucide-react';
import { AdminLogin } from './AdminLogin';
import { AdminDashboard } from './AdminDashboard';
import { CampaignManager } from './CampaignManager';
import { PaymentSettings } from './PaymentSettings';
import { WithdrawalManager } from './WithdrawalManager';
import { DepositManager } from './DepositManager';
import { UserManager } from './UserManager';
import { NotificationManager } from './NotificationManager';
import { SiteSettingsManager } from './SiteSettingsManager';
import { AnnouncementManager } from './AnnouncementManager';
import { CardOffersManager } from './CardOffersManager';
import { useNavigate } from 'react-router-dom';

export function AdminPanel() {
  const navigate = useNavigate();
  const [adminUser, setAdminUser] = useState<{ email: string; name: string } | null>(null);
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'deposits' | 'card-offers' | 'campaigns' | 'payments' | 'withdrawals' | 'users' | 'notifications' | 'announcements' | 'settings'
  >('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  if (!adminUser) {
    return <AdminLogin onSuccess={(data) => setAdminUser(data)} />;
  }

  const navItems = [
    { id: 'dashboard', label: 'Dashboard Overview', icon: LayoutDashboard },
    { id: 'deposits', label: 'Deposit Requests (Card Approval)', icon: ArrowDownLeft },
    { id: 'card-offers', label: 'Card Prices, Offers & Social Links', icon: Tag },
    { id: 'withdrawals', label: 'Withdrawal Requests', icon: Wallet },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'campaigns', label: 'Video Ads Manager', icon: Tv },
    { id: 'announcements', label: 'Post Announcements', icon: Megaphone },
    { id: 'payments', label: 'Bank & Payment Accounts', icon: CreditCard },
    { id: 'notifications', label: 'System Alerts & Push', icon: ShieldCheck },
    { id: 'settings', label: 'Site Name & Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col md:flex-row font-sans">
      {/* Mobile Top Nav Header */}
      <div className="md:hidden bg-[#111827] border-b border-slate-800 p-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center font-black text-white text-xs shadow-md">
            UK
          </div>
          <span className="font-bold text-white text-sm tracking-tight">UK Dream Admin Console</span>
        </div>

        <button 
          onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          className="p-2 text-slate-400 hover:text-white"
        >
          {isMobileSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Sidebar Navigation */}
      <aside className={`
        fixed md:static inset-y-0 left-0 z-50 w-72 bg-[#111827] border-r border-slate-800 flex flex-col justify-between p-6 transition-transform duration-300
        ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="space-y-6">
          {/* Logo / Header */}
          <div className="flex items-center space-x-3 border-b border-slate-800 pb-5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-black text-white text-sm tracking-wide">UK Dream Admin</h2>
              <span className="text-[10px] text-emerald-400 font-mono font-bold block uppercase tracking-wider">Aasaan Management Panel</span>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as any);
                    setIsMobileSidebarOpen(false);
                  }}
                  className={`
                    w-full px-3.5 py-3 rounded-2xl text-xs font-bold transition-all flex items-center justify-between group cursor-pointer text-left
                    ${isActive 
                      ? 'bg-gradient-to-r from-emerald-500 via-teal-600 to-blue-600 text-white shadow-lg shadow-emerald-500/20' 
                      : 'text-slate-400 hover:text-white hover:bg-[#1e293b]'
                    }
                  `}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'}`} />
                    <span className="leading-snug">{item.label}</span>
                  </div>
                  {isActive && <ChevronRight className="w-4 h-4 text-white/80 shrink-0" />}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer actions */}
        <div className="space-y-2.5 pt-5 border-t border-slate-800">
          <button 
            onClick={() => navigate('/')}
            className="w-full py-2.5 px-3 bg-[#1e293b] hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>App (User Side) Par Jayen</span>
          </button>

          <button 
            onClick={() => setAdminUser(null)}
            className="w-full py-2.5 px-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout Karein</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-8 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'dashboard' && <AdminDashboard />}
            {activeTab === 'deposits' && <DepositManager adminEmail={adminUser.email} />}
            {activeTab === 'card-offers' && <CardOffersManager />}
            {activeTab === 'campaigns' && <CampaignManager />}
            {activeTab === 'payments' && <PaymentSettings />}
            {activeTab === 'withdrawals' && <WithdrawalManager />}
            {activeTab === 'users' && <UserManager />}
            {activeTab === 'notifications' && <NotificationManager />}
            {activeTab === 'announcements' && <AnnouncementManager />}
            {activeTab === 'settings' && <SiteSettingsManager />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
