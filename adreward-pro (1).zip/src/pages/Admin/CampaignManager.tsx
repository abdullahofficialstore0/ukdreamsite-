import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Tv, Plus, Edit2, Trash2, CheckCircle2, XCircle, Video, Image, Clock, DollarSign, Calendar } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Campaign } from '../../types';
import { saveCampaignInFirestore, deleteCampaignInFirestore } from '../../lib/firestoreService';

export function CampaignManager() {
  const { campaigns, siteSettings, deleteCampaign } = useApp();
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [thumbnail, setThumbnail] = useState('https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800');
  const [duration, setDuration] = useState(15);
  const [rewardAmount, setRewardAmount] = useState(0.27);
  const [rewardPkr, setRewardPkr] = useState(75);
  const [category, setCategory] = useState('Technology');
  const [status, setStatus] = useState<'active' | 'disabled'>('active');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const openCreateModal = () => {
    setEditingCampaign(null);
    setTitle('');
    setDescription('');
    setVideoUrl('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4');
    setThumbnail('https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800');
    setDuration(15);
    setRewardAmount(0.27);
    setRewardPkr(75);
    setCategory('Technology');
    setStatus('active');
    setStartDate('');
    setEndDate('');
    setIsModalOpen(true);
  };

  const openEditModal = (camp: Campaign) => {
    setEditingCampaign(camp);
    setTitle(camp.title);
    setDescription(camp.description);
    setVideoUrl(camp.videoUrl || '');
    setThumbnail(camp.thumbnail || 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800');
    setDuration(camp.duration || 15);
    setRewardAmount(camp.rewardAmount);
    setRewardPkr(camp.rewardPkr || 75);
    setCategory(camp.category || 'General');
    setStatus(camp.status || 'active');
    setStartDate(camp.startDate || '');
    setEndDate(camp.endDate || '');
    setIsModalOpen(true);
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setVideoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = editingCampaign ? editingCampaign.id : `ad-${Date.now()}`;

    const updatedCampaign: Campaign = {
      id,
      title,
      description,
      thumbnail,
      videoUrl,
      duration: Number(duration),
      rewardAmount: Number(rewardAmount),
      rewardPkr: Number(rewardPkr),
      remainingAvailability: 1000,
      category,
      status,
      startDate,
      endDate
    };

    await saveCampaignInFirestore(updatedCampaign, 'admin@ukdream.com');
    setIsModalOpen(false);
  };

  const handleDelete = async (campaignId: string) => {
    try {
      await deleteCampaignInFirestore(campaignId, 'admin@ukdream.com');
      deleteCampaign(campaignId);
    } catch (e) {
      console.error('Delete error:', e);
      deleteCampaign(campaignId);
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 p-8 bg-[#111827] border border-slate-800 rounded-[2rem] shadow-2xl">
        <div>
          <h2 className="text-3xl font-black text-white flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/10 rounded-xl">
              <Tv className="w-8 h-8 text-emerald-400" />
            </div>
            <span>Campaign Manager</span>
          </h2>
          <p className="text-sm text-slate-400 mt-2 max-w-md">Create and configure video ad campaigns. Set reward amounts, schedule durations, and manage content visibility.</p>
        </div>

        <button 
          onClick={openCreateModal}
          className="px-6 py-4 bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-xl shadow-emerald-500/20 flex items-center justify-center space-x-2 shrink-0 cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>Launch Campaign</span>
        </button>
      </div>

      {/* Campaigns Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
        {campaigns.map((camp) => (
          <div 
            key={camp.id}
            className={`group p-6 rounded-[2rem] bg-[#111827] border transition-all shadow-2xl flex flex-col justify-between space-y-6 ${
              camp.status === 'disabled' ? 'border-red-500/20 grayscale' : 'border-slate-800 hover:border-emerald-500/40 hover:shadow-emerald-500/5'
            }`}
          >
            <div>
              <div className="relative h-48 rounded-3xl overflow-hidden mb-5 bg-slate-900 border border-slate-800">
                <img src={camp.thumbnail} alt={camp.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60" />
                <span className={`absolute top-4 right-4 px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-full shadow-2xl border ${
                  camp.status === 'disabled' ? 'bg-red-500/20 text-red-400 border-red-500/40' : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                }`}>
                  {camp.status || 'active'}
                </span>
                <div className="absolute bottom-4 left-4 flex items-center space-x-2">
                  <span className="px-3 py-1 bg-black/60 backdrop-blur-xl text-[10px] font-black text-white rounded-lg border border-white/10 uppercase tracking-tighter">
                    {camp.duration}s
                  </span>
                  <span className="px-3 py-1 bg-black/60 backdrop-blur-xl text-[10px] font-black text-emerald-400 rounded-lg border border-emerald-400/20 uppercase tracking-tighter">
                    {camp.category}
                  </span>
                </div>
              </div>

              <h3 className="font-black text-white text-lg mb-2 leading-tight">{camp.title}</h3>
              <p className="text-sm text-slate-500 line-clamp-2 mb-5 leading-relaxed">{camp.description}</p>

              <div className="grid grid-cols-2 gap-4 p-4 bg-[#1e293b]/50 rounded-2xl border border-slate-700/30">
                <div>
                  <span className="text-slate-500 block text-[10px] font-bold uppercase tracking-widest mb-1">Rewards</span>
                  <span className="font-black text-emerald-400 text-base block">₨ {camp.rewardPkr || 75}</span>
                  <span className="text-slate-500 text-[10px] font-mono">${camp.rewardAmount} USD</span>
                </div>
                <div className="text-right border-l border-slate-700/50 pl-4">
                  <span className="text-slate-500 block text-[10px] font-bold uppercase tracking-widest mb-1">Availability</span>
                  <span className="font-black text-white text-base block">{camp.remainingAvailability || '1,000+'}</span>
                  <span className="text-slate-500 text-[10px] font-mono">REMAINING</span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3 pt-4 border-t border-slate-800">
              <button 
                onClick={() => openEditModal(camp)}
                className="flex-1 py-3.5 bg-[#1e293b] hover:bg-slate-700 text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-lg"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Configure</span>
              </button>
              {deletingId === camp.id ? (
                <div className="flex items-center space-x-2 animate-in fade-in zoom-in">
                  <button 
                    onClick={async () => {
                      try {
                        await handleDelete(camp.id);
                        alert('Campaign deleted successfully');
                      } catch (err) {
                        alert('Delete failed');
                      }
                      setDeletingId(null);
                    }}
                    className="px-4 py-2 bg-red-600 text-white text-[10px] font-black uppercase rounded-lg active:scale-95 shadow-lg shadow-red-500/20"
                  >
                    Confirm Delete
                  </button>
                  <button 
                    onClick={() => setDeletingId(null)}
                    className="px-4 py-2 bg-slate-800 text-slate-400 text-[10px] font-black uppercase rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button 
                  onClick={() => setDeletingId(camp.id)}
                  className="p-3.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-bold rounded-xl transition-all cursor-pointer border border-red-500/20"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* CREATE / EDIT CAMPAIGN MODAL */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#111827] border border-slate-800 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-8 text-slate-100"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-4">
                <h3 className="text-lg font-bold text-white">
                  {editingCampaign ? 'Edit Video Campaign' : 'Create New Video Campaign'}
                </h3>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center font-bold"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Campaign Title</label>
                  <input 
                    type="text" 
                    required 
                    value={title} 
                    onChange={e => setTitle(e.target.value)}
                    placeholder="e.g. Electric Vehicle Tech Showcase 2026"
                    className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Thumbnail URL</label>
                  <input 
                    type="url" 
                    required 
                    value={thumbnail} 
                    onChange={e => setThumbnail(e.target.value)}
                    placeholder="e.g. https://images.unsplash.com/..."
                    className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Ad Video File (Upload MP4)</label>
                  <div className="flex flex-col space-y-2">
                    <div className="relative group">
                      <input 
                        type="file" 
                        accept="video/*"
                        onChange={handleVideoUpload}
                        className="hidden"
                        id="video-upload"
                      />
                      <label 
                        htmlFor="video-upload"
                        className="w-full px-4 py-4 bg-slate-800/50 border-2 border-dashed border-slate-700 rounded-2xl flex flex-col items-center justify-center cursor-pointer group-hover:border-emerald-500/50 group-hover:bg-slate-800 transition-all"
                      >
                        <Video className="w-8 h-8 text-slate-500 group-hover:text-emerald-400 mb-2" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 group-hover:text-emerald-400">
                          {videoUrl.startsWith('data:') ? 'Video Selected ✅' : 'Click to Upload Video File'}
                        </span>
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-px bg-slate-800 flex-1"></div>
                      <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">OR</span>
                      <div className="h-px bg-slate-800 flex-1"></div>
                    </div>
                    <input 
                      type="url" 
                      value={videoUrl.startsWith('data:') ? '' : videoUrl} 
                      onChange={e => setVideoUrl(e.target.value)}
                      placeholder="Paste MP4 Video URL instead"
                      className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Description</label>
                  <textarea 
                    rows={2}
                    required 
                    value={description} 
                    onChange={e => setDescription(e.target.value)}
                    placeholder="Watch this 15-second ad completely to claim your reward."
                    className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Reward (PKR)</label>
                    <input 
                      type="number" 
                      required 
                      value={rewardPkr} 
                      onChange={e => setRewardPkr(Number(e.target.value))}
                      className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Reward (USD Equivalent)</label>
                    <input 
                      type="number" 
                      step="0.01"
                      required 
                      value={rewardAmount} 
                      onChange={e => setRewardAmount(Number(e.target.value))}
                      className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Video Duration (Seconds)</label>
                    <input 
                      type="number" 
                      required 
                      value={duration} 
                      onChange={e => setDuration(Number(e.target.value))}
                      className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Category</label>
                    <select 
                      value={category} 
                      onChange={e => setCategory(e.target.value)}
                      className="w-full px-4 py-2.5 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                    >
                      <option value="Technology">Technology</option>
                      <option value="Automotive">Automotive</option>
                      <option value="Finance">Finance</option>
                      <option value="Lifestyle">Lifestyle</option>
                      <option value="Gaming">Gaming</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Start Date</label>
                    <input 
                      type="date" 
                      value={startDate} 
                      onChange={e => setStartDate(e.target.value)}
                      className="w-full px-3 py-2 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">End Date</label>
                    <input 
                      type="date" 
                      value={endDate} 
                      onChange={e => setEndDate(e.target.value)}
                      className="w-full px-3 py-2 bg-[#1e293b] border border-slate-700 rounded-xl outline-none text-white text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Campaign Status</label>
                  <div className="flex space-x-4 pt-1">
                    <label className="inline-flex items-center space-x-2 text-xs cursor-pointer">
                      <input 
                        type="radio" 
                        name="status" 
                        value="active" 
                        checked={status === 'active'} 
                        onChange={() => setStatus('active')}
                        className="text-emerald-500" 
                      />
                      <span>Active</span>
                    </label>
                    <label className="inline-flex items-center space-x-2 text-xs cursor-pointer">
                      <input 
                        type="radio" 
                        name="status" 
                        value="disabled" 
                        checked={status === 'disabled'} 
                        onChange={() => setStatus('disabled')}
                        className="text-red-500" 
                      />
                      <span>Disabled</span>
                    </label>
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/20 text-xs transition-all cursor-pointer mt-4"
                >
                  Save Campaign Changes
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
