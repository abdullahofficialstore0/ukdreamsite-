import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Users, Copy, CheckCircle2, Trophy, Sparkles, RefreshCw, Gift, ShieldCheck } from 'lucide-react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useApp } from '../context/AppContext';

export function Referrals() {
  const { referralEarnings, user, setUser } = useApp();
  const [copiedCode, setCopiedCode] = useState(false);
  const [referralsList, setReferralsList] = useState<any[]>([]);

  const userRefCode = user?.referralCode || `UKD-${Math.floor(1000 + Math.random() * 9000)}`;

  // Real-time synchronization for referrals from Firestore
  useEffect(() => {
    if (!user?.email) return;

    // 1. Initial fallback from user object or local storage
    if (user.referralsList && Array.isArray(user.referralsList) && user.referralsList.length > 0) {
      setReferralsList(user.referralsList);
    } else {
      const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      const currentUserData = storedUsers[user.email];
      if (currentUserData?.referralsList) {
        setReferralsList(currentUserData.referralsList);
      }
    }

    // 2. Real-time Firestore query for all users referred by this user's email
    const qReferred = query(collection(db, 'users'), where('referredByEmail', '==', user.email));
    const unsubReferred = onSnapshot(qReferred, (snap) => {
      if (!snap.empty) {
        const liveList: any[] = [];
        snap.forEach(docSnap => {
          const uData = docSnap.data();
          const isCardActive = Boolean(uData.activeCardId && uData.activeCardId !== 'unactivated');
          liveList.push({
            name: uData.name || 'Member',
            email: uData.email,
            date: uData.memberSince || 'Recently',
            reward: isCardActive ? 80 : 0,
            packageActivated: isCardActive
          });
        });
        setReferralsList(liveList);
      }
    }, (err) => {
      console.warn('Referred query notice:', err);
    });

    // 3. Also listen to referrer's own user document in Firestore
    const qMe = query(collection(db, 'users'), where('email', '==', user.email));
    const unsubMe = onSnapshot(qMe, (snap) => {
      if (!snap.empty) {
        const myData = snap.docs[0].data();
        if (myData.referralsList && Array.isArray(myData.referralsList) && myData.referralsList.length > 0) {
          setReferralsList(prev => {
            if (prev.length === 0) return myData.referralsList;
            return prev.map((p: any) => {
              const matchedFromMe = myData.referralsList.find((m: any) => m.email === p.email);
              if (matchedFromMe && matchedFromMe.packageActivated) {
                return { ...p, packageActivated: true };
              }
              return p;
            });
          });
        }
      }
    });

    return () => {
      unsubReferred();
      unsubMe();
    };
  }, [user?.email, userRefCode]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(userRefCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleRegenerateCode = () => {
    if (!user) return;
    const cleanName = (user.name || 'UKD').replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 4) || 'UKD';
    const newCode = `${cleanName}-${Math.floor(1000 + Math.random() * 9000)}`;
    
    // Update local storage and app state
    const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
    if (storedUsers[user.email]) {
      storedUsers[user.email].referralCode = newCode;
      localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
    }
    
    setUser({ ...user, referralCode: newCode });
  };

  const totalInvites = referralsList.length;

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-20">
      {/* Hero Banner */}
      <div className="bg-gradient-to-br from-indigo-900 via-blue-900 to-slate-900 rounded-[2.5rem] p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl border border-blue-500/20">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/3"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-indigo-500/10 blur-3xl rounded-full translate-y-1/2 -translate-x-1/3"></div>
        
        <div className="relative z-10 max-w-2xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-blue-500/20 border border-blue-400/30 rounded-full text-blue-300 text-xs font-bold uppercase tracking-wider mb-6">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span>UK Dream Official Affiliate Program</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4 tracking-tighter">
            Earn ₨ 80 PKR Reward
          </h2>
          <p className="text-blue-100 text-base sm:text-lg mb-8 leading-relaxed opacity-90">
            Share your unique Referral Code with friends. When they register using your code and activate their Business Card, you get <strong className="text-emerald-400">₨ 80 PKR</strong> instantly!
          </p>

          {/* Referral Code Box */}
          <div className="space-y-4 max-w-md mx-auto">
            <div className="p-5 bg-white/10 backdrop-blur-3xl rounded-3xl border border-white/20 flex items-center justify-between shadow-2xl">
              <div className="text-left pl-2">
                <span className="text-[10px] uppercase font-black text-blue-300 block tracking-widest mb-0.5">Your Referral Code</span>
                <span className="font-mono text-2xl font-black text-white tracking-widest">{userRefCode}</span>
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={handleRegenerateCode}
                  title="Generate New Code"
                  className="p-3 bg-white/10 hover:bg-white/20 text-blue-200 rounded-2xl transition-all"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
                <button 
                  onClick={handleCopyCode}
                  className="px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-blue-600/30 flex items-center space-x-2"
                >
                  {copiedCode ? <CheckCircle2 className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
                </button>
              </div>
            </div>

            <p className="text-[11px] text-blue-200 font-medium">
              Friends can enter code <strong className="font-mono text-white">{userRefCode}</strong> during registration.
            </p>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {[
          { label: 'Total Affiliates', value: totalInvites, icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10' },
          { label: 'Joining Reward', value: '₨ 80', icon: Gift, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
          { label: 'Total Profits', value: `$${referralEarnings.toFixed(2)}`, icon: Trophy, color: 'text-amber-500', bg: 'bg-amber-500/10' },
        ].map((stat, i) => (
          <div key={i} className="p-8 rounded-[2.5rem] bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-xl text-center group hover:border-blue-500/50 transition-all duration-300">
            <div className={`w-16 h-16 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-lg group-hover:scale-110 transition-transform duration-500`}>
              <stat.icon className="w-8 h-8" />
            </div>
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] mb-2">{stat.label}</p>
            <h3 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter">{stat.value}</h3>
          </div>
        ))}
      </div>

      {/* Referral History List */}
      <div className="rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Invited Members History</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Track friends who signed up using your Referral Code.</p>
          </div>
          <span className="text-xs font-bold px-3 py-1 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-full border border-emerald-200 dark:border-emerald-500/20">
            {totalInvites} Total
          </span>
        </div>
        
        {totalInvites > 0 ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {referralsList.map((ref, idx) => (
              <div key={idx} className="p-4 sm:px-6 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold flex items-center justify-center text-sm">
                    {ref.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">{ref.name}</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{ref.email}</p>
                  </div>
                </div>
                <div className="text-right">
                  {ref.packageActivated ? (
                    <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 block">+₨ 80 PKR</span>
                  ) : (
                    <span className="text-xs font-bold text-amber-500 block">Card Pending</span>
                  )}
                  <span className="text-[10px] text-slate-400">{ref.date || 'Recently'}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center flex flex-col items-center">
            <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
              <Users className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">No referrals yet</h3>
            <p className="text-slate-500 dark:text-slate-400 max-w-sm text-sm">
              Share your custom Referral Code (<strong>{userRefCode}</strong>) with friends. You will earn ₨ 80 PKR as soon as they activate their Business Card!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
