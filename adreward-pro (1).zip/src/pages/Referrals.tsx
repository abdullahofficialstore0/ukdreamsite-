import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Users, Copy, CheckCircle2, Trophy, Share2, Sparkles, RefreshCw, Gift } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function Referrals() {
  const { referralEarnings, user, setUser } = useApp();
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [referralsList, setReferralsList] = useState<any[]>([]);

  const userRefCode = user?.referralCode || `UKD-${Math.floor(1000 + Math.random() * 9000)}-AI`;
  const referralLink = `${window.location.origin}/join?ref=${userRefCode}`;

  // Fetch referrals list from localStorage
  useEffect(() => {
    if (user?.email) {
      const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      const currentUserData = storedUsers[user.email];
      if (currentUserData?.referralsList) {
        setReferralsList(currentUserData.referralsList);
      }
    }
  }, [user]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(userRefCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleRegenerateCode = () => {
    if (!user) return;
    const cleanName = (user.name || 'UKD').replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 4) || 'UKD';
    const newCode = `${cleanName}-${Math.floor(1000 + Math.random() * 9000)}-AI`;
    
    // Update local storage and app state
    const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
    if (storedUsers[user.email]) {
      storedUsers[user.email].referralCode = newCode;
      localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
    }
    
    setUser({ ...user, referralCode: newCode });
  };

  const totalInvites = referralsList.length;
  const calculatedEarnings = totalInvites * 0.50 || referralEarnings;

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Hero Banner */}
      <div className="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl border border-emerald-500/20">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/3"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-teal-500/10 blur-3xl rounded-full translate-y-1/2 -translate-x-1/3"></div>
        
        <div className="relative z-10 max-w-2xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-emerald-500/20 border border-emerald-400/30 rounded-full text-emerald-300 text-xs font-bold uppercase tracking-wider mb-6">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>AI Referral Rewards Engine</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-black text-white mb-3">Invite Friends & Earn $0.50 Instant Bonus</h2>
          <p className="text-emerald-100 text-base sm:text-lg mb-8 leading-relaxed">
            Share your unique AI referral link or Referral ID. Whenever a new user signs up using your link, ID, or email address, you instantly get <strong>$0.50 USD</strong> credited directly to your balance!
          </p>

          {/* AI Referral Code & Link Box */}
          <div className="space-y-4 max-w-lg mx-auto">
            {/* Unique Referral ID */}
            <div className="p-4 bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 flex items-center justify-between shadow-lg">
              <div className="text-left">
                <span className="text-[10px] uppercase font-bold text-emerald-300 block">Your Unique AI Referral ID</span>
                <span className="font-mono text-lg font-black text-white tracking-wider">{userRefCode}</span>
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={handleRegenerateCode}
                  className="p-2 bg-white/10 hover:bg-white/20 text-emerald-200 rounded-xl transition-all"
                  title="Generate New AI Code"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
                <button 
                  onClick={handleCopyCode}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl transition-all flex items-center space-x-1"
                >
                  {copiedCode ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedCode ? 'Copied' : 'Copy ID'}</span>
                </button>
              </div>
            </div>

            {/* Referral Link Input */}
            <div className="bg-white/10 backdrop-blur-xl p-2 rounded-2xl flex flex-col sm:flex-row items-center border border-white/20 shadow-xl">
              <input 
                type="text" 
                readOnly 
                value={referralLink} 
                className="w-full bg-transparent text-white px-4 py-3 outline-none font-mono text-xs sm:text-sm text-center sm:text-left truncate"
              />
              <button 
                onClick={handleCopyLink}
                className="w-full sm:w-auto mt-2 sm:mt-0 px-6 py-3 bg-white text-emerald-950 hover:bg-emerald-50 font-bold rounded-xl transition-colors flex items-center justify-center space-x-2 text-sm shadow-md shrink-0"
              >
                {copiedLink ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <Share2 className="w-5 h-5 text-emerald-700" />}
                <span>{copiedLink ? 'Copied Link!' : 'Copy Link'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm text-center">
          <div className="w-12 h-12 bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Users className="w-6 h-6" />
          </div>
          <p className="text-xs font-semibold uppercase text-slate-400 mb-1">Total Invites</p>
          <h3 className="text-3xl font-extrabold text-slate-900 dark:text-white">{totalInvites}</h3>
        </div>

        <div className="p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm text-center">
          <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Gift className="w-6 h-6" />
          </div>
          <p className="text-xs font-semibold uppercase text-slate-400 mb-1">Reward Rate</p>
          <h3 className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">$0.50 / User</h3>
        </div>

        <div className="p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm text-center">
          <div className="w-12 h-12 bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Trophy className="w-6 h-6" />
          </div>
          <p className="text-xs font-semibold uppercase text-slate-400 mb-1">Total Earned</p>
          <h3 className="text-3xl font-extrabold text-slate-900 dark:text-white">${calculatedEarnings.toFixed(2)}</h3>
        </div>
      </div>

      {/* Referral History List */}
      <div className="rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Invited Users</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Users who joined through your AI referral code or link.</p>
          </div>
          <span className="text-xs font-bold px-3 py-1 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-full border border-emerald-200 dark:border-emerald-500/20">
            {totalInvites} Total
          </span>
        </div>
        
        {totalInvites > 0 ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {referralsList.map((ref, idx) => (
              <div key={idx} className="p-4 sm:px-6 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold flex items-center justify-center text-sm">
                    {ref.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">{ref.name}</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{ref.email}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 block">+${ref.reward?.toFixed(2) || '0.50'}</span>
                  <span className="text-[10px] text-slate-400">{ref.date || 'Recently'}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center flex flex-col items-center">
            <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
              <Users className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">No referrals yet</h3>
            <p className="text-slate-500 dark:text-slate-400 max-w-sm text-sm">
              Share your custom AI referral ID (<strong>{userRefCode}</strong>) or referral link with friends. You will earn $0.50 instantly when they register!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
