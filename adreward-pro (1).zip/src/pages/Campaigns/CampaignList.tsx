import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Filter, Play, Clock, Target, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const categories = ['All', 'Technology', 'Finance', 'Lifestyle', 'Automotive', 'Gaming'];

export function CampaignList() {
  const { campaigns } = useApp();
  const [activeCat, setActiveCat] = useState('All');

  const filteredCampaigns = campaigns.filter(c => activeCat === 'All' || c.category === activeCat);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Available Campaigns</h2>
          <p className="text-slate-500 dark:text-slate-400">Watch premium advertisements and earn rewards instantly.</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search..." 
              className="pl-9 pr-4 py-2 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:border-blue-500 outline-none w-full md:w-48 text-slate-900 dark:text-white transition-colors"
            />
          </div>
          <button className="p-2 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-lg text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
            <Filter className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4 md:mx-0 md:px-0 space-x-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCat(cat)}
            className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              activeCat === cat 
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20' 
                : 'bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {filteredCampaigns.length === 0 ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center justify-center py-20 px-4 text-center rounded-3xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-[#111827]/50"
        >
          <div className="w-20 h-20 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-6 text-slate-400">
            <Play className="w-10 h-10" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">No campaigns available</h3>
          <p className="text-slate-500 dark:text-slate-400 max-w-md">
            No campaigns are available right now. Please check back later.
          </p>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCampaigns.map((campaign, i) => (
            <motion.div
              key={campaign.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-xl hover:border-blue-500/30 transition-all duration-300 flex flex-col"
            >
              <div className="relative h-48 overflow-hidden">
                <img src={campaign.thumbnail} alt={campaign.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                
                <div className="absolute top-3 right-3 px-3 py-1 bg-black/50 backdrop-blur-md text-white text-sm font-bold rounded-full border border-white/10">
                  ${campaign.rewardAmount.toFixed(2)}
                </div>
                
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-sm">
                  <span className="font-medium px-2 py-1 bg-white/20 backdrop-blur-md rounded-md">{campaign.category}</span>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{campaign.duration}s</span>
                  </div>
                </div>
              </div>
              
              <div className="p-5 flex-1 flex flex-col">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">{campaign.title}</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 flex-1">{campaign.description}</p>
                
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex flex-col">
                    <span className="text-xs text-slate-400 uppercase font-semibold tracking-wider">Available</span>
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{campaign.remainingAvailability} left</span>
                  </div>
                  
                  <Link to={`/campaigns/watch/${campaign.id}`} className="px-4 py-2 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-600 hover:text-white text-blue-600 dark:text-blue-400 text-sm font-bold rounded-lg transition-colors flex items-center space-x-2">
                    <Play className="w-4 h-4 fill-current" />
                    <span>Watch</span>
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
