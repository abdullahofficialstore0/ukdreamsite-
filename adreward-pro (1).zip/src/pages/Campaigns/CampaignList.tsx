import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Play, Clock, CheckCircle2, ShieldCheck, CreditCard, Sparkles, AlertTriangle, ArrowRight, RefreshCw } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

export function CampaignList() {
  const { campaigns, hasActiveCard, resetDailyAds, businessCards, user, pkrRate } = useApp();
  const navigate = useNavigate();

  // Daily limit is fixed at 5 ads as requested
  const maxDailyAds = 5;

  // Plan-based rewards (PKR)
  let rewardPerAd = 50;
  let currentPlan = 'Starter';
  
  if (user?.activeCardId === 'gold') {
    rewardPerAd = 70;
    currentPlan = 'Golden';
  } else if (user?.activeCardId === 'premium') {
    rewardPerAd = 85;
    currentPlan = 'Premium';
  } else if (user?.activeCardId === 'royal') {
    rewardPerAd = 95;
    currentPlan = 'Royal';
  }

  // Filter ads:
  // 1. Only show ads NOT in the user's watchedAds list
  // 2. Limit to total ads possible today (maxDailyAds - today's count)
  const watchedAdsList = user?.watchedAds || [];
  const today = new Date().toLocaleDateString();
  const dailyAdsWatchedCount = user?.lastWatchDate === today ? (user?.dailyAdsWatched || 0) : 0;
  
  const availableCampaigns = campaigns.filter(c => !watchedAdsList.includes(c.id));
  const activeCampaigns = availableCampaigns.slice(0, Math.max(0, maxDailyAds - dailyAdsWatchedCount));

  // 24 Hour Countdown State
  const [timeLeft, setTimeLeft] = useState({ hours: 23, minutes: 59, seconds: 59 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 23, minutes: 59, seconds: 59 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const allWatched = dailyAdsWatchedCount >= maxDailyAds;

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-950 rounded-3xl p-8 sm:p-10 text-white relative overflow-hidden shadow-xl border border-blue-500/20">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/3"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-emerald-500/20 border border-emerald-400/30 rounded-full text-emerald-300 text-xs font-bold uppercase tracking-wider mb-3">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>{currentPlan} Member</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold mb-2">Watch Real UK Video Ads</h1>
            <p className="text-blue-100 text-sm sm:text-base max-w-xl">
              Earn <strong>₨ {rewardPerAd} PKR</strong> for every 15-second video ad. Daily potential income: <strong>₨ {maxDailyAds * rewardPerAd} PKR</strong>.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-center shrink-0">
            <span className="text-[10px] uppercase font-bold text-blue-200 block">Today's Progress</span>
            <span className="text-2xl font-black text-white">{dailyAdsWatchedCount} / {maxDailyAds}</span>
            <span className="text-[11px] text-emerald-300 block font-semibold mt-0.5">Ads Watched</span>
          </div>
        </div>
      </div>

      {/* NOT ACTIVATED BUSINESS CARD NOTICE */}
      {!hasActiveCard ? (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-8 sm:p-10 rounded-3xl bg-amber-50 dark:bg-amber-500/10 border-2 border-amber-300 dark:border-amber-500/30 text-center space-y-6 shadow-xl"
        >
          <div className="w-20 h-20 bg-amber-500 text-white rounded-full flex items-center justify-center mx-auto shadow-lg shadow-amber-500/30">
            <CreditCard className="w-10 h-10" />
          </div>

          <div className="max-w-md mx-auto space-y-2">
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              First Activate Your Business Card
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
              To start watching daily video ads and earn <strong>₨ {rewardPerAd} PKR (${(rewardPerAd / pkrRate).toFixed(2)})</strong> per ad, you must first activate your Business Card package.
            </p>
          </div>

          <div className="pt-2">
            <button 
              onClick={() => navigate('/business-card')}
              className="px-8 py-4 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-base rounded-2xl shadow-xl shadow-amber-500/20 transition-all flex items-center space-x-2 mx-auto active:scale-95 group"
            >
              <span>Go to Business Card Section</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </motion.div>
      ) : (
        /* CARD IS ACTIVE - SHOW ADS & STATUS */
        <div className="space-y-6">
          {/* ALL ADS WATCHED 24-HOUR NOTICE */}
          {allWatched && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8 rounded-3xl bg-emerald-500/10 border-2 border-emerald-500/30 text-center space-y-4 shadow-lg"
            >
              <div className="w-16 h-16 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-1">
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                  Have you seen all ads?
                </h3>
                <p className="text-slate-600 dark:text-slate-300 text-sm max-w-md mx-auto font-medium">
                  Great job! You have watched all 5 video ads for today. 5 new ads will reset automatically in 24 hours.
                </p>
              </div>

              {/* 24-Hour Countdown Timer Display */}
              <div className="inline-flex items-center space-x-3 bg-slate-900 text-white px-6 py-3 rounded-2xl font-mono text-lg font-bold shadow-md">
                <Clock className="w-5 h-5 text-emerald-400 animate-pulse" />
                <span>
                  {String(timeLeft.hours).padStart(2, '0')}h : {String(timeLeft.minutes).padStart(2, '0')}m : {String(timeLeft.seconds).padStart(2, '0')}s
                </span>
              </div>

              <div className="pt-2">
                <button 
                  onClick={resetDailyAds}
                  className="px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition-all inline-flex items-center space-x-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset Ads Now (Demo Test)</span>
                </button>
              </div>
            </motion.div>
          )}

          {/* EMPTY CAMPAIGNS FROM ADMIN NOTICE */}
          {!allWatched && activeCampaigns.length === 0 && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-8 sm:p-12 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 text-center space-y-4 shadow-sm"
            >
              <div className="w-16 h-16 bg-blue-500/10 text-blue-500 rounded-full flex items-center justify-center mx-auto">
                <AlertTriangle className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  No Ads Available Right Now
                </h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm max-w-md mx-auto font-medium">
                  No ads available from admin right now. Please wait for new ads to be published.
                </p>
              </div>
            </motion.div>
          )}

          {/* DAILY ADS GRID */}
          {activeCampaigns.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {activeCampaigns.map((ad) => {
                const isWatched = ad.watched;

                return (
                  <div 
                    key={ad.id}
                    className={`rounded-3xl bg-white dark:bg-[#111827] border overflow-hidden shadow-sm transition-all flex flex-col justify-between ${
                      isWatched 
                        ? 'border-emerald-300 dark:border-emerald-500/30 opacity-80' 
                        : 'border-slate-200 dark:border-slate-800 hover:border-blue-500/40 hover:shadow-xl'
                    }`}
                  >
                    <div className="relative h-44 overflow-hidden bg-slate-900">
                      <img 
                        src={ad.thumbnail} 
                        alt={ad.title} 
                        className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-transform duration-500" 
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                      <div className="absolute top-3 right-3 px-3 py-1 bg-emerald-500 text-white text-xs font-black rounded-full shadow-md">
                        ₨ {rewardPerAd} PKR
                      </div>

                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs font-bold">
                        <span className="px-2.5 py-1 bg-white/20 backdrop-blur-md rounded-lg">{ad.category}</span>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{ad.duration}s</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                      <div>
                        <h3 className="text-base font-extrabold text-slate-900 dark:text-white mb-1">{ad.title}</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{ad.description}</p>
                      </div>

                      <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                        {isWatched ? (
                          <div className="w-full py-2.5 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold text-xs rounded-xl flex items-center justify-center space-x-1.5 border border-emerald-200 dark:border-emerald-500/20">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Ad Completed (₨ {rewardPerAd} Earned)</span>
                          </div>
                        ) : (
                          <Link 
                            to={`/campaigns/watch/${ad.id}`}
                            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5 active:scale-95"
                          >
                            <Play className="w-4 h-4 fill-current" />
                            <span>Watch Video Ad (15s)</span>
                          </Link>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
