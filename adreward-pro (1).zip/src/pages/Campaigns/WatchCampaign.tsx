import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, Maximize, X, CheckCircle2, ShieldCheck, RefreshCw, AlertTriangle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import confetti from 'canvas-confetti';

export function WatchCampaign() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { campaigns, markAdWatched, user, pkrRate } = useApp();
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [claimed, setClaimed] = useState(false);
  const [videoError, setVideoError] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const lastElapsedRef = useRef(0);

  // Check user daily watch limit (5 ads)
  const today = new Date().toLocaleDateString();
  const dailyAdsWatchedCount = user?.lastWatchDate === today ? (user?.dailyAdsWatched || 0) : 0;
  const isLimitReached = dailyAdsWatchedCount >= 5;

  // Plan-based rewards (PKR)
  let rewardPkr = 50;
  if (user?.activeCardId === 'gold') {
    rewardPkr = 70;
  } else if (user?.activeCardId === 'premium') {
    rewardPkr = 85;
  } else if (user?.activeCardId === 'royal') {
    rewardPkr = 95;
  }

  const rewardUsd = parseFloat((rewardPkr / (pkrRate || 278.5)).toFixed(2));

  const campaign = campaigns.find(c => c.id === id) || campaigns[0] || {
    id: 'ad-1',
    title: 'Campaign Ad',
    rewardAmount: rewardUsd,
    rewardPkr: rewardPkr,
    duration: 15,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800'
  };

  const duration = campaign.duration || 15;

  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Video progress and guaranteed timer handler
  useEffect(() => {
    let interval: any = null;
    if (isPlaying && !completed) {
      interval = setInterval(() => {
        let currentSec = lastElapsedRef.current;
        
        // If HTML5 video is actively playing and advancing
        if (videoRef.current && !videoRef.current.paused && videoRef.current.currentTime > 0) {
          currentSec = videoRef.current.currentTime;
        } else {
          // Guaranteed fallback timer if video is paused, buffering, or video element failed
          currentSec += 0.5;
        }

        lastElapsedRef.current = currentSec;
        const roundedSec = Math.min(duration, Math.floor(currentSec));
        const pct = Math.min(100, (currentSec / duration) * 100);

        setElapsedSeconds(roundedSec);
        setProgress(pct);

        if (currentSec >= duration) {
          setCompleted(true);
          setIsPlaying(false);
          setProgress(100);
          setElapsedSeconds(duration);
          if (videoRef.current) {
            try { videoRef.current.pause(); } catch (e) {}
          }
        }
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isPlaying, completed, duration]);

  const handleTimeUpdate = () => {
    if (videoRef.current && isPlaying) {
      const currentTime = videoRef.current.currentTime;
      if (currentTime > lastElapsedRef.current) {
        lastElapsedRef.current = currentTime;
        const pct = (currentTime / (videoRef.current.duration || duration)) * 100;
        setProgress(Math.min(100, pct));
        setElapsedSeconds(Math.min(duration, Math.floor(currentTime)));
      }
    }
  };

  const togglePlay = () => {
    if (completed) return;
    if (isPlaying) {
      if (videoRef.current) {
        try { videoRef.current.pause(); } catch (e) {}
      }
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      if (videoRef.current) {
        videoRef.current.play().catch(err => {
          console.warn('Video element play warning:', err);
          setVideoError(true);
        });
      }
    }
  };

  const claimReward = () => {
    if (id) {
      markAdWatched(id);
    }
    setClaimed(true);
    confetti({
      particleCount: 150,
      spread: 80,
      origin: { y: 0.6 },
      colors: ['#10B981', '#3B82F6', '#F59E0B']
    });
    setTimeout(() => navigate('/campaigns'), 2200);
  };

  const closePlayer = () => {
    if (completed && !claimed) {
      const confirmLeave = window.confirm("You haven't claimed your ₨ 75 reward yet! Are you sure you want to leave?");
      if (!confirmLeave) return;
    }
    navigate('/campaigns');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col select-none">
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 p-4 sm:p-6 flex items-center justify-between z-20 bg-gradient-to-b from-black/90 to-transparent">
        <div>
          <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Verified Video Ad</span>
          </div>
          <h2 className="text-white text-lg sm:text-xl font-black">{campaign.title}</h2>
          <p className="text-emerald-400 text-xs font-bold">Reward: ₨ {rewardPkr} PKR (${rewardUsd.toFixed(2)})</p>
        </div>
        <button onClick={closePlayer} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors backdrop-blur-md">
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Video Canvas Container */}
      <div className="flex-1 relative flex items-center justify-center bg-slate-950">
        {!videoError ? (
          <video 
            ref={videoRef}
            src={campaign.videoUrl || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'}
            poster={campaign.thumbnail}
            onTimeUpdate={handleTimeUpdate}
            onError={() => setVideoError(true)}
            onEnded={() => {
              setCompleted(true);
              setIsPlaying(false);
              setProgress(100);
            }}
            playsInline
            className="w-full h-full object-contain max-h-[85vh]"
          />
        ) : (
          <div className="relative w-full h-full max-h-[85vh] flex flex-col items-center justify-center bg-slate-900 text-center p-6 space-y-4">
            <img src={campaign.thumbnail} alt={campaign.title} className="absolute inset-0 w-full h-full object-cover opacity-30" />
            <div className="relative z-10 p-6 bg-slate-900/90 backdrop-blur-xl border border-emerald-500/30 rounded-3xl space-y-3 max-w-md">
              <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                <RefreshCw className="w-8 h-8 animate-spin" />
              </div>
              <h3 className="text-lg font-bold text-white">Stream Simulator Active</h3>
              <p className="text-xs text-slate-300">
                Playing advertisement content. Reward will be unlocked automatically when countdown reaches 100%.
              </p>
            </div>
          </div>
        )}

        {!isPlaying && !completed && (
          <button 
            onClick={togglePlay} 
            className="absolute z-10 w-24 h-24 bg-emerald-600/90 hover:bg-emerald-500 text-white rounded-full flex items-center justify-center backdrop-blur-md shadow-[0_0_50px_rgba(16,185,129,0.6)] transition-all hover:scale-110 cursor-pointer"
          >
            <Play className="w-10 h-10 ml-2 fill-current" />
          </button>
        )}

        {/* Completion Modal Overlay */}
        <AnimatePresence>
          {isLimitReached && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute z-40 inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
            >
              <div className="p-8 bg-slate-900 border border-amber-500/40 rounded-3xl text-center max-w-sm w-full shadow-2xl space-y-4">
                <div className="w-20 h-20 bg-amber-500/20 border border-amber-500/30 text-amber-400 rounded-full flex items-center justify-center mx-auto">
                  <AlertTriangle className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white">Daily Limit Reached</h3>
                  <p className="text-slate-300 text-sm mt-2 leading-relaxed">
                    Your daily limit of 5 ads has been completed! Please check back tomorrow.
                  </p>
                </div>

                <button 
                  onClick={() => navigate('/campaigns')} 
                  className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-sm rounded-2xl shadow-xl transition-all active:scale-95 cursor-pointer"
                >
                  Back To Campaigns
                </button>
              </div>
            </motion.div>
          )}

          {completed && !claimed && !isLimitReached && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute z-30 p-8 bg-slate-900/90 backdrop-blur-2xl border border-emerald-500/40 rounded-3xl text-center max-w-sm w-full mx-4 shadow-2xl space-y-4"
            >
              <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(16,185,129,0.6)] text-white">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <div>
                <h3 className="text-2xl font-black text-white">Ad Finished!</h3>
                <p className="text-slate-300 text-sm mt-1">You have completely watched this 15s advertisement.</p>
              </div>

              <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/30 text-emerald-400 font-extrabold text-lg">
                + ₨ {rewardPkr} PKR (${rewardUsd.toFixed(2)})
              </div>

              <button 
                onClick={claimReward} 
                className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white font-black text-base rounded-2xl shadow-xl transition-all active:scale-95 flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>Claim ₨ {rewardPkr} Reward Now</span>
              </button>
            </motion.div>
          )}
          
          {claimed && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute z-30 p-8 bg-emerald-600 rounded-3xl text-center max-w-sm w-full mx-4 shadow-2xl flex flex-col items-center space-y-2 text-white"
            >
              <CheckCircle2 className="w-16 h-16 text-white" />
              <h3 className="text-2xl font-black">₨ {rewardPkr} Added To Balance!</h3>
              <p className="text-emerald-100 text-xs">Redirecting to campaign list...</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Control Bar & Timeline */}
      <div className="absolute bottom-0 left-0 right-0 p-6 z-20 bg-gradient-to-t from-black via-black/90 to-transparent space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-slate-300 px-1">
          <span className="flex items-center space-x-2 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>Watch Full {duration} Seconds Required</span>
          </span>
          <span className="font-mono text-white text-sm bg-white/10 px-3 py-1 rounded-full border border-white/10">
            {String(elapsedSeconds).padStart(2, '0')}s / {duration}s ({Math.floor(progress)}%)
          </span>
        </div>

        <div className="flex items-center space-x-4">
          <button 
            onClick={togglePlay} 
            disabled={completed} 
            className="p-3 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white rounded-2xl transition-all shadow-lg active:scale-95 shrink-0 cursor-pointer"
          >
            {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current" />}
          </button>
          
          <div className="flex-1 h-3 bg-white/20 rounded-full overflow-hidden p-0.5 border border-white/10">
            <div 
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300 ease-out shadow-[0_0_15px_rgba(16,185,129,0.8)]" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
}

