import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, Maximize, X, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import confetti from 'canvas-confetti';

export function WatchCampaign() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addBalance, campaigns } = useApp();
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [claimed, setClaimed] = useState(false);
  
  const campaign = campaigns.find(c => c.id === id) || {
    id: 'unknown',
    title: 'Global Tech Launch',
    rewardAmount: 2.50,
    duration: 30,
    thumbnail: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1920&q=80'
  };

  const duration = campaign.duration;
  const reward = campaign.rewardAmount;
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isPlaying && !completed) {
      intervalRef.current = setInterval(() => {
        setProgress(p => {
          if (p >= 100) {
            clearInterval(intervalRef.current!);
            setCompleted(true);
            setIsPlaying(false);
            return 100;
          }
          return p + (100 / (duration * 10)); // updating every 100ms
        });
      }, 100);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPlaying, completed, duration]);

  const togglePlay = () => {
    if (!completed) setIsPlaying(!isPlaying);
  };

  const claimReward = () => {
    addBalance(reward, campaign.title);
    setClaimed(true);
    confetti({
      particleCount: 150,
      spread: 80,
      origin: { y: 0.6 },
      colors: ['#10B981', '#3B82F6', '#F59E0B']
    });
    setTimeout(() => navigate('/campaigns'), 2500);
  };

  const closePlayer = () => {
    if (completed && !claimed) {
      const confirm = window.confirm("You haven't claimed your reward yet! Are you sure you want to leave?");
      if (!confirm) return;
    }
    navigate('/campaigns');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      <div className="absolute top-0 left-0 right-0 p-4 sm:p-6 flex items-center justify-between z-20 bg-gradient-to-b from-black/80 to-transparent">
        <div>
          <h2 className="text-white text-xl sm:text-2xl font-bold">{campaign.title}</h2>
          <p className="text-white/70 text-sm">Watch to earn ${reward.toFixed(2)}</p>
        </div>
        <button onClick={closePlayer} className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors backdrop-blur-md">
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 relative flex items-center justify-center">
        {/* Placeholder for actual video element */}
        <div className="absolute inset-0 bg-slate-900 flex items-center justify-center">
          <img src={campaign.thumbnail} alt="Video cover" className="absolute inset-0 w-full h-full object-cover opacity-40" />
          
          {!isPlaying && !completed && (
            <button onClick={togglePlay} className="z-10 w-24 h-24 bg-blue-600/90 hover:bg-blue-600 text-white rounded-full flex items-center justify-center backdrop-blur-md shadow-[0_0_50px_rgba(37,99,235,0.5)] transition-transform hover:scale-110">
              <Play className="w-10 h-10 ml-2 fill-current" />
            </button>
          )}
        </div>

        <AnimatePresence>
          {completed && !claimed && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute z-30 p-8 bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl text-center max-w-sm w-full mx-4 shadow-2xl"
            >
              <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_rgba(16,185,129,0.5)]">
                <CheckCircle2 className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Campaign Completed!</h3>
              <p className="text-white/80 mb-8">You've successfully watched the video.</p>
              <button onClick={claimReward} className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-lg rounded-xl shadow-lg transition-all transform hover:-translate-y-1">
                Claim ${reward.toFixed(2)} Reward
              </button>
            </motion.div>
          )}
          
          {claimed && (
             <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             className="absolute z-30 p-8 bg-emerald-500/90 backdrop-blur-xl rounded-3xl text-center max-w-sm w-full mx-4 shadow-2xl flex flex-col items-center"
           >
             <CheckCircle2 className="w-16 h-16 text-white mb-4" />
             <h3 className="text-2xl font-bold text-white mb-2">Reward Claimed!</h3>
             <p className="text-emerald-50">Added to your wallet.</p>
           </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 z-20 bg-gradient-to-t from-black to-transparent">
        <div className="flex items-center space-x-4 mb-2">
          <button onClick={togglePlay} disabled={completed} className="text-white hover:text-blue-400 disabled:opacity-50 transition-colors">
            {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current" />}
          </button>
          <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 transition-all duration-100 ease-linear" style={{ width: `${progress}%` }}></div>
          </div>
          <span className="text-white text-sm font-medium font-mono min-w-[60px] text-right">
            {Math.floor(progress)}%
          </span>
          <button className="text-white hover:text-blue-400 transition-colors hidden sm:block">
            <Maximize className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
