import React from 'react';
import { motion } from 'motion/react';
import { Wallet, TrendingUp, PlayCircle, Users, ArrowRight, Zap, Target, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Link } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function Dashboard() {
  const { walletBalance, todayEarnings, totalAdsWatched, referralEarnings, campaigns, user } = useApp();

  // Create an empty chart for new users
  const chartData = [
    { name: 'Mon', rewards: 0 },
    { name: 'Tue', rewards: 0 },
    { name: 'Wed', rewards: 0 },
    { name: 'Thu', rewards: 0 },
    { name: 'Fri', rewards: 0 },
    { name: 'Sat', rewards: 0 },
    { name: 'Sun', rewards: 0 },
  ];

  const stats = [
    { label: 'Wallet Balance', value: `$${walletBalance.toFixed(2)}`, icon: Wallet, trend: walletBalance > 0 ? '+12.5%' : '0.0%', color: 'from-blue-600 to-indigo-600', shadow: 'shadow-blue-500/20' },
    { label: 'Today\'s Earnings', value: `$${todayEarnings.toFixed(2)}`, icon: TrendingUp, trend: todayEarnings > 0 ? '+5.2%' : '0.0%', color: 'from-emerald-500 to-teal-500', shadow: 'shadow-emerald-500/20' },
    { label: 'Total Ads Watched', value: totalAdsWatched.toString(), icon: PlayCircle, trend: totalAdsWatched > 0 ? '+18 today' : '0 today', color: 'from-purple-500 to-pink-500', shadow: 'shadow-purple-500/20' },
    { label: 'Referral Earnings', value: `$${referralEarnings.toFixed(2)}`, icon: Users, trend: referralEarnings > 0 ? '4 new' : '0 new', color: 'from-amber-500 to-orange-500', shadow: 'shadow-amber-500/20' },
  ];

  const hasActivity = walletBalance > 0 || totalAdsWatched > 0;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-900 to-indigo-900 p-8 sm:p-10 text-white"
      >
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80')] opacity-10 bg-cover bg-center mix-blend-overlay"></div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/3"></div>
        
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-6 text-sm font-medium">
            <Zap className="w-4 h-4 text-yellow-400" />
            <span>Daily Streak: {hasActivity ? '14 Days' : '0 Days'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Welcome back, {user?.name?.split(' ')[0] || 'User'}!</h2>
          <p className="text-blue-100 text-lg mb-8 max-w-xl">
            {hasActivity 
              ? "You're on a roll. Complete 3 more premium campaigns today to unlock the weekly gold bonus."
              : "Ready to start earning? Watch your first campaign today to build your streak!"}
          </p>
          <div className="flex flex-wrap gap-4">
            <Link to="/campaigns" className="px-6 py-3 bg-white text-blue-900 font-semibold rounded-xl hover:bg-blue-50 transition-colors shadow-lg shadow-black/20 flex items-center space-x-2">
              <PlayCircle className="w-5 h-5" />
              <span>Watch & Earn</span>
            </Link>
            <Link to="/wallet/withdraw" className="px-6 py-3 bg-white/10 backdrop-blur-md border border-white/20 text-white font-semibold rounded-xl hover:bg-white/20 transition-colors flex items-center space-x-2">
              <Wallet className="w-5 h-5" />
              <span>Withdraw</span>
            </Link>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden group"
          >
            <div className="flex justify-between items-start mb-4 relative z-10">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">{stat.label}</p>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{stat.value}</h3>
              </div>
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} ${stat.shadow} flex items-center justify-center text-white shadow-lg`}>
                <stat.icon className="w-6 h-6" />
              </div>
            </div>
            <div className="inline-flex items-center space-x-1 text-sm font-medium text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded-md">
              <TrendingUp className="w-3 h-3" />
              <span>{stat.trend}</span>
            </div>
            
            {/* Hover decorative element */}
            <div className={`absolute -bottom-16 -right-16 w-32 h-32 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500 rounded-full blur-2xl`}></div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Earnings Overview</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Your performance this week</p>
            </div>
            <select className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-sm rounded-lg px-3 py-2 outline-none">
              <option>This Week</option>
              <option>Last Week</option>
              <option>This Month</option>
            </select>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRewards" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.2} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dx={-10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area type="monotone" dataKey="rewards" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorRewards)" activeDot={{ r: 6, strokeWidth: 0, fill: '#3b82f6' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Recent Activity & Campaigns */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Hot Campaigns</h3>
            <Link to="/campaigns" className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline">View All</Link>
          </div>
          
          <div className="space-y-4 flex-1">
            {campaigns.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center p-4">
                <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4 text-slate-400">
                  <Search className="w-8 h-8" />
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm">No campaigns are available right now. Please check back later.</p>
              </div>
            ) : (
              campaigns.slice(0, 3).map((campaign) => (
                <div key={campaign.id} className="group flex items-center space-x-4 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-white/5 transition-colors border border-transparent hover:border-slate-200 dark:hover:border-slate-700/50 cursor-pointer">
                  <div className="relative w-16 h-12 rounded-lg overflow-hidden flex-shrink-0">
                    <img src={campaign.thumbnail} alt={campaign.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <PlayCircle className="w-6 h-6 text-white opacity-80 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">{campaign.title}</h4>
                    <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
                      <Target className="w-3 h-3" />
                      <span>{campaign.duration}s duration</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="block text-sm font-bold text-emerald-600 dark:text-emerald-400">+${campaign.rewardAmount.toFixed(2)}</span>
                  </div>
                </div>
              ))
            )}
          </div>
          
          {campaigns.length > 0 && (
            <Link to="/campaigns" className="w-full mt-4 py-3 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-100 dark:hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 font-semibold rounded-xl transition-colors flex items-center justify-center space-x-2">
              <span>Start Watching</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          )}
        </motion.div>
      </div>
    </div>
  );
}
