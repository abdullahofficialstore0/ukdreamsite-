import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Wallet, TrendingUp, PlayCircle, Users, ArrowRight, Zap, CreditCard, Sparkles, CheckCircle2, Megaphone, ShieldCheck, ArrowUpRight, Award } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Link } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { FbrCertificateModal } from '../components/FbrCertificateModal';

export function Dashboard() {
  const { walletBalance, todayEarnings, totalAdsWatched, referralEarnings, campaigns, user, hasActiveCard, businessCards, announcements, pkrRate, siteSettings } = useApp();
  const [isFbrModalOpen, setIsFbrModalOpen] = useState(false);

  const activeCard = businessCards.find(c => c.status === 'active') || (user?.activeCardId ? businessCards.find(c => c.id === user.activeCardId) : null);

  // Filter announcements for this page
  const pageAnnouncements = announcements.filter(a => a.targetPage === 'dashboard' || a.targetPage === 'all');

  const chartData = [
    { name: 'Mon', rewards: 0 },
    { name: 'Tue', rewards: 0 },
    { name: 'Wed', rewards: 0 },
    { name: 'Thu', rewards: 0 },
    { name: 'Fri', rewards: 0 },
    { name: 'Sat', rewards: 0 },
    { name: 'Sun', rewards: todayEarnings * pkrRate },
  ];

  let rewardPerAd = 50;
  if (user?.activeCardId === 'gold') rewardPerAd = 70;
  else if (user?.activeCardId === 'premium') rewardPerAd = 85;
  else if (user?.activeCardId === 'royal') rewardPerAd = 95;

  const walletBalancePkr = (walletBalance * pkrRate).toFixed(0);
  const todayEarningsPkr = (todayEarnings * pkrRate).toFixed(0);

  const stats = [
    { label: 'Wallet Balance', value: `₨ ${walletBalancePkr} PKR`, icon: Wallet, trend: `$${walletBalance.toFixed(2)} USD`, color: 'from-blue-600 to-indigo-600', shadow: 'shadow-blue-500/20' },
    { label: 'Today\'s Earnings', value: `₨ ${todayEarningsPkr} PKR`, icon: TrendingUp, trend: `$${todayEarnings.toFixed(2)} USD`, color: 'from-emerald-500 to-teal-500', shadow: 'shadow-emerald-500/20' },
    { label: 'Ads Progress', value: `${totalAdsWatched} / 5 Completed`, icon: PlayCircle, trend: `₨ ${rewardPerAd}/Ad Rate`, color: 'from-purple-500 to-pink-500', shadow: 'shadow-purple-500/20' },
    { label: 'Affiliate Profit', value: `₨ ${(referralEarnings * pkrRate).toFixed(0)} PKR`, icon: Users, trend: `$${referralEarnings.toFixed(2)} USD`, color: 'from-amber-500 to-orange-500', shadow: 'shadow-amber-500/20' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-24">
      {/* Official FBR Trust Badge Banner */}
      {siteSettings?.fbrCertificateEnabled !== false && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-4"
        >
          <div className="absolute top-0 right-0 w-60 h-60 bg-emerald-500/10 blur-3xl rounded-full pointer-events-none"></div>
          <div className="flex items-center space-x-3.5 relative z-10">
            <div className="w-11 h-11 bg-emerald-500/20 border border-emerald-400/30 rounded-2xl flex items-center justify-center shrink-0 shadow-inner">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-extrabold text-[9px] uppercase tracking-wider rounded-md border border-emerald-500/30">FBR Registered</span>
                <span className="text-[10px] text-emerald-400/80 font-mono font-bold">Govt Tax Compliance</span>
              </div>
              <h3 className="text-sm sm:text-base font-black text-white mt-0.5">FBR Official Registered Platform</h3>
              <p className="text-xs text-slate-300">Verified taxpayer digital ad network in Pakistan.</p>
            </div>
          </div>
          
          <button
            onClick={() => setIsFbrModalOpen(true)}
            className="w-full sm:w-auto px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs rounded-xl transition-all shadow-md flex items-center justify-center space-x-2 shrink-0 cursor-pointer active:scale-95 relative z-10"
          >
            <Award className="w-4 h-4 text-slate-950" />
            <span>View Certificate</span>
          </button>
        </motion.div>
      )}

      {/* Announcements Slider/List */}
      {pageAnnouncements.length > 0 && (
        <div className="space-y-4">
          {pageAnnouncements.map((ann) => (
            <motion.div 
              key={ann.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white dark:bg-[#111827] border border-blue-500/20 rounded-2xl overflow-hidden shadow-md"
            >
              <div className="flex flex-col md:flex-row">
                {ann.imageUrl && (
                  <div className="md:w-1/3 h-48 md:h-auto overflow-hidden">
                    <img src={ann.imageUrl} alt={ann.title} className="w-full h-full object-cover" />
                  </div>
                )}
                <div className="p-5 flex-1 space-y-2">
                  <div className="flex items-center space-x-2 text-blue-500 dark:text-blue-400">
                    <Megaphone className="w-4 h-4" />
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">Latest Announcement</span>
                  </div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white">{ann.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{ann.message}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Dynamic Balance Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-gradient-to-br from-slate-900 via-[#0f172a] to-slate-950 text-white border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden group"
      >
        <div className="absolute top-0 right-0 w-72 h-72 bg-emerald-500/10 blur-[90px] rounded-full group-hover:bg-emerald-500/15 transition-all duration-700 pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 rounded-full text-[10px] font-bold text-emerald-300 uppercase tracking-wider mb-3">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>Verified Account Balance</span>
            </div>
            <h2 className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">Total Account Liquidity</h2>
            <div className="flex items-baseline space-x-3">
              <span className="text-4xl sm:text-5xl font-black text-white tracking-tight">₨ {walletBalancePkr}</span>
              <span className="text-emerald-400 text-base sm:text-lg font-bold font-mono">PKR</span>
            </div>
            <p className="text-slate-400 text-xs font-semibold mt-2 flex items-center space-x-2">
              <span>≈ ${walletBalance.toFixed(2)} USD</span>
              <span className="w-1.5 h-1.5 rounded-full bg-slate-700" />
              <span className="text-[10px] uppercase text-emerald-400">Instant Withdrawal Ready</span>
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-3">
            <Link to="/wallet/withdraw" className="flex-1 sm:flex-none px-6 py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-slate-950 font-black text-xs rounded-2xl transition-all flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/20 active:scale-95 cursor-pointer">
              <Wallet className="w-4 h-4 text-slate-950" />
              <span>Withdraw Funds</span>
            </Link>
            <Link to="/history" className="flex-1 sm:flex-none px-5 py-3.5 bg-slate-800/80 hover:bg-slate-700 text-white font-bold text-xs rounded-2xl transition-all flex items-center justify-center space-x-1.5 border border-slate-700/80 active:scale-95">
              <span>Transactions</span>
              <ArrowUpRight className="w-4 h-4 text-slate-400" />
            </Link>
          </div>
        </div>
      </motion.div>

      {/* Welcome Banner */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-900/40 via-slate-900 to-slate-950 p-6 sm:p-8 text-white shadow-xl border border-blue-500/20"
      >
        <div className="relative z-10">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div>
              <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-full bg-blue-500/20 border border-blue-500/30 mb-3 text-[10px] font-black text-blue-300 uppercase tracking-[0.2em]">
                <Zap className="w-3 h-3 text-amber-400" />
                <span>Account Status</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black mb-1 text-slate-100">Welcome, {user?.name || 'User'}</h2>
              <p className="text-slate-300 text-xs sm:text-sm font-medium max-w-lg leading-relaxed">
                {hasActiveCard 
                  ? "Your Business Card is active! Complete your 5 daily video ads to maximize earnings."
                  : "Activate your Business Card now to unlock daily video ads and instant withdrawals."}
              </p>
            </div>
            
            <div className="flex shrink-0">
              {!hasActiveCard ? (
                <Link to="/business-card" className="px-5 py-3 bg-white text-slate-950 font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-emerald-50 transition-all flex items-center space-x-2 shadow-xl active:scale-95">
                  <CreditCard className="w-4 h-4" />
                  <span>Activate Card</span>
                </Link>
              ) : (
                <div className="px-5 py-3 bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-black text-xs uppercase tracking-widest rounded-2xl flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Package Active</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Quick Action Icons Row */}
      <div className="grid grid-cols-4 gap-3 sm:gap-6">
        {[
          { label: 'Ads', path: '/campaigns', icon: PlayCircle, color: 'bg-emerald-500/10 text-emerald-500', border: 'border-emerald-500/20' },
          { label: 'Cards', path: '/business-card', icon: CreditCard, color: 'bg-blue-500/10 text-blue-500', border: 'border-blue-500/20' },
          { label: 'Wallet', path: '/wallet', icon: Wallet, color: 'bg-purple-500/10 text-purple-500', border: 'border-purple-500/20' },
          { label: 'Affiliate', path: '/referrals', icon: Users, color: 'bg-amber-500/10 text-amber-500', border: 'border-amber-500/20' },
        ].map((action, i) => (
          <Link 
            key={i} 
            to={action.path}
            className="flex flex-col items-center group"
          >
            <motion.div 
              whileHover={{ y: -4, scale: 1.03 }}
              whileTap={{ scale: 0.95 }}
              className={`w-full aspect-square sm:aspect-auto sm:h-24 rounded-2xl sm:rounded-3xl bg-white dark:bg-[#111827] border ${action.border} flex flex-col items-center justify-center shadow-sm group-hover:shadow-md transition-all duration-300`}
            >
              <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl ${action.color} flex items-center justify-center mb-1 sm:mb-2 group-hover:scale-110 transition-transform`}>
                <action.icon className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <span className="text-[10px] sm:text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-tighter">{action.label}</span>
            </motion.div>
          </Link>
        ))}
      </div>

      {/* Business Card Notice Banner if not activated */}
      {!hasActiveCard && (
        <div className="p-6 rounded-3xl bg-amber-500/10 border-2 border-amber-400/40 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">First Activate Your Business Card</h3>
              <p className="text-xs text-slate-600 dark:text-slate-300">Choose Starter (₨ 700), Premium (₨ 1400), Gold (₨ 2100), or Royal (₨ 3000) to start earning.</p>
            </div>
          </div>
          <Link to="/business-card" className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl shrink-0 transition-all">
            Activate Now
          </Link>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden group"
          >
            <div className="flex justify-between items-start mb-3 relative z-10">
              <div>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{stat.label}</p>
                <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">{stat.value}</h3>
              </div>
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} ${stat.shadow} flex items-center justify-center text-white shadow-md shrink-0`}>
                <stat.icon className="w-5 h-5" />
              </div>
            </div>
            <div className="inline-flex items-center space-x-1 text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/80 px-2 py-1 rounded-md">
              <TrendingUp className="w-3 h-3 text-emerald-500" />
              <span>{stat.trend}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Earnings Analytics</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Daily video ad earnings tracking in PKR</p>
            </div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-500/20">
              ₨ {rewardPerAd} / Ad
            </span>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRewards" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.2} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dx={-10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area type="monotone" dataKey="rewards" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorRewards)" activeDot={{ r: 6, strokeWidth: 0, fill: '#10b981' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Quick Video Ads */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="p-6 rounded-2xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Daily Video Ads</h3>
              <Link to="/campaigns" className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline">View All 5</Link>
            </div>
            
            <div className="space-y-3">
              {campaigns.slice(0, 3).map((campaign) => (
                <div key={campaign.id} className="flex items-center space-x-3 p-2.5 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-slate-800">
                  <div className="w-12 h-10 rounded-lg overflow-hidden shrink-0 relative bg-slate-900">
                    <img src={campaign.thumbnail} alt={campaign.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">{campaign.title}</h4>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">15s Duration</span>
                  </div>
                  <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 shrink-0">₨ {rewardPerAd}</span>
                </div>
              ))}
            </div>
          </div>
          
          <Link to="/campaigns" className="w-full mt-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-2 shadow-md cursor-pointer">
            <span>Watch Video Ads</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>

      <FbrCertificateModal isOpen={isFbrModalOpen} onClose={() => setIsFbrModalOpen(false)} />
    </div>
  );
}

