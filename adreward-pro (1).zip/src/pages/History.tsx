import React, { useState } from 'react';
import { Search, Filter, ArrowUpRight, ArrowDownRight, Download, Calendar, History as HistoryIcon, X, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';
import { Link } from 'react-router-dom';

export function History() {
  const { transactions, deleteTransaction, pkrRate } = useApp();
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTx, setSelectedTx] = useState<any | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filteredData = transactions.filter(item => {
    const matchesFilter = 
      filter === 'all' ? true :
      filter === 'rewards' ? (item.type === 'reward' || item.type === 'bonus') :
      filter === 'withdrawals' ? item.type === 'withdrawal' : true;

    const matchesSearch = searchTerm.trim() === '' || 
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.referenceNumber.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-16 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200/80 dark:border-slate-800/80 pb-5">
        <div>
          <div className="flex items-center space-x-2 text-blue-600 dark:text-blue-400 font-bold text-xs uppercase tracking-widest mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Audit Trail</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Transaction History</h2>
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Complete verified ledger of your earnings, bonuses, and payouts.</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => {
              const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(transactions, null, 2));
              const downloadAnchor = document.createElement('a');
              downloadAnchor.setAttribute("href", dataStr);
              downloadAnchor.setAttribute("download", `UK_Dream_Transactions_${Date.now()}.json`);
              document.body.appendChild(downloadAnchor);
              downloadAnchor.click();
              downloadAnchor.remove();
            }}
            className="px-4 py-2.5 bg-white dark:bg-[#111827] border border-slate-200/80 dark:border-slate-800 rounded-xl text-slate-700 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 dark:hover:bg-white/5 transition-all flex items-center space-x-2 shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-blue-500" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="bg-white dark:bg-[#111827] rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
        {/* Controls Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-200/80 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/30 flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4">
          <div className="flex bg-slate-200/60 dark:bg-slate-900 p-1 rounded-xl overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: 'All Activity' },
              { id: 'rewards', label: 'Rewards & Bonuses' },
              { id: 'withdrawals', label: 'Withdrawals' }
            ].map((f) => (
              <button 
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                  filter === f.id 
                    ? 'bg-white dark:bg-blue-600 text-blue-600 dark:text-white shadow-sm' 
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
          
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search reference or description..." 
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-white/5 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-semibold focus:border-blue-500 outline-none text-slate-900 dark:text-white transition-all placeholder:text-slate-400"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {filteredData.length === 0 ? (
          <div className="py-16 px-6 text-center flex flex-col items-center">
            <div className="w-14 h-14 bg-blue-500/10 text-blue-500 rounded-2xl flex items-center justify-center mb-4">
              <HistoryIcon className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">No Transactions Found</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 max-w-sm">
              {searchTerm ? 'No history records match your search filter.' : 'Your account has no recorded transactions yet.'}
            </p>
            <Link to="/campaigns" className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-blue-500/20">
              Start Earning Now
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {filteredData.map((tx, i) => {
              const isEarning = tx.type === 'reward' || tx.type === 'bonus';
              const pkrVal = Math.abs(tx.amount * pkrRate);

              return (
                <div 
                  key={tx.id} 
                  className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/80 dark:hover:bg-white/[0.02] transition-colors group"
                >
                  <div className="flex items-start space-x-3.5">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                      isEarning 
                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20' 
                        : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20'
                    }`}>
                      {isEarning ? <ArrowDownRight className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm leading-snug">{tx.description}</h4>
                      <div className="flex items-center space-x-2 text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                        <span className="font-mono text-slate-400">Ref: {tx.referenceNumber}</span>
                        <span>•</span>
                        <span>{tx.date}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end space-x-4 border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100 dark:border-slate-800">
                    <div className="text-left sm:text-right">
                      <div className={`font-black text-sm ${isEarning ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-900 dark:text-white'}`}>
                        {isEarning ? '+' : '-'}₨ {pkrVal.toFixed(0)} PKR
                      </div>
                      <div className="flex items-center space-x-1.5 sm:justify-end mt-0.5">
                        <span className={`inline-block w-1.5 h-1.5 rounded-full ${
                          tx.status === 'Completed' || tx.status === 'Approved' || tx.status === 'completed' ? 'bg-emerald-500' :
                          tx.status === 'Pending' || tx.status === 'pending' ? 'bg-amber-500' : 'bg-red-500'
                        }`} />
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                          {tx.status}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => setSelectedTx(tx)}
                        className="px-3 py-1.5 bg-slate-100 dark:bg-white/5 hover:bg-blue-600 hover:text-white text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold transition-all"
                      >
                        Receipt
                      </button>

                      {deletingId === tx.id ? (
                        <div className="flex items-center space-x-1.5">
                          <button 
                            onClick={async () => {
                              try {
                                await deleteTransaction(tx.id);
                              } catch (err) {
                                console.warn('Delete transaction error:', err);
                              }
                              setDeletingId(null);
                            }}
                            className="px-2.5 py-1 bg-red-600 text-white text-[10px] font-bold rounded-lg"
                          >
                            Confirm
                          </button>
                          <button 
                            onClick={() => setDeletingId(null)}
                            className="px-2 py-1 bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-bold rounded-lg"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setDeletingId(tx.id)}
                          className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                          title="Delete record"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Transaction Receipt Modal */}
      <AnimatePresence>
        {selectedTx && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-[#111827] rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800"
            >
              <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 text-white text-center relative">
                <button 
                  onClick={() => setSelectedTx(null)}
                  className="absolute top-4 right-4 p-1.5 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
                <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-white/20">
                  <ShieldCheck className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-lg">Transaction Receipt</h3>
                <p className="text-xs text-blue-100 opacity-90">UK Dream Official Verification</p>
              </div>

              <div className="p-6 space-y-4">
                <div className="bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-3 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">Description</span>
                    <span className="font-bold text-slate-900 dark:text-white text-right max-w-[180px] truncate">{selectedTx.description}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">PKR Equivalent</span>
                    <span className="font-black text-emerald-600 dark:text-emerald-400 text-sm">
                      ₨ {Math.abs(selectedTx.amount * pkrRate).toFixed(2)} PKR
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">USD Value</span>
                    <span className="font-bold text-slate-900 dark:text-white">${Math.abs(selectedTx.amount).toFixed(2)} USD</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">Reference Code</span>
                    <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{selectedTx.referenceNumber}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">Date & Time</span>
                    <span className="font-bold text-slate-900 dark:text-white">{selectedTx.date}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">Status</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 uppercase">
                      {selectedTx.status}
                    </span>
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedTx(null)}
                  className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-xs rounded-xl transition-all"
                >
                  Close Receipt
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

