import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Moon, Sun, Bell, Lock, User, CheckCircle2, ShieldCheck, Key, Globe, CreditCard } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function Settings() {
  const { theme, setTheme, user, setUser } = useApp();

  // Profile Form state
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '+92 300 0000000');
  const [country, setCountry] = useState(user?.country || 'Pakistan');
  const [profileSuccess, setProfileSuccess] = useState(false);

  // Notification toggles state
  const [notifs, setNotifs] = useState({
    campaigns: true,
    rewards: true,
    withdrawals: true,
    marketing: false
  });

  // Password modal/inline state
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [currPass, setCurrPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passSuccess, setPassSuccess] = useState(false);
  const [passError, setPassError] = useState('');

  // 2FA state
  const [twoFactor, setTwoFactor] = useState(false);
  const [twoFactorMessage, setTwoFactorMessage] = useState('');

  // Handle Profile Update
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const updatedUser = { ...user, name, phone, country };
    setUser(updatedUser);

    // Save to localStorage
    const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
    if (storedUsers[user.email]) {
      storedUsers[user.email] = { ...storedUsers[user.email], name, phone, country };
      localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
    }

    setProfileSuccess(true);
    setTimeout(() => setProfileSuccess(false), 3000);
  };

  // Handle Password Change
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPassError('');
    if (newPass !== confirmPass) {
      setPassError('New passwords do not match');
      return;
    }
    if (newPass.length < 6) {
      setPassError('Password must be at least 6 characters');
      return;
    }

    if (user?.email) {
      const storedUsers = JSON.parse(localStorage.getItem('adreward_users') || '{}');
      if (storedUsers[user.email]) {
        storedUsers[user.email].password = newPass;
        localStorage.setItem('adreward_users', JSON.stringify(storedUsers));
      }
    }

    setPassSuccess(true);
    setCurrPass('');
    setNewPass('');
    setConfirmPass('');
    setTimeout(() => {
      setPassSuccess(false);
      setShowPasswordForm(false);
    }, 2500);
  };

  // Toggle 2FA
  const handleToggleTwoFactor = () => {
    const nextState = !twoFactor;
    setTwoFactor(nextState);
    setTwoFactorMessage(nextState ? 'Two-Factor Authentication is now ENABLED.' : 'Two-Factor Authentication is disabled.');
    setTimeout(() => setTwoFactorMessage(''), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Account & System Settings</h2>
        <p className="text-slate-500 dark:text-slate-400">Manage your profile, theme appearance, notifications, and security preferences.</p>
      </div>

      <div className="space-y-6">
        {/* Profile Information */}
        <motion.section 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Personal Profile</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Update your account name and contact details.</p>
              </div>
            </div>
            {profileSuccess && (
              <span className="flex items-center space-x-1 text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 dark:text-emerald-400 px-3 py-1.5 rounded-full border border-emerald-200 dark:border-emerald-500/20">
                <CheckCircle2 className="w-4 h-4" />
                <span>Profile Saved</span>
              </span>
            )}
          </div>

          <form onSubmit={handleSaveProfile} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Full Name</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Email Address</label>
              <input 
                type="email" 
                value={user?.email || ''}
                readOnly
                className="w-full px-4 py-3 bg-slate-100 dark:bg-white/10 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-500 dark:text-slate-400 text-sm cursor-not-allowed font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Phone Number</label>
              <input 
                type="text" 
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Country</label>
              <select 
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white text-sm"
              >
                <option value="Pakistan">Pakistan</option>
                <option value="United States">United States</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="Canada">Canada</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
              </select>
            </div>

            <div className="sm:col-span-2 pt-2 flex justify-end">
              <button 
                type="submit"
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md transition-all active:scale-95"
              >
                Save Changes
              </button>
            </div>
          </form>
        </motion.section>

        {/* Appearance & Theme Selection */}
        <motion.section 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm"
        >
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2.5 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl">
              {theme === 'dark' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Theme & Appearance</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Choose your preferred visual display mode.</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button 
              onClick={() => setTheme('light')}
              className={`p-5 rounded-2xl border-2 transition-all flex items-center space-x-4 ${
                theme === 'light' 
                  ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 font-bold shadow-md' 
                  : 'border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700/50 text-slate-600 dark:text-slate-400'
              }`}
            >
              <div className="p-3 bg-white text-amber-500 rounded-xl shadow-sm border border-slate-200">
                <Sun className="w-6 h-6" />
              </div>
              <div className="text-left">
                <p className="font-bold text-slate-900 dark:text-white">Light Mode</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Crisp, high-contrast bright canvas</p>
              </div>
            </button>

            <button 
              onClick={() => setTheme('dark')}
              className={`p-5 rounded-2xl border-2 transition-all flex items-center space-x-4 ${
                theme === 'dark' 
                  ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 font-bold shadow-md' 
                  : 'border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700/50 text-slate-600 dark:text-slate-400'
              }`}
            >
              <div className="p-3 bg-slate-900 text-indigo-400 rounded-xl shadow-sm border border-slate-700">
                <Moon className="w-6 h-6" />
              </div>
              <div className="text-left">
                <p className="font-bold text-slate-900 dark:text-white">Dark Mode</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Ultra-sleek dark slate interface</p>
              </div>
            </button>
          </div>
        </motion.section>

        {/* Notifications */}
        <motion.section 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm"
        >
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2.5 bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-xl">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Notification Preferences</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Control what alerts and emails you receive.</p>
            </div>
          </div>
          
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {[
              { key: 'campaigns', label: 'New Campaign Alerts', desc: 'Get notified when new ad campaigns become available.' },
              { key: 'rewards', label: 'Reward Deposit Alerts', desc: 'Instant alert when a reward or referral bonus hits your balance.' },
              { key: 'withdrawals', label: 'Withdrawal Status Updates', desc: 'Realtime notification on Meezan, EasyPaisa, or JazzCash payouts.' },
              { key: 'marketing', label: 'Weekly Summary & Offers', desc: 'Receive weekly earnings reports and special promo invites.' },
            ].map((item) => {
              const isOn = notifs[item.key as keyof typeof notifs];
              return (
                <div key={item.key} className="flex items-center justify-between py-4 first:pt-0 last:pb-0">
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-white text-sm">{item.label}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{item.desc}</p>
                  </div>
                  <button 
                    type="button"
                    onClick={() => setNotifs(prev => ({ ...prev, [item.key]: !prev[item.key as keyof typeof notifs] }))}
                    className={`w-12 h-6 rounded-full transition-colors relative ${isOn ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'}`}
                  >
                    <div className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform shadow-sm ${isOn ? 'translate-x-6' : ''}`}></div>
                  </button>
                </div>
              );
            })}
          </div>
        </motion.section>

        {/* Security Section */}
        <motion.section 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 shadow-sm"
        >
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2.5 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Security & Password</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Protect your account balance and credentials.</p>
            </div>
          </div>
          
          <div className="space-y-4">
            {/* Change Password Bar */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-slate-900 dark:text-white text-sm">Account Password</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Regularly change your password to keep your wallet safe.</p>
                </div>
                <button 
                  onClick={() => setShowPasswordForm(!showPasswordForm)}
                  className="px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-900 dark:text-white text-xs font-bold rounded-xl transition-all"
                >
                  {showPasswordForm ? 'Cancel' : 'Change Password'}
                </button>
              </div>

              {/* Expandable Password Form */}
              <AnimatePresence>
                {showPasswordForm && (
                  <motion.form 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    onSubmit={handleChangePassword}
                    className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700 space-y-3"
                  >
                    {passError && (
                      <p className="text-xs font-bold text-red-500 bg-red-50 dark:bg-red-500/10 p-2.5 rounded-lg border border-red-200 dark:border-red-500/20">{passError}</p>
                    )}
                    {passSuccess && (
                      <p className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 p-2.5 rounded-lg border border-emerald-200 dark:border-emerald-500/20">Password updated successfully!</p>
                    )}

                    <input 
                      type="password" 
                      placeholder="Current Password"
                      value={currPass}
                      onChange={(e) => setCurrPass(e.target.value)}
                      required
                      className="w-full px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none text-sm text-slate-900 dark:text-white"
                    />
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input 
                        type="password" 
                        placeholder="New Password (min 6 chars)"
                        value={newPass}
                        onChange={(e) => setNewPass(e.target.value)}
                        required
                        className="w-full px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none text-sm text-slate-900 dark:text-white"
                      />
                      <input 
                        type="password" 
                        placeholder="Confirm New Password"
                        value={confirmPass}
                        onChange={(e) => setConfirmPass(e.target.value)}
                        required
                        className="w-full px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none text-sm text-slate-900 dark:text-white"
                      />
                    </div>
                    <button 
                      type="submit"
                      className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all"
                    >
                      Update Password Now
                    </button>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>

            {/* 2FA Toggle Bar */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-900 dark:text-white text-sm">Two-Factor Authentication (2FA)</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {twoFactor ? '2FA Protection is ACTIVE' : 'Require an extra code when withdrawing funds or signing in.'}
                </p>
                {twoFactorMessage && (
                  <p className="text-[11px] font-bold text-emerald-500 mt-1">{twoFactorMessage}</p>
                )}
              </div>
              <button 
                type="button"
                onClick={handleToggleTwoFactor}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                  twoFactor 
                    ? 'bg-emerald-500 text-white hover:bg-emerald-600' 
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                {twoFactor ? 'Enabled' : 'Enable 2FA'}
              </button>
            </div>
          </div>
        </motion.section>
      </div>
    </div>
  );
}
