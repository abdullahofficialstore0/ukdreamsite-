import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShieldCheck, CheckCircle2, Download, Printer, ExternalLink, Building2, Award } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface FbrCertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function FbrCertificateModal({ isOpen, onClose }: FbrCertificateModalProps) {
  const { siteSettings } = useApp();

  if (!isOpen) return null;

  const certificateNumber = siteSettings.fbrCertificateNumber || 'NTN: 8940125-9 / FBR Reg: UKD-2026-PRO';

  const handlePrint = () => {
    window.print();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-950/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ duration: 0.2 }}
          className="bg-white dark:bg-[#0f172a] text-slate-900 dark:text-white rounded-3xl max-w-2xl w-full shadow-2xl border border-emerald-500/30 overflow-hidden relative"
        >
          {/* Top Bar / Header */}
          <div className="bg-gradient-to-r from-emerald-700 via-teal-800 to-slate-900 p-4 sm:p-5 text-white flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center border border-white/20 shrink-0">
                <ShieldCheck className="w-6 h-6 text-emerald-300" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-200 block">Government of Pakistan</span>
                <h3 className="text-base sm:text-lg font-black tracking-tight">FBR Registration Certificate</h3>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-xl transition-colors cursor-pointer text-white/80 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Custom Image or Official Certificate Template */}
          <div className="p-6 sm:p-8 space-y-6">
            {siteSettings.fbrCertificateImage ? (
              <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800">
                <img 
                  src={siteSettings.fbrCertificateImage} 
                  alt="FBR Registration Certificate" 
                  className="w-full h-auto object-contain max-h-[500px]"
                />
              </div>
            ) : (
              <div className="bg-gradient-to-b from-amber-50/40 to-slate-50 dark:from-slate-900 dark:to-slate-950 p-6 sm:p-8 rounded-2xl border-2 border-emerald-600/30 relative overflow-hidden shadow-inner space-y-6">
                {/* Decorative Watermark Shield */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-5 pointer-events-none">
                  <Award className="w-80 h-80 text-emerald-600" />
                </div>

                {/* Government Seal & Letterhead */}
                <div className="text-center border-b border-emerald-600/20 pb-5">
                  <div className="inline-flex items-center justify-center space-x-2 bg-emerald-600 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider mb-2 shadow-sm">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Official Taxpayer Status: ACTIVE & VERIFIED</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">
                    Federal Board of Revenue
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-serif italic">Government of Pakistan • Taxpayer Registration System</p>
                </div>

                {/* Main Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                  <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Company Name</span>
                    <p className="font-extrabold text-slate-900 dark:text-white text-sm mt-0.5">UK DREAM ADREWARD PRO LTD</p>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Registration / NTN</span>
                    <p className="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-sm mt-0.5">{certificateNumber}</p>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Taxpayer Category</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">Corporate / Digital Advertising Services</p>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Verification Authority</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">FBR Inland Revenue Department</p>
                  </div>
                </div>

                {/* Security Verification Stamp Box */}
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-emerald-600 text-white rounded-lg flex items-center justify-center shrink-0">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">Active Taxpayer List (ATL) Certified</h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">Tax compliance verified for legal corporate ad networks.</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-600 text-white font-mono text-[10px] font-bold rounded-md">VERIFIED</span>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center space-x-1">
                <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Verified by FBR e-Portal System</span>
              </p>

              <div className="flex items-center space-x-2 w-full sm:w-auto">
                <button
                  onClick={handlePrint}
                  className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-bold text-xs rounded-xl transition-colors flex items-center justify-center space-x-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Certificate</span>
                </button>

                <button
                  onClick={onClose}
                  className="flex-1 sm:flex-none px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
