import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, PlaySquare, Wallet, History, UserCircle } from 'lucide-react';
import { cn } from '../lib/utils';

const mobileNavItems = [
  { icon: Home, label: 'Home', path: '/' },
  { icon: PlaySquare, label: 'Campaigns', path: '/campaigns' },
  { icon: Wallet, label: 'Wallet', path: '/wallet' },
  { icon: History, label: 'History', path: '/history' },
  { icon: UserCircle, label: 'Profile', path: '/profile' },
];

export function BottomNav() {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-[#0a0f1c]/80 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 z-50 pb-safe">
      <div className="flex items-center justify-around px-2 py-3">
        {mobileNavItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => cn(
              "flex flex-col items-center p-2 rounded-xl transition-all duration-200 min-w-[64px]",
              isActive 
                ? "text-blue-600 dark:text-blue-400" 
                : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            )}
          >
            <item.icon className={cn(
              "w-5 h-5 mb-1 transition-transform duration-200"
            )} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
