import React from 'react';
import { Bell, Search, Menu, Sun, Moon } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useLocation } from 'react-router-dom';
import { Logo } from './Logo';

export function TopBar({ onMenuClick }: { onMenuClick?: () => void }) {
  const { walletBalance, theme, setTheme, user } = useApp();
  const location = useLocation();
  
  const getPageTitle = () => {
    switch(location.pathname) {
      case '/': return 'Dashboard';
      case '/campaigns': return 'Available Campaigns';
      case '/wallet': return 'Wallet';
      case '/wallet/withdraw': return 'Withdraw Funds';
      case '/history': return 'Rewards History';
      case '/referrals': return 'Referral Program';
      case '/profile': return 'My Profile';
      case '/settings': return 'Settings';
      default: return 'UK Dream';
    }
  };

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6 py-4 bg-white/80 dark:bg-[#0a0f1c]/80 backdrop-blur-xl border-b border-slate-200 dark:border-slate-800 transition-colors duration-300">
      <div className="flex items-center">
        <button 
          onClick={onMenuClick} 
          aria-label="Open menu"
          className="mr-3 md:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white rounded-xl bg-slate-100 dark:bg-slate-800/60 active:scale-95 transition-all"
        >
          <Menu className="w-6 h-6" />
        </button>
        <div className="md:hidden mr-4">
          <Logo />
        </div>
        <h1 className="text-xl font-semibold text-slate-900 dark:text-white hidden sm:block">
          {getPageTitle()}
        </h1>
        {/* Search Bar - hidden on small mobile, visible on tablet+ */}
        <div className="hidden md:flex ml-8 relative group">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
          <input 
            type="text" 
            placeholder="Search..." 
            className="w-64 pl-9 pr-4 py-2 bg-slate-100 dark:bg-white/5 border-transparent focus:bg-white dark:focus:bg-[#111827] border focus:border-blue-500/50 rounded-full text-sm outline-none transition-all duration-300 text-slate-900 dark:text-white placeholder:text-slate-500"
          />
        </div>
      </div>

      <div className="flex items-center space-x-3 sm:space-x-4">
        {/* Balance Badge */}
        <div className="flex flex-col items-end px-3 py-1 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 rounded-xl">
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-wider">Balance</span>
          <span className="text-sm font-extrabold text-emerald-700 dark:text-emerald-300">${walletBalance.toFixed(2)}</span>
        </div>
        
        {/* Theme Switcher Button Right Next to Balance */}
        <button 
          onClick={toggleTheme} 
          aria-label="Toggle theme"
          className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-amber-400 transition-all active:scale-95 border border-slate-200 dark:border-slate-700 shadow-sm" 
          title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5 text-indigo-600" />}
        </button>

        <button className="relative p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors rounded-xl hover:bg-slate-100 dark:hover:bg-white/10">
          <Bell className="w-5 h-5" />
          {useApp().notifications?.length > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-[#0a0f1c]"></span>
          )}
        </button>

        <button className="w-9 h-9 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center p-[2px] shadow-sm hover:shadow-md transition-shadow">
          <div className="w-full h-full rounded-full border-2 border-white dark:border-[#0a0f1c] overflow-hidden bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
            {user?.avatar ? (
              <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <span className="text-slate-500 text-xs font-bold">{user?.name?.charAt(0) || 'U'}</span>
            )}
          </div>
        </button>
      </div>
    </header>
  );
}
