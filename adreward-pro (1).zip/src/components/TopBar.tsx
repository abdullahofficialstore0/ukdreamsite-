import React, { useState } from 'react';
import { Bell, Search, Menu, Sun, Moon, ShieldCheck, Youtube, MessageSquare, Phone, Facebook } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useLocation } from 'react-router-dom';
import { Logo } from './Logo';
import { FbrCertificateModal } from './FbrCertificateModal';

export function TopBar({ onMenuClick }: { onMenuClick?: () => void }) {
  const { walletBalance, theme, setTheme, user, siteSettings } = useApp();
  const location = useLocation();
  const [isFbrModalOpen, setIsFbrModalOpen] = useState(false);
  
  const getPageTitle = () => {
    switch(location.pathname) {
      case '/': return 'Dashboard';
      case '/campaigns': return 'Available Campaigns';
      case '/wallet': return 'Wallet';
      case '/wallet/withdraw': return 'Withdraw Funds';
      case '/history': return 'Rewards History';
      case '/referrals': return 'Affiliate Program';
      case '/profile': return 'My Profile';
      case '/settings': return 'Settings';
      default: return 'UK Dream';
    }
  };

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <>
      <div className="px-2 sm:px-6 pt-2 sm:pt-4 sticky top-0 z-30 pointer-events-none">
        <header className="pointer-events-auto flex items-center justify-between px-2.5 sm:px-6 py-2 sm:py-3 bg-white/95 dark:bg-[#111827]/95 backdrop-blur-2xl border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl transition-all duration-300 shadow-xl shadow-slate-200/20 dark:shadow-black/40">
          <div className="flex items-center min-w-0 mr-1 sm:mr-3">
            <button 
              onClick={onMenuClick} 
              aria-label="Open menu"
              className="mr-1.5 md:hidden p-1.5 -ml-1 text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white rounded-xl bg-slate-100 dark:bg-slate-800/60 active:scale-95 transition-all shrink-0"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="md:hidden mr-1.5 shrink-0">
              <Logo hideSubtitleOnMobile={true} className="scale-95 origin-left" />
            </div>
            <h1 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white hidden md:block truncate">
              {getPageTitle()}
            </h1>

            {/* Social Icons Toolbar in TopBar */}
            <div className="hidden lg:flex items-center space-x-1.5 ml-6 pl-6 border-l border-slate-200 dark:border-slate-800">
              {siteSettings?.socialYoutube && (
                <a
                  href={siteSettings.socialYoutube}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                  title="Official YouTube Channel"
                >
                  <Youtube className="w-4 h-4" />
                </a>
              )}
              {siteSettings?.socialWhatsapp && (
                <a
                  href={siteSettings.socialWhatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 text-emerald-500 hover:bg-emerald-500/10 rounded-lg transition-colors"
                  title="WhatsApp Support Group"
                >
                  <MessageSquare className="w-4 h-4" />
                </a>
              )}
              {siteSettings?.socialTelegram && (
                <a
                  href={siteSettings.socialTelegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 text-sky-400 hover:bg-sky-400/10 rounded-lg transition-colors"
                  title="Telegram Official Channel"
                >
                  <Phone className="w-4 h-4" />
                </a>
              )}
              {siteSettings?.socialFacebook && (
                <a
                  href={siteSettings.socialFacebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 text-blue-500 hover:bg-blue-500/10 rounded-lg transition-colors"
                  title="Facebook Page"
                >
                  <Facebook className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-1.5 sm:space-x-3 shrink-0">
            {/* FBR Certificate Badge Trigger */}
            {siteSettings?.fbrCertificateEnabled !== false && (
              <button
                onClick={() => setIsFbrModalOpen(true)}
                className="flex items-center space-x-1 px-2 py-1 sm:px-2.5 sm:py-1 bg-emerald-500/10 border border-emerald-500/30 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 font-bold text-xs rounded-xl transition-all cursor-pointer shrink-0 shadow-xs active:scale-95"
                title="View FBR Registration Certificate"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span className="text-[10px] sm:text-[11px] font-bold tracking-tight">FBR<span className="hidden xs:inline"> Govt</span></span>
              </button>
            )}

            {/* Balance Badge */}
            <div className="flex flex-col items-end px-1.5 sm:px-3 py-0.5 sm:py-1 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 rounded-xl shrink-0">
              <span className="text-[8px] sm:text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-wider">Balance</span>
              <span className="text-[11px] sm:text-sm font-black text-emerald-700 dark:text-emerald-300">${walletBalance.toFixed(2)}</span>
            </div>
            
            {/* Theme Switcher Button */}
            <button 
              onClick={toggleTheme} 
              aria-label="Toggle theme"
              className="p-1.5 sm:p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-amber-400 transition-all active:scale-95 border border-slate-200 dark:border-slate-700 shadow-xs shrink-0" 
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 sm:w-5 sm:h-5" /> : <Moon className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-600" />}
            </button>

            <button className="hidden sm:flex relative p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 shrink-0">
              <Bell className="w-5 h-5" />
              {useApp().notifications?.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-[#0a0f1c]"></span>
              )}
            </button>

            <button className="w-7 h-7 sm:w-9 sm:h-9 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center p-[2px] shadow-xs hover:shadow-md transition-shadow shrink-0">
              <div className="w-full h-full rounded-full border border-white dark:border-[#0a0f1c] overflow-hidden bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
                {user?.avatar ? (
                  <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-slate-500 text-[10px] sm:text-xs font-bold">{user?.name?.charAt(0) || 'U'}</span>
                )}
              </div>
            </button>
          </div>
        </header>
      </div>

      <FbrCertificateModal isOpen={isFbrModalOpen} onClose={() => setIsFbrModalOpen(false)} />
    </>
  );
}
