import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, PlaySquare, Wallet, History, Users, UserCircle, Settings } from 'lucide-react';
import { cn } from '../lib/utils';
import { useApp } from '../context/AppContext';
import { Logo } from './Logo';

const navItems = [
  { icon: Home, label: 'Dashboard', path: '/' },
  { icon: PlaySquare, label: 'Campaigns', path: '/campaigns' },
  { icon: Wallet, label: 'Wallet', path: '/wallet' },
  { icon: History, label: 'History', path: '/history' },
  { icon: Users, label: 'Referrals', path: '/referrals' },
  { icon: UserCircle, label: 'Profile', path: '/profile' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

export function Sidebar({ isOpen, onClose }: { isOpen?: boolean; onClose?: () => void }) {
  const { theme } = useApp();
  
  return (
    <aside className={cn(
      "flex flex-col w-64 h-screen border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0a0f1c] fixed top-0 left-0 z-40 transition-transform duration-300 md:translate-x-0",
      isOpen ? "translate-x-0" : "-translate-x-full"
    )}>
      <div className="p-6">
        <Logo />
      </div>
      
      <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            onClick={onClose}
            className={({ isActive }) => cn(
              "flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group",
              isActive 
                ? "bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-medium" 
                : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <item.icon className={cn(
              "w-5 h-5 transition-colors duration-200",
            )} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
      
      <div className="p-4 m-4 rounded-2xl bg-gradient-to-br from-blue-50 to-blue-100/50 dark:from-blue-900/20 dark:to-blue-800/10 border border-blue-100/50 dark:border-blue-700/20">
        <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">Go Premium</h4>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">Unlock 2x rewards on all campaigns.</p>
        <button className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors shadow-md shadow-blue-500/20">
          Upgrade Now
        </button>
      </div>
    </aside>
  );
}
