import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Home, PlaySquare, CreditCard, Wallet, History, Users, UserCircle, Settings, ShieldCheck } from 'lucide-react';
import { cn } from '../lib/utils';
import { useApp } from '../context/AppContext';
import { Logo } from './Logo';
import { FbrCertificateModal } from './FbrCertificateModal';

const navItems = [
  { icon: Home, label: 'Dashboard', path: '/' },
  { icon: CreditCard, label: 'Business Card', path: '/business-card' },
  { icon: PlaySquare, label: 'Campaigns', path: '/campaigns' },
  { icon: Wallet, label: 'Wallet', path: '/wallet' },
  { icon: History, label: 'History', path: '/history' },
  { icon: Users, label: 'Affiliate Program', path: '/referrals' },
  { icon: UserCircle, label: 'Profile', path: '/profile' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

export function Sidebar({ isOpen, onClose }: { isOpen?: boolean; onClose?: () => void }) {
  const { siteSettings } = useApp();
  const [isFbrModalOpen, setIsFbrModalOpen] = useState(false);
  
  return (
    <>
      <aside className={cn(
        "flex flex-col w-64 h-screen border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0a0f1c] fixed top-0 left-0 z-40 transition-transform duration-300 md:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-5 pb-3 border-b border-slate-100 dark:border-slate-800/80">
          <Logo />
          {siteSettings?.fbrCertificateEnabled !== false && (
            <button
              onClick={() => setIsFbrModalOpen(true)}
              className="mt-3 w-full flex items-center justify-center space-x-1.5 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold text-xs rounded-xl transition-all cursor-pointer shadow-xs active:scale-98"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>FBR Govt Registered</span>
            </button>
          )}
        </div>
        
        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={({ isActive }) => cn(
                "flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group",
                isActive 
                  ? "bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold" 
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white font-medium"
              )}
            >
              <item.icon className={cn(
                "w-5 h-5 transition-colors duration-200",
              )} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </aside>

      <FbrCertificateModal isOpen={isFbrModalOpen} onClose={() => setIsFbrModalOpen(false)} />
    </>
  );
}

