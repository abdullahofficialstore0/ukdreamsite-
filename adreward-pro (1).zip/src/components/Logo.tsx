import React from 'react';

interface LogoProps {
  className?: string;
  onClick?: () => void;
  hideSubtitleOnMobile?: boolean;
}

export function Logo({ className = '', onClick, hideSubtitleOnMobile = false }: LogoProps) {
  return (
    <div 
      onClick={onClick}
      className={`flex items-center space-x-2.5 select-none cursor-pointer shrink-0 ${className}`}
    >
      <div className="relative group shrink-0">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-emerald-500 rounded-2xl blur opacity-30 group-hover:opacity-75 transition duration-300"></div>
        <img 
          src="/src/assets/images/uk_dream_logo_1785829976392.jpg" 
          alt="UK Dream Logo" 
          referrerPolicy="no-referrer"
          className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl object-cover border border-slate-200/50 dark:border-slate-700/50 shadow-md shrink-0"
        />
      </div>
      <div className="flex flex-col min-w-0">
        <span className="text-base sm:text-xl font-black bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-500 tracking-tight whitespace-nowrap leading-none">
          UK Dream
        </span>
        <span className={`text-[8px] sm:text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest leading-none mt-1 whitespace-nowrap ${hideSubtitleOnMobile ? 'hidden sm:block' : ''}`}>
          AdReward Pro
        </span>
      </div>
    </div>
  );
}


