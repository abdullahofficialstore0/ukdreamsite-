import React, { useState, useEffect } from 'react';
import { motion, useAnimation } from 'motion/react';
import { MessageCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function WhatsAppWidget() {
  const { siteSettings } = useApp();
  const [lastActivity, setLastActivity] = useState(Date.now());
  const controls = useAnimation();

  useEffect(() => {
    const handleActivity = () => setLastActivity(Date.now());
    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('keydown', handleActivity);
    window.addEventListener('scroll', handleActivity);
    window.addEventListener('click', handleActivity);

    const interval = setInterval(() => {
      const inactiveTime = Date.now() - lastActivity;
      if (inactiveTime > 15000) { // 15 seconds of inactivity
        controls.start({
          rotate: [0, -10, 10, -10, 10, 0],
          transition: { duration: 0.5, repeat: 2 }
        });
      }
    }, 5000);

    return () => {
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('scroll', handleActivity);
      window.removeEventListener('click', handleActivity);
      clearInterval(interval);
    };
  }, [lastActivity, controls]);

  const handleWhatsAppClick = () => {
    if (siteSettings?.socialWhatsapp) {
      window.open(siteSettings.socialWhatsapp, '_blank');
    } else {
      const phone = siteSettings?.supportPhone?.replace(/\D/g, '') || '923001234567';
      window.open(`https://wa.me/${phone}`, '_blank');
    }
  };

  return (
    <motion.button
      animate={controls}
      onClick={handleWhatsAppClick}
      className="fixed bottom-28 right-6 z-[999] w-14 h-14 bg-emerald-500 text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-emerald-600 transition-colors group"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
    >
      <MessageCircle className="w-7 h-7" />
      <span className="absolute right-full mr-3 px-3 py-1.5 bg-slate-900 text-white text-[10px] font-bold rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
        Need help? Chat with us!
      </span>
      <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-pulse" />
    </motion.button>
  );
}
