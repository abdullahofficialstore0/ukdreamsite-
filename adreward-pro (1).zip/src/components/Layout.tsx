import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { BottomNav } from './BottomNav';
import { TopBar } from './TopBar';
import { useApp } from '../context/AppContext';

export function Layout() {
  const { user } = useApp();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#030712] text-slate-900 dark:text-slate-100 font-sans transition-colors duration-300">
      <Sidebar isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
      
      {/* Mobile overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden" 
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      <div className="md:ml-64 pb-20 md:pb-0 min-h-screen flex flex-col">
        <TopBar onMenuClick={() => setIsMobileMenuOpen(true)} />
        <main className="flex-1 p-4 sm:p-6 lg:p-10 w-full max-w-7xl mx-auto overflow-x-hidden">
          <Outlet />
        </main>

        <footer className="w-full py-8 border-t border-slate-200 dark:border-slate-800 text-center space-y-4 bg-white dark:bg-[#0a0f1c] mt-12">
          <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-left">
              <h3 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">UK Dream AI</h3>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">© 2026 UK Dream Private Limited. All Rights Reserved.</p>
            </div>
            <div className="flex items-center space-x-6">
              {['Privacy Policy', 'Terms of Service', 'Support'].map(item => (
                <a key={item} href="#" className="text-[11px] font-black text-slate-500 hover:text-blue-500 dark:hover:text-blue-400 transition-colors uppercase tracking-widest">
                  {item}
                </a>
              ))}
            </div>
          </div>
          <p className="text-[9px] text-slate-400 max-w-2xl mx-auto px-6 opacity-60">
            UK Dream is a secure affiliate and reward-based platform. Users must be 18+ to participate. Our AI-driven algorithms ensure fair distribution of rewards based on campaign engagement.
          </p>
        </footer>
      </div>
      <BottomNav />
    </div>
  );
}
